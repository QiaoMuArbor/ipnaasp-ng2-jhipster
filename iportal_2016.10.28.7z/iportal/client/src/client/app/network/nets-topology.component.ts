import { Component, ViewChild } from '@angular/core';
import { Network } from './network';
import { NetworkService } from './network.service';
import { ActivatedRoute, Router,ROUTER_DIRECTIVES } from "@angular/router";
import { MODAL_DIRECTIVES, ModalComponent } from 'ng2-bs3-modal/ng2-bs3-modal';
import { EventBroadcastService } from '../shared/index';
import { Topo } from './topo.component';



@Component({
  moduleId:module.id,
  selector: 'nets-topology',
  providers:[NetworkService],
  directives:[ROUTER_DIRECTIVES, MODAL_DIRECTIVES, Topo],
  template: `
    <div *ngIf="isLoading">Loading...</div>
    <topo [data]="networks"></topo>
  `,
})

export class NetsTopologyComponent {
  @ViewChild('modal') modal: ModalComponent;
  public networks:any;
  isLoading:boolean = false;
  constructor(private networkService :NetworkService, private router:Router, private eventBroadcastService :EventBroadcastService) {
    this.networks = '';
  }
  ngOnInit() {
    this.getNetworksList();
  }

  getNetworksList(){
    let that = this;
    that.isLoading = true;
    that.networkService.getTopoData()
    .subscribe(
      res =>{
        that.isLoading = false;
        that.networks = res;
      // },error=> {
      //   that.eventBroadcastService.broadcastError(error.message);
      });
  }

}
