/**
 * Created by zte on 16-8-15.
 */
import { RouterConfig } from '@angular/router';
import { NetworkComponent } from './network.component';
import { NetsListComponent } from './nets-list.component';
import { NetsTopologyComponent } from './nets-topology.component';
import { NetAddComponent } from './net-add.component';
import { NetDetailComponent } from './net-detail.component';
//import { NetModifyComponent } from './net-modify.component';

export const NetworkRoutes: RouterConfig = [
  {
    path: 'network',
    children:[
      {
        path: '',
        redirectTo: 'list',
        pathMatch: 'full'
      },
      {
        path: 'list',
        component: NetworkComponent,
        children: [
          {
            path: '',
            redirectTo: 'nets-list',
            pathMatch: 'full'
          },
          {
            path: 'nets-list',
            component: NetsListComponent
          },
          {
            path: 'nets-topology',
            component: NetsTopologyComponent
          }
        ]
      },
      {
        path: 'net-add',
        component: NetAddComponent
      },
      {
        path: 'net-detail/:netid',
        component: NetDetailComponent
      }
      // {
      //   path: 'net-modify/:netid',
      //   component: NetModifyComponent
      // }
    ]
  }
];
