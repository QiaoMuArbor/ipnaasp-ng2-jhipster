import { Component, ViewChild} from '@angular/core';
import { Network } from './network';
import { NetworkService } from './network.service';
import { ActivatedRoute, Router,ROUTER_DIRECTIVES } from "@angular/router";
import { MODAL_DIRECTIVES, ModalComponent } from 'ng2-bs3-modal/ng2-bs3-modal';
import { EventBroadcastService, ISOLocalPipe, NetStatePipe } from '../shared/index';
import { ActiveProjectService } from '../app.service';


@Component({
  moduleId:module.id,
  selector: 'nets-list',
  providers:[NetworkService],
  directives:[ROUTER_DIRECTIVES, MODAL_DIRECTIVES],
  templateUrl: 'nets-list.component.html',
  styleUrls:['nets-list.component.css'],
  pipes:[ISOLocalPipe, NetStatePipe]
})

export class NetsListComponent {
  @ViewChild('modal') modal: ModalComponent;
  public displayNetworks:Array<Network>;
  public networks:Array<Network>;
  isLoading:boolean = false;
  isNotExistNetworksByproject = false;
  isFirstLoad :boolean = true;
  constructor(private networkService :NetworkService, private router:Router, private eventBroadcastService :EventBroadcastService, private activeProject: ActiveProjectService) {
  }
  ngOnInit() {
    this.networks = [];
    this.displayNetworks = [];
    this.getNetworksList();
  }

  getNetworksList(){
    let that = this;
    this.isLoading = true;
    that.networkService.getNetworks().subscribe(
      networks =>{
        that.isLoading = false;
        that.networks = networks.networks;
        that.displayNetworks = networks.networks;
      },error=> {
        that.isLoading = false;
        that.eventBroadcastService.broadcastError(error.message);
      });

  }

  searchNetwork(searchtext:string) {
    this.displayNetworks = _.filter(this.networks, function(network){
      return network.name.indexOf(searchtext)!=-1;
    });
  }

  delNetwork(netid: string){
    let that = this;
    this.networkService.delete(netid).subscribe(
      res=>{
        that.modal.close();
        that.eventBroadcastService.broadcastSuccess('网络删除成功！');
        that.getNetworksList();
      },
      error => {
        that.modal.close();
        that.eventBroadcastService.broadcastError(error.message);
      }
    )
  }

  checkHandleNet(netPub: boolean){
    if(this.activeProject.id == "admin") {
      return true;
    }
    else if(netPub == false){
      return true;
    }
    else{
      return false;
    }

  }

}
