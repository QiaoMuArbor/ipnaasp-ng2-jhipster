import {Component, Input, Output, ElementRef, SimpleChange} from '@angular/core';
import { ActivatedRoute, Router,ROUTER_DIRECTIVES } from "@angular/router";
import { Network } from './network';
import { ActiveProjectService } from '../app.service';


@Component({
  moduleId: module.id,
  selector: 'topo',
  directives:[ROUTER_DIRECTIVES],
  template: `<div></div>`
})

export class Topo {
  @Input('data') data: any;

  private el: HTMLElement;
  color: any;
  const_svg_width: number = 1180;
  const_svg_heigth: number = 450;
  normal_network_width: number = 260;
  normal_service_heigth: number = 60;
  small_network_width: number = 100;
  small_device_heigth: number = 40;
  styleMap: any = {
    'network': {
      'rx': 7,
      'ry': 7,
      'width': 20,
      'networkWidth': 180,
      'height': 60,
      'nameY': -3,
      'nameX': 60,
      'subnetY': -20,
      'subnetX': 20,
      'externalY': -15,
      'externalX': 52,
      'imageWidth': '11',
      'imageHeight': '12'
    },
    'service': {
      'leftWidth': 75,
      'x': 0,
      'y': 0,
      'rx': 6,
      'ry': 6,
      'width': 40,
      'height': 50,
      'heightExtend': 0,
      'nameX': 2,
      'nameY': 20,
      'lineWidth': '2px',
      'typeX': 1,
      'typeY': 36,
      'typeWidth': 38,
      'typeHeight': 13,
      'typeNameRX': 8,
      'typeNameSX': 2,
      'typeNameY': 49,
      'distance': 40,
      'imageService': '../images/pod_topo.jpg'
    },
    'port': {
      'lineWidth': '2px',
      'x1Left': 0,
      'x1Right': 0,
      'y1': 0,
      'y2': 0,
      'x2Left': 0,
      'x2Right': 0,
      'textleftX': -82,
      'textrightX': 25,
      'textHeight': -4
    }
  };

  constructor(el: ElementRef, private router:Router, private activeProject: ActiveProjectService) {
    this.color= d3.scale.category20();
    this.el = el.nativeElement;
  }

  ngOnInit() {
  }


  ngOnChanges(changes: {[propertyName: string]: SimpleChange}) {
    this.darwSvg(changes['data'].currentValue);
  }

  darwSvg(newData:any){
    if(newData != ""){
      d3.select('svg').remove();
      var svgConfig = {};
      svgConfig = this.getSmallTopo(newData);
      var svg = d3.select(this.el).append('svg')
        .attr({
          width: svgConfig.svgWidth,
          height: svgConfig.svgHeigth,
          id: 'topology_canvas'
        });
      this.fillNetworks(svg, newData.networkList);
    }
  }


  getSmallTopo(newData:any){
    var svgConfig = {
      svgWidth: this.const_svg_width,
      svgHeigth: this.const_svg_heigth
    };
    this.setSmallConfig();
    if (newData.networkNum * this.small_network_width > this.const_svg_width) {
      this.styleMap.network.networkWidth = this.const_svg_width / newData.networkNum;
    }
    if ((newData.serviceNum + 2) * this.small_device_heigth + 40 > this.const_svg_heigth) {
      svgConfig.svgHeigth = (newData.deviceNum + 2) * this.small_device_heigth + 40;
          }
      this.setNetworkHeigth(svgConfig.svgHeigth);
    return svgConfig;
  }

  setSmallConfig() {
    this.styleMap.network.width = 15;
    this.styleMap.network.networkWidth = this.small_network_width;
    this.styleMap.network.heightExtend = 5;
    this.styleMap.service.width = 20;
    this.styleMap.service.height = 20;
    this.styleMap.service.leftWidth = 45;
    this.styleMap.service.distance = this.small_device_heigth;
    this.styleMap.port.x2Left = -30;
    this.styleMap.port.x2Right = 50;
    this.styleMap.port.x1Left = 0;
    this.styleMap.port.x1Right = -2;
  }

  setNetworkHeigth(svgHeigth:any) {
    this.styleMap.network.height = svgHeigth;
    this.styleMap.network.nameX = svgHeigth / 2 - 40;
    this.styleMap.network.subnetX = svgHeigth - 110;
    this.styleMap.network.externalX = svgHeigth - 20;
  }


  /* 添加网络节点 */
  fillNetworks(svg:any, networkList:any) {
    let that = this;
    var networkGroup = svg.selectAll('g')
      .data(networkList).enter()
      .append('g')
      .attr('class', 'network')
      .attr('transform', function(d) {
        return 'translate(' + d.networkIndex * that.styleMap.network.networkWidth + ',0)';
      });

    var network = networkGroup.each(function(d, i) {
        that.fillServices(d, i, d3.select(this));
      })
      .append('g')
      .attr('class', 'network_container_small')
      .attr('id', function(d) {
        return d.network_id;
      });

    network.append('rect')
      .attr('class', 'network-rect')
      .attr('rx', that.styleMap.network.rx)
      .attr('ry', that.styleMap.network.ry)
      .attr('width', that.styleMap.network.width)
      .style('cursor', 'pointer')
      .attr('height', that.styleMap.network.height)
      .attr('fill', function(d, i) {
        return that.color(i);
      })
      .on('click', function(d) {
        that.router.navigate(['/project',that.activeProject.id,'network','/net-detail/',d.network_id]);
      });

    network.append('text')
      .attr('class', 'network-name')
      .attr('x', that.styleMap.network.nameX)
      .attr('y', that.styleMap.network.nameY)
      .attr('transform', 'rotate(90 0 0)')
      .attr('pointer-events', 'none')
      .text(function(d) {
        return d.name;
      });

    network.append('text')
      .attr('class', 'network-cidr')
      .attr('x', that.styleMap.network.subnetX)
      .attr('y', that.styleMap.network.subnetY)
      .attr("font-size",10)
      .attr('transform', 'rotate(90 0 0)')
      .text(function(d) {
        if (d.cidr.length > 30) {
          return d.cidr.substring(0, 30) + '...';
        } else {
          return d.cidr;
        }
      });
  }


/* 添加设备节点 */
  fillServices(data:any, index:any, thisObj:any) {
    let that = this;
    var deviceGroup = thisObj.selectAll('g')
      .data(data.services)
      .enter()
      .append('g')
      .attr('class', 'service')
      .attr('transform', function(d) {
        return 'translate(' + that.styleMap.service.leftWidth + ',' + ((d.serviceIndex+1) * that.styleMap.service.distance) + ')';
      });

    var tooltip = d3.select('body')
      .append('div')
      .attr('class', 'tooltip')
      .style('opacity', 0.0);

    deviceGroup.append('image')
      .attr('class', 'frame')
      .style('cursor', 'pointer')
      .attr('width', that.styleMap.service.width)
      .attr('height', that.styleMap.service.height)
      .attr('xlink:href', function(d) {
        return that.styleMap.service.imageService;
      })
      .on('mouseover', function(d) {
        tooltip.html("name: " + d.name)
          .style("left", (d3.event.pageX) + "px")  
          .style("top", (d3.event.pageY + 10) + "px")  
          .style("opacity",1.0);  
      })
      .on('mouseout', function() {
        tooltip.style('opacity', 0.0);
      })
      .on('click', function(d) {
        tooltip.style('opacity', 0.0);
        if(d.type == 'ms'){
          that.router.navigate(['project',that.activeProject.id,'app','msdetail', 'ms_child'],{queryParams:{'id':d.id}});
        }
        else if(d.type == 'srv'){
          that.router.navigate(['project',that.activeProject.id,'app','servicedetail', 'service_child'], {queryParams:{'id':d.id}});
        }
      });

    deviceGroup.each(function(d, i) {
      that.fillPorts(d, i, d3.select(this));
    });
  }
  /* 添加设备节点结束 */


  /* 添加端口节点 */
  fillPorts(data:any, index:any, thisObj:any) {
    let that= this;
    var ports = thisObj.selectAll('g')
      .data(data.ips)
      .enter()
      .append('g')
      .attr('class', 'port')
      .attr('transform', function(d) {
        var lineX = 0;
        var lineY = 0;
        if (d.direction == 'left') {
          lineX = 0;
          //lineY = that.styleMap.service.height / 2;
          lineY = d.leftIndex * ((that.styleMap.service.height - that.styleMap.network.heightExtend) / (d.leftLineNum + 2)) + 5;
        } else {
          lineX = 20;
          lineY = d.rightIndex * ((that.styleMap.service.height + that.styleMap.network.heightExtend) / (d.rightLineNum + 2)) + 5;
        }
        return 'translate(' + lineX + ',' + lineY + ')';
      });

    ports.append('line')
      .attr('class', 'port_line')
      .attr('stroke-width', that.styleMap.port.lineWidth)
      .attr('x1', function(d) {
        if (d.direction == 'left') {
          return that.styleMap.port.x1Left;
        } else {
          return that.styleMap.port.x1Right;
        }
      })
      .attr('y1', that.styleMap.port.y1)
      .attr('y2', that.styleMap.port.y2)
      .attr('x2', function(d) {
        if (d.direction == 'left') {
          return that.styleMap.port.x2Left + (d.linkNetworkIndex - d.networkIndex) * that.styleMap.network.networkWidth - that.styleMap.network.width;
      } else {
          return (d.linkNetworkIndex - d.networkIndex) * that.styleMap.network.networkWidth - that.styleMap.port.x2Right - that.styleMap.network.width;
      }
      })
      .attr('stroke', function(d) {
        return that.color(d.linkNetworkIndex);
    });
  }
        /* 添加端口节点结束 */


}