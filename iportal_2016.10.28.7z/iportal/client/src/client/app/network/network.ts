export class Network {
  public:boolean;
  cidr:string;
  gateway:string;
  name:string;
  network_id:string;
  create_time:string;
  state:string;
  description:string;
  owner:string;
  // constructor(
  //   public cidr:string=null,
  //   public gateway:string=null,
  //   public name:string=null,
  //   public network_id:string=null,
  //   public create_time:string=null,
  //   public state:string=null,
  //   public description:string=null,
  //   public owner:string=null,
  //   public public:boolean=null
  //   ){ 
  // }
}
