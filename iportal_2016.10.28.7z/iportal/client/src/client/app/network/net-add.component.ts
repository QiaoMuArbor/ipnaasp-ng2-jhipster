import { Component, ViewChild } from '@angular/core';
import { Router, ActivatedRoute,ROUTER_DIRECTIVES } from '@angular/router';
import { Network } from './network';
import { NetworkService } from './network.service';
import { ActiveProjectService } from '../app.service';
import { EventBroadcastService } from '../shared/index';
import { TOOLTIP_DIRECTIVES } from 'ng2-bootstrap/ng2-bootstrap';

@Component({
  moduleId: module.id,
  selector: 'net-add',
  directives: [ROUTER_DIRECTIVES, TOOLTIP_DIRECTIVES],
  templateUrl: 'net-add.component.html',
  styles: [`
    .lablename{
      width:100px;
    }
    .helpp{
    height: 20px;
    background-color: #1898EB;
    display: inline-block;
    width: 20px;
    vertical-align: middle;
    border-radius: 50%;
    color: #fff;
    text-align: center;
    margin-right: 5px;
    }
  `],
  providers:[NetworkService]
})

export class NetAddComponent {
  public network: Network = new Network();
  isOnFocus : any;
  isLoading : boolean = false;
  constructor(private activeProject: ActiveProjectService, private router: Router, private networkService: NetworkService,private eventBroadcastService: EventBroadcastService) {
    this.isOnFocus = {
      'name' : false,
      'cidr' : false,
      'des' : false
    }
    this.network.public = false;
  }

  ngOnInit() {

  }

  createNet(isValid: boolean): boolean{
    if (!isValid) {
      return false;
    }
    this.isLoading = true;
    let that =this;
    that.networkService.addNetwork(that.network).subscribe(
      res=>{
        that.isLoading = false;
        that.eventBroadcastService.broadcastSuccess('创建成功!');
        that.router.navigate(['/project',that.activeProject.id,'network']);
      },
      error => {
        that.isLoading = false;
        that.eventBroadcastService.broadcastError(error.message);}
      );
    return true;
  }

  cancel(){
    this.router.navigate(['/project',this.activeProject.id,'network']);
  }

  modifyPubNet(isPub:boolean){
    this.network.public = !isPub;
  }

}
