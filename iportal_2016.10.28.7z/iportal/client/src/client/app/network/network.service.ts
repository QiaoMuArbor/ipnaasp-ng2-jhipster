// Observable Version
import { Injectable }     from '@angular/core';
import { Observable }     from 'rxjs/Observable';
import { Network } from './network';
import { AuthHttp } from '../shared/index';
import {ActiveProjectService} from '../app.service';



@Injectable()
export class NetworkService{
  private networkUrlNew = '';
  private vnpmUrl = '';
  constructor(private http: AuthHttp, private activeProject: ActiveProjectService) {
    this.vnpmUrl = '/api/vnpm_deploy/v1/tenants/' + this.activeProject.id;
    this.networkUrlNew = '/api/nw/v1/tenants/' + this.activeProject.id + '/' + 'networks';
  }

  getNetworks(){
    return this.getNetworksInterface();
  }

  getNetworksInterface(){
    return this.http.get(this.networkUrlNew).map(res=>{
      var nets: any[] = res.networks;
      var netsObj : any = {'networks':[]};
      nets = _.sortBy(nets, function(net){
        return net.name;
      });
      nets = _.sortBy(nets, function(net){
        return Date.parse(net.create_time);
      });
      netsObj.networks = nets;
      return netsObj;
    });
  }

  addNetwork (network: Network){
    return this.http.post(this.networkUrlNew, {'network':network});
  }

  delete(netid: string) {
    return this.http.delete(this.networkUrlNew+'/'+netid);
  }

  getNetworkDetail(netid: string): Observable<Network> {
    return this.http.get(this.networkUrlNew + '/' + netid).map(res=>{
      return res.network;
    });
  }

  getVnpmServiceList(serviceType:string){
    let that = this;
    let listUrl: string = '';
    if(serviceType == 'srv') { 
      listUrl = that.vnpmUrl + '/' + 'services';
    } 
    else if(serviceType == 'ms'){
      listUrl = that.vnpmUrl + '/' + 'microservices';
    }
    else{
      listUrl = '';
    }
    return Observable.create((observer:any) =>{
    that.http.get(listUrl).subscribe(res=>{
      let tmpList :any[]= [];
      if(serviceType == "ms") {
        tmpList = res.ms_list;
      }
      else if(serviceType == "srv"){
        tmpList = res.srv_list;
      }
      observer.next(tmpList);
      observer.complete();
      },error=>{
        observer.next([]);
        observer.complete();
      });
    });
  }

  handleVnmpNetData(msNetworkDetail:any){
    var netList: any[] = [];
    // netList = _.values(msNetworkDetail.network_list);
    // netList = _.map(netList, function(net){
    //   return net.split(',');
    // });
    // netList = _.flatten(netList);
    // netList = _.map(netList, function(net){
    //   var netInfo: any = {'network_plane_name': ''};
    //   netInfo.network_plane_name = net;
    //   return netInfo;
    // });
    for(let net of msNetworkDetail){
      var netInfo: any = {'network_plane_name': ''};
      netInfo.network_plane_name = net.attach_to_network;
      netList.push(netInfo);
    }
    return netList;
  }

  getVnpmNetDetail(serviceType:string, service_id:any){
    var servivedetail:any = {};
    var netData:any[] = [];
    let that = this;
    let serviceDetailUrl: string = '';
    if(serviceType == 'srv') { 
      serviceDetailUrl = that.vnpmUrl + '/' + 'services' + '/' + service_id;
    } 
    else if(serviceType == 'ms'){
      serviceDetailUrl = that.vnpmUrl + '/' + 'microservices' + '/' + service_id;
    }
    else{
      serviceDetailUrl = '';
    }
    return that.http.get(serviceDetailUrl).map(res=>{
        netData = that.handleVnmpNetData(res.deploy_config.networks.ports);
        servivedetail.ips = netData;
        servivedetail.name = res.deploy_name;
        servivedetail.id = service_id;
        servivedetail.type = serviceType;
        return servivedetail;
      });
  }

  getVnpmServiceNet(serviceType:string){
    let that = this;
    return that.getVnpmServiceList(serviceType).flatMap(res=>{
        return Observable.from(res);
    })
    .flatMap(res=>{
      if(serviceType == "ms") {
        return that.getVnpmNetDetail(serviceType, res.ms_ins_id);
      }
      else if(serviceType == "srv"){
        return that.getVnpmNetDetail(serviceType, res.srv_ins_id);
      }
      else{
        return Observable.create((observer:any) =>{
          observer.next({});
          observer.complete();
        });
      }
    });
  }

  sortNetworklist(netslist:any[]): any[] {
    netslist = _.map(netslist, function(net, index){
      net.networkIndex = index;
      net.services = [];
      return net;
    });
    return netslist;
  }

  sortServices(services:any[], netslist:any[]): any[] {
    let that = this;
    services = _.filter(services, function(service){
      return service.ips.length != 0;
    });
    services = _.map(services, function(service, index){
      service.serviceIndex = index;
      service.ips = that.sortIps(service.ips, netslist);
      return service;
    });
    return services;
  }

  sortIps(ips:any[], netslist:any[]): any[] {
    let ipsTmp:any[] = ips;
    let mainNet: any;
    ipsTmp = _.filter(ipsTmp, function(ip){
      let flag = _.find(netslist, function(net){
        return net.name == ip.network_plane_name;
      });
      return flag == undefined;
    });

    ips = _.difference(ips, ipsTmp);

    mainNet = _.find(netslist, function(net){
      return net.name == ips[0].network_plane_name;
    });
    let leftLineNum:number = 0;
    let rightLineNum:number = 0;
    ips = _.map(ips, function(ip, index){
      ip.lineIndex = index;
      ip.networkIndex = mainNet.networkIndex;
      for(let net of netslist){
        if(ip.network_plane_name == net.name){
          ip.linkNetworkIndex = net.networkIndex;
        }
      }
      if(ip.linkNetworkIndex <= ip.networkIndex) {
        ip.direction = 'left';
        ip.leftIndex = leftLineNum;
        leftLineNum = leftLineNum + 1;
      }
      else{
        ip.direction = 'right';
        ip.rightIndex = rightLineNum;
        rightLineNum = rightLineNum + 1;
      }
      return ip;
    });
    ips = _.map(ips, function(ip){
      ip.leftLineNum = leftLineNum;
      ip.rightLineNum = rightLineNum;
      return ip;
    });
    return ips;
  }

  getServiceInfo(){
    let that = this;
    var serviveObj:any = {'services': []};
    return Observable.merge(that.getVnpmServiceNet("ms"), that.getVnpmServiceNet("srv")).toArray().map(res=>{
      serviveObj.services = res;
      return serviveObj;
    });
  }

  getTopoData(){
    let that = this;
    return Observable.merge(that.getNetworksInterface(), that.getServiceInfo()).toArray().map(res=>{
      let netslist : any = [];
      let services: any = [];
      let netsTopo = {};
      if(res[0].networks == undefined){
        netslist = res[1].networks;
        services = res[0].services;
      }
      else{
        netslist = res[0].networks;
        services = res[1].services;
      }
      netsTopo.networkNum = netslist.length;
      netsTopo.serviceNum = services.length;

      netslist = this.sortNetworklist(netslist);
      if(netsTopo.serviceNum != 0){
        services = this.sortServices(services,netslist);
      }
      netslist = _.map(netslist, function(net){
        for(let service of services){
          if(service.ips[0].networkIndex == net.networkIndex) {
            net.services.push(service);
          }
        }
        return net;
      });
      netsTopo.networkList = netslist;
      return netsTopo;
    });
  }

}
