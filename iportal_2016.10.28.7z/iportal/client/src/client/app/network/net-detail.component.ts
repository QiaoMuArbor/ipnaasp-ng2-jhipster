import { Component, ViewChild} from '@angular/core';
import { Network } from './network';
import { NetworkService } from './network.service';
import { ActivatedRoute, Router,ROUTER_DIRECTIVES } from "@angular/router";
import { MODAL_DIRECTIVES, ModalComponent } from 'ng2-bs3-modal/ng2-bs3-modal';
import { EventBroadcastService, ISOLocalPipe, LogISOLocalPipe, NetStatePipe} from '../shared/index';
import { ActiveProjectService } from '../app.service';


@Component({
  moduleId:module.id,
  selector: 'net-detail',
  providers:[NetworkService],
  directives:[ROUTER_DIRECTIVES, MODAL_DIRECTIVES],
  templateUrl: 'net-detail.component.html',
  styleUrls:['net-detail.component.css'],
  pipes:[ISOLocalPipe, LogISOLocalPipe, NetStatePipe]
})

export class NetDetailComponent {
  @ViewChild('modal') modal: ModalComponent;
  network : Network = new Network();
  constructor(private networkService :NetworkService, private router:Router, private route: ActivatedRoute, private activeProject: ActiveProjectService, private eventBroadcastService :EventBroadcastService) {
  }

  ngOnInit() {
    let netid : string = this.route.snapshot.params['netid'];
    this.getNetwork(netid);
  }

  getNetwork(netid: string){
    let that = this;
    that.networkService.getNetworkDetail(netid).subscribe(network=>{
      if(network.public == true) {
        network.public = "public";
      }
      else{
        network.public = "private";
      }
      that.network = network;
    });
  }

  delNetwork(netid: string){
    let that = this;
    this.networkService.delete(netid).subscribe(
      res=>{
        that.modal.close();
        that.eventBroadcastService.broadcastSuccess('网络删除成功！');
        that.router.navigate(['/project',that.activeProject.id,'network']);
      },
      error => {
        that.modal.close();
        that.eventBroadcastService.broadcastError(error.message);
      }
    )
  }

  cancel(){
    window.history.back();
  }

}
