/**
 * Created by zte on 16-8-4.
 */
import {Component} from '@angular/core';
import { HeaderMenuComponent } from './header/header-menu.component';

@Component({
  moduleId: module.id,
  selector: 'about',
  directives: [HeaderMenuComponent],
  template: `
    <header-menu [isCentered]="true"></header-menu>
    <h1 style="margin-top: 60px;">LastCommitId:47fad4b70da183bc59638b1e15f822524adee81d<br>Date:   Thu Oct 20 17:21:20 2016 +0800 <br>Branch:master <br>Version</h1> 
  `
})

export class AboutComponent {

}
