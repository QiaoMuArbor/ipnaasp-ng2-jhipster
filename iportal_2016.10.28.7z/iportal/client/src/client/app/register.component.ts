/**
 * Created by zte on 16-8-4.
 */
import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { Http } from '@angular/http';
import { EventBroadcastService } from './shared/index';

@Component({
  moduleId: module.id,
  selector: 'register',
  template: `
  <div class="login">
  <img class="login-logo" src="../images/login-logo.svg" alt="OpenPalette"/>
    <form class="login-form" #loginForm="ngForm" (ngSubmit)="register()">
        <div class="item-line">
          <input type="text" [(ngModel)]="user.userName" minlength="3" maxlength="64" required name="name" #name="ngModel" placeholder="用户名"/>
          <i class="fa fa-check-circle form-ic-success" *ngIf="name.valid"></i>
          <label *ngIf="((loginForm.submitted||name.dirty||!name.untouched)&&!name.valid)" class="form-error">
            <i class="fa fa-times-circle form-ic-error" aria-hidden="true"></i>
            <span *ngIf="name.errors.minlength">用户名长度为3-64个字符</span>
            <span *ngIf="name.errors.required">用户名不能为空</span>
          </label>
        </div>
        <div class="item-line">
          <input type="password" [(ngModel)]="user.password" minlength="6" maxlength="32" required name="password1" #password1="ngModel" placeholder="密码"/>
          <i class="fa fa-check-circle form-ic-success" *ngIf="password1.valid"></i>
          <label *ngIf="((loginForm.submitted||password1.dirty||!password1.untouched)&&!password1.valid)" class="form-error">
            <i class="fa fa-times-circle form-ic-error" aria-hidden="true"></i>
            <span *ngIf="password1.errors.minlength">密码长度为6-32个字符</span>
            <span *ngIf="password1.errors.required">密码不能为空</span>
          </label>
        </div>
        <div class="item-line">
          <input type="password" [(ngModel)]="passwordRetry" minlength="6" maxlength="32" required name="password2" #password2="ngModel" placeholder="确认密码"/>
          <i class="fa fa-check-circle form-ic-success" *ngIf="password2.valid"></i>
          <label *ngIf="((loginForm.submitted||password2.dirty||!password2.untouched)&&!password2.valid)" class="form-error">
            <i class="fa fa-times-circle form-ic-error" aria-hidden="true"></i>
            <span *ngIf="password2.errors.minlength">密码长度为6-32个字符</span>
            <span *ngIf="password2.errors.required">密码不能为空</span>
          </label>
        </div>
        <div class="item-line">
          <input type="text" [(ngModel)]="user.name" minlength="1" maxlength="64" name="name2" #name2="ngModel" placeholder="姓名"/>
          <i class="fa fa-check-circle form-ic-success" *ngIf="name2.dirty&&name2.valid"></i>
        </div> 
        <div class="item-line">
          <input type="email" [(ngModel)]="user.email" name="email" #email="ngModel" pattern="^[a-z0-9]+([._\\-]*[a-z0-9])*@([a-z0-9]*[-a-z0-9]*[a-z0-9]+.){1,63}[a-z0-9]+$" placeholder="电子邮箱"/>
          <i class="fa fa-check-circle form-ic-success" *ngIf="email.dirty&&email.valid"></i>
          <label *ngIf="((loginForm.submitted||email.dirty||!email.untouched)&&!email.valid)" class="form-error">
            <i class="fa fa-times-circle form-ic-error" aria-hidden="true"></i>
            <span *ngIf="email.errors.pattern">电子邮箱格式错误</span>
          </label>
        </div> 
        <div class="btn-area">
          <button type="submit" class="modal-btn-confirm login-btn" *ngIf="!registing">注&nbsp;&nbsp;&nbsp;册</button>
          <button type="submit" class="modal-btn-confirm login-btn" *ngIf="logining" [disabled]="registing">注&nbsp;&nbsp;&nbsp;册&nbsp;&nbsp;&nbsp;中</button>
          <a href="javascript:;" (click)="gotoLogin()" class="cancel-btn" *ngIf="!registing">取&nbsp;&nbsp;&nbsp;消</a>
        </div>
    </form>
  </div>
  `,
  styles:[`
  div.login {
      width: 600px;
      margin: 0 auto;
      text-align: center;
      margin-top: 10%;
  }
  img.login-logo{
    width: 300px;
  }
  .login h1{
    font-size: 48px;
    color: #1898EB;
    margin-bottom: 30px;
  }
  .login-form i.form-ic-success,
  .login-form label.form-error{
    position: absolute;
    margin-left: 10px;
    margin-top: 6px;
  }
  a.cancel-btn,
  button.login-btn{
  width: 125px;
  height: 32px;
  margin-right: 0;
  font-size: 16px;
  margin-left: 4px;
  }
  a.cancel-btn{
    display: inline-block;
    margin-left: 50px;
  }
`]
})

export class registerComponent {
  private passwordRetry:string;
  private registing:boolean;
  private user:any = {userName:'',password:'',name:'',email:''};
  constructor(private eventBroadcastService:EventBroadcastService,
              private http:Http,private router: Router) {
    this.registing=false;
  }

  gotoLogin = function(){
    this.router.navigate(['/login']);
  }

  checkPassword = function(){
    if(this.user.password !== this.passwordRetry){
      this.eventBroadcastService.broadcastError("两次输入的密码不相同，请重新输入！");
      return false;
    }
    return true;
  }

  register(){
    if(!this.checkPassword()){
      return;
    };
    let that=this;
    this.registing=true;
    this.http.post('/api/user/v1/users',this.user)
      .subscribe(res=>{
        that.registing=false;
        that.gotoLogin();
      },err=>{
        that.registing=false;
        that.eventBroadcastService.broadcastError(err.message);
      });
  }
}
