import { Injectable }     from '@angular/core';
import { Http, Response } from '@angular/http';
import { Headers, RequestOptions } from '@angular/http';
import { Observable }     from 'rxjs/Observable';
import { AuthHttp } from '../../shared/http/auth-http.service';
import { framework } from './framework';
import { ActiveProjectService } from '../../app.service';

@Injectable()
export class FrameworkService{
  private frameworkUrl = '/api/dev/v1/tenants/';  // URL to web API
  constructor(private http: AuthHttp,private activeProject:ActiveProjectService) {
    this.frameworkUrl+=this.activeProject.id+'/';
  }

  getFramewokrs (): Observable<any> {
    return this.http.get(this.frameworkUrl+'frameworks');
  }

  getFramewokr(id: string): Observable<any>{
    return this.http.get(this.frameworkUrl+'frameworks/'+id);
  }

  addFramework(frameworks:framework): Observable<any> {
    let that =this;
    return that.http.post(that.frameworkUrl+'frameworks',frameworks)
      .map(res=> {
        return res;
      })
      .catch(that.handleError);
  }

  deleteFramework(id:string){
    return this.http.delete(this.frameworkUrl+'frameworks/'+id);
  }

  updateFramework(frameworks:framework): Observable<any> {
    return this.http.put(this.frameworkUrl+'frameworks/'+frameworks.uuid,frameworks);
  }

  handleError (error: any) {
    let errMsg:string;
    if(error.message) { 
       errMsg = error.message;
    } else {
       errMsg = (error.message) ? error.message :
            error.status ? `${error.status} - ${error.statusText}` : 'Server error';
    }
   
    
    return Observable.throw({message:errMsg,status:error.status});
  }
}