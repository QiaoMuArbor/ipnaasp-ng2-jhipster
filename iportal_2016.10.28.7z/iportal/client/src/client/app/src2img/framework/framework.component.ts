import { Component, Input, Output, EventEmitter } from '@angular/core';
import { FrameworkService } from './framework.service';
import { EventBroadcastService } from '../../shared/index';
import { codebuild, codebuildinfoview } from '../src2img';
import { framework } from './framework';

@Component({
  moduleId:module.id,
  selector: 'framework',
  templateUrl:'framework.component.html' ,
  styleUrls:['framework.component.css'],
  providers:[FrameworkService]
})

export class FrameworkComponent {
  private frameworks:framework[]=[];
  private curframe:any;
  private sign:string;
  private imageinfo:string;
  @Output('selectframe') emitframework = new EventEmitter();
  @Input ('currentframe') set choosecurrent(currentframe:string) {
    this.sign = currentframe;
    if(currentframe&&this.frameworks.length!=0){
      this.curframe = _.findWhere(this.frameworks,{'uuid':currentframe});
      this.selectframework(this.curframe);
    }
  };
  constructor(private frameworkService:FrameworkService,
              private eventBroadcastService :EventBroadcastService) {
  }

  ngOnInit() {
    this.getframes();
  }

  getframes() {
    let that = this;
    this.frameworkService.getFramewokrs().subscribe(res=>{
      that.frameworks = res.frameworks;
      if(this.sign){
        this.curframe = _.findWhere(this.frameworks,{'uuid':this.sign});
        this.selectframework(this.curframe);
      }
      else if(that.frameworks.length){
        that.curframe = that.frameworks[0];
        that.selectframework(that.curframe);
      }
    },err=>{
      that.eventBroadcastService.broadcastError('获取开发框架失败');
    });
  }

  selectframework(frame:framework) {
    this.emitframework.emit(frame);
  }

  trackByframeworks(index:number,framework:any) {
    return framework.name;
  }
  showimage(frame:framework){
    if(frame.isonebaseimage)
    this.imageinfo="基础镜像:"+frame.baseimage.tenantid+'/'+frame.baseimage.name+':'+frame.baseimage.version;
    else
    this.imageinfo="基础镜像:"+frame.baseimage.tenantid+'/'+frame.baseimage.name+':'+frame.baseimage.version+' '+frame.runbaseimage.tenantid+'/'+frame.runbaseimage.name+':'+frame.runbaseimage.version;
    return this.imageinfo;
  }
  

}