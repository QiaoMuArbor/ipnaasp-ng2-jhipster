export class framework{
	public name:string='';
	public uuid:string='';
	public description:string='';
	public language:string='';
  public icon:string='';
	public type:string='';
	public isonebaseimage:boolean = true;
	public imagedescfile:string='';
	public baseimage:{tenantid:string,name:string,version:string}={'tenantid':'','name':'','version':''};
	public runbaseimage:{tenantid:string,name:string,version:string}={'tenantid':'','name':'','version':''};
	public creator:string='';
	public createtime:string='';
	public updatetime:string='';
}