import { Pipe, PipeTransform } from '@angular/core';
@Pipe({ name: 'Src2ImgStatusToChinese' })
export class Src2ImgStatusToChinese implements PipeTransform {
  transform(value:any) {
    if (!value) {return null;}
    if (!isNaN(value)) {value = value;}
    let statusOragin:string = value;
    let status = statusOragin.toLowerCase();
    return this.transferToChinese(status);
  }

  transferToChinese(status:string):any{
    let result:string = "查询中";
   switch (status) {
      case "initial":result="初始化";break;
      case "running":result="构建中";break;
      case "success":result="成功";break
      case "fail":result="失败";break;
      case "pending":result="排队中";break;
      default: result = status;break
    }
    return result;

  }
}

