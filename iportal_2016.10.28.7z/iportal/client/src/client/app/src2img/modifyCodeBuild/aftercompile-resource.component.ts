import {Component, Input, Output, EventEmitter} from '@angular/core';
import { codebuildinfo } from '../src2img';

@Component({
	moduleId: module.id,
	selector: 'afterCompileInfo',
	styleUrls:['modify-resource.component.css'],
	templateUrl: 'aftercompile-resource.component.html',
})

export class AfterCompileResoureComponent {
	@Input() cbinfo:codebuildinfo;

}