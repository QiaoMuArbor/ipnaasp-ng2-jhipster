import { Component, ViewChild } from '@angular/core';
import { Src2imgService } from '../src2img.service';
import { EventBroadcastService, ISOLocalPipe } from '../../shared/index';
import { MODAL_DIRECTIVES, ModalComponent } from 'ng2-bs3-modal/ng2-bs3-modal';
import { codebuild, codebuildinfo } from '../src2img';
import { ROUTER_DIRECTIVES,Router,ActivatedRoute } from '@angular/router';
import { ActiveProjectService } from '../../app.service';
import { Headers, Http, Response} from '@angular/http';
import { BaseInfoResoureComponent} from './baseinfo-resource.component';
import { CodeRepositoryResoureComponent} from './coderepository-resource.component';
import { BuildInfoResoureComponent} from './buildinfo-resource.component';
import { AfterCompileResoureComponent} from './aftercompile-resource.component';


@Component({
  moduleId:module.id,
  selector: 'cb-modify',
  templateUrl:'modify-codebuild.component.html' ,
  styleUrls:['modify-resource.component.css'],
  directives:[MODAL_DIRECTIVES,ROUTER_DIRECTIVES,BaseInfoResoureComponent,CodeRepositoryResoureComponent,
              BuildInfoResoureComponent,AfterCompileResoureComponent],
  pipes:[ISOLocalPipe],
  providers:[Src2imgService]
})

export class ModifyCodeBuildComponent {
  public codebulids:codebuild[];
  private cbinfo:codebuildinfo;
  private id:string;
  public staticcheck:boolean;
  public cyclomaticcomplexity:boolean;
  public unittest:boolean;

  public showflag:boolean;
  public edit:boolean = false;

  public selectId:number ;
  public index:number;
  public gitcfg:{giturl:string,branch:string,clonedir:string,monitorchange:boolean,triggersubdir:string};
  public gitcfgs:{giturl:string,branch:string,clonedir:string,monitorchange:boolean,triggersubdir:string}[] =[];
  @ViewChild('modal') modal: ModalComponent;
  constructor(private src2imgService:Src2imgService,
              private eventBroadcastService :EventBroadcastService,
              private router:Router,
              private activeProjectService:ActiveProjectService,
              private route:ActivatedRoute,
              private _http: Http) {
  }
  ngOnInit() {
    this.id = this.router.routerState.parent(this.route).params.value.id;
    this.cbinfo = new codebuildinfo();
    this.getcodebuild();
    this.showflag=true;
    this.gitcfg={'giturl':'','branch':'master','clonedir':'','monitorchange':true,'triggersubdir':''};
  }

  getcodebuild() {
    this.src2imgService.getCodeBuild(this.id).subscribe(res=>{
      this.cbinfo = res;
      this.gitcfgs = res.gitcfg;
      console.log(this.gitcfgs);
    },err=>{
      this.eventBroadcastService.broadcastError('获取构建信息失败');
    })
  }

  setcodebuild() {
    this.cbinfo.gitcfg=this.gitcfgs;
    this.src2imgService.putCodeBuild(this.cbinfo).subscribe(res=>{
      this.eventBroadcastService.broadcastSuccess('更新成功');
      this.router.navigate(['../log'],{relativeTo:this.route});
    },err=>{
      this.eventBroadcastService.broadcastError('更新失败,请重试');
    });
  }

  onSubmit() {
    this.setcodebuild();
  }
  backtocblist() {
    this.router.navigate(['../../../list'],{relativeTo:this.route});
  }
}
