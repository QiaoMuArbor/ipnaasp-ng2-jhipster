import {Component, Input, Output, EventEmitter} from '@angular/core';

@Component({
	moduleId: module.id,
	selector: 'coderepository',
	directives:[],
	styleUrls:['modify-resource.component.css'],
	templateUrl: 'coderepository-resource.component.html',
})

export class CodeRepositoryResoureComponent {
	@Input() gitcfg:{giturl:string,branch:string,clonedir:string,monitorchange:boolean,triggersubdir:string};
	@Input() gitcfgs:{giturl:string,branch:string,clonedir:string,monitorchange:boolean,triggersubdir:string}[] =[];
  
  public index:number;

  addsubgit(gitcfg:{giturl:string,branch:string,clonedir:string,monitorchange:boolean,triggersubdir:string}) {
    this.gitcfgs.push(gitcfg);
    this.gitcfg={'giturl':'','branch':'','clonedir':'','monitorchange':true,'triggersubdir':''};
  }

  deletesubgit(gitcfg:{giturl:string,branch:string,clonedir:string,monitorchange:boolean,triggersubdir:string}) {
    this.gitcfgs = _.filter(this.gitcfgs, function(item){ 
      return (item.giturl != gitcfg.giturl)||(item.branch != gitcfg.branch)||(item.clonedir != gitcfg.clonedir)||(item.monitorchange != gitcfg.monitorchange)||(item.triggersubdir != gitcfg.triggersubdir)
    });
  }

    getclonedir(search:string,config:{giturl:string,branch:string,clonedir:string,monitorchange:boolean,triggersubdir:string}) {
    this.index= search.lastIndexOf('/');
    if(this.index!=-1) {
      config.clonedir=search.substring(this.index+1,search.length);
    }else{
      config.clonedir='';
    }
    }

}