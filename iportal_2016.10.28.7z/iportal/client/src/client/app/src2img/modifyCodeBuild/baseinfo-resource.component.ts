import {Component, Input, Output, EventEmitter} from '@angular/core';
import { codebuildinfo } from '../src2img';
import { framework,FrameworkComponent } from '../framework/index';

@Component({
	moduleId: module.id,
	selector: 'baseInfo',
	directives:[FrameworkComponent],
	styleUrls:['modify-resource.component.css'],
	templateUrl: 'baseInfo-resource.component.html',
})

export class BaseInfoResoureComponent {
	@Input() cbinfo:codebuildinfo;
	 private isonebaseimage = true;
	 private frameworks:framework[];

  selectframework(frame:framework) {
    this.cbinfo.frameworkcfg.frameworkuuid = frame.uuid;
    this.isonebaseimage = frame.isonebaseimage;
  }
}