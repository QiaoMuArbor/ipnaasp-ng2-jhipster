import {Component, Input, Output, EventEmitter} from '@angular/core';
import {codebuildinfo } from '../src2img';

@Component({
	moduleId: module.id,
	selector: 'buildInfo',
	styleUrls:['modify-resource.component.css'],
	templateUrl: 'buildinfo-resource.component.html',
})

export class BuildInfoResoureComponent {
	@Input() cbinfo:codebuildinfo;

}