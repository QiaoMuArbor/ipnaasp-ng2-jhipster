/**
 * Created by zte on 16-8-15.
 */
import { RouterConfig } from '@angular/router';
import { Src2imgComponent } from './src2img.component';
import { CodeBuildComponent } from './codebuild.component';
import { CodeBuildDetailComponent } from './codebuild-detail.component';
import { CodeBuildModifyComponent } from './codebuild-modify.component';
import { CodebuildLogComponent } from './codebuild-log.component';
import {CreateCodeBuildComponent} from'./createCodeBuild/create-codebuild.component';
import {ModifyCodeBuildComponent} from'./modifyCodeBuild/modify-codebuild.component'

export const Src2imgRoutes: RouterConfig = [

  {
    path: 'src2img',
    children: [
      {
        path: '',
        redirectTo: 'list',
        pathMatch:'full'
      },
      {
        path: 'list',
        component:Src2imgComponent,
      },
      {
        path: 'codebuilds',
        children: [
          {
            path: '',
            redirectTo: 'create',
            pathMatch:'full'
          },
          {
            path: 'create',
            component:CodeBuildComponent,
          },
          {
            path:'newCreate',
            component:CreateCodeBuildComponent,
          },
          {
            path: ':id',
            component: CodeBuildDetailComponent,
            children:[
              {
                path: '',
                redirectTo: 'modify',
                pathMatch:'full'
              },
              {
                path: 'modify',
                component:CodeBuildModifyComponent,
              },
                {
                path: 'newmodify',
                component:ModifyCodeBuildComponent,
              },
              {
                path: 'log',
                component:CodebuildLogComponent,
              },
            ]
          }
        ]
      }
    ]
  }
];


