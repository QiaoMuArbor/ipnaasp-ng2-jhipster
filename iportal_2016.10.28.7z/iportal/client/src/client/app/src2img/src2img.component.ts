import { Component, ViewChild } from '@angular/core';
import { Src2imgService } from './src2img.service';
import { EventBroadcastService, ISOLocalPipe } from '../shared/index';
import { ActiveProjectService } from '../app.service';
import { MODAL_DIRECTIVES, ModalComponent } from 'ng2-bs3-modal/ng2-bs3-modal';
import { codebuild, onebuild } from './src2img';
import { ROUTER_DIRECTIVES,Router, ActivatedRoute } from '@angular/router';
import { Src2ImgStatusToChinese } from './src2img-status-tochinese.pipe';

@Component({
  moduleId:module.id,
  selector: 'src2img',
  templateUrl:'src2img.component.html',
  styleUrls:['src2img.component.css'],
  directives:[MODAL_DIRECTIVES,ROUTER_DIRECTIVES],
  pipes:[ISOLocalPipe,Src2ImgStatusToChinese],
  providers:[Src2imgService]
})

export class Src2imgComponent {
  public codebulids:codebuild[];
  public savecodebuilds:codebuild[];
  public istrue:boolean=true;
  public searchtext:string;
  @ViewChild('modal') modal: ModalComponent;
  public time:any;
  constructor(private src2imgService:Src2imgService,
              //private src2imgClientService:Src2imgClientService,
              private eventBroadcastService :EventBroadcastService,
              private activeProjectService:ActiveProjectService,
              private router:Router,
              private route:ActivatedRoute) {
  }
  ngOnInit() {
    this.codebulids = []; 
    this.getcodebulids();
    this.freashcodebuilds();
  }
  getcodebulids() {;
    let that = this;
    this.src2imgService.getCodeBuilds().subscribe(
      (res:{codebuildlist:codebuild[]})=>{
        if(!res.codebuildlist){
          res.codebuildlist=[];
        }
        that.savecodebuilds = res.codebuildlist;
        that.codebulids = res.codebuildlist;
      },error=>{
        this.eventBroadcastService.broadcastError('获取列表失败');
      })
  }
  delCodeBuild(id:string) {
    let that = this;
    this.src2imgService.delete(id).subscribe((res:any)=>{
      that.modal.close();
      that.eventBroadcastService.broadcastSuccess('删除成功');
      that.getcodebulids();
    },(error:any)=>{
      that.modal.close();
      that.eventBroadcastService.broadcastError('删除失败');
    })
  }
  oneBuild(id:string,imagename:string) {
    let build:onebuild = {'imagename':imagename,'uuid':id,'tenantid':this.activeProjectService.id};
    this.src2imgService.oneBuild(id,build).subscribe(
      res=>{
        this.eventBroadcastService.broadcastSuccess('开始构建');
        this.router.navigate(['../codebuilds',id,'/log'],{relativeTo:this.route});
      },err=>{
        this.eventBroadcastService.broadcastError('构建失败,请重试');
      });   
  }
  freashcodebuilds() {
    this.time = setInterval(()=>{this.getcodebulids()},5000);
  }
  codebuildsearch(search:string) {
    this.codebulids = _.filter(this.savecodebuilds,function(codebuild){
      return codebuild.imagename.indexOf(search)!=-1;
    });
  }
  trackBycodebuilds(index:number,codebuild:any) {
    return codebuild.uuid;
  }
  ngOnDestroy() {
    clearInterval(this.time);
  }
}
