export class codebuild {
	public imagename:string;
	public uuid:string;
	public tenantuuid:string;
	public lastbuildtime:string;
	public duration:string;
	public lastbuildstatus:string;
	public updatetime:string;
	public waitqueue:{
					triggertime:string;             
					type:string;
					}[];                     
}
export class createCodeBuild{
	public imageName:string='';
	public imageVersion:string='';
	public imageDescription:string='';

	public frameworkUuid:string = '';

	public gitCfg:{gitUrl:string,branch:string,cloneDir:string,monitorChange:boolean,triggerSubdir:string}[]=[];

	public buildScriptName:string='';

	//public buildimagetype:string =""; //auto  dockerfile

	public ifAuto:boolean = false;
	public auto:{installfilesdir:string,installscript:string,runscript:string} 
				={'installfilesdir':'','installscript':'','runscript':''};

	public dockerfiledir:string =""; 

	public ifContinueBuild:boolean = false;


	public ifStaticCheck:boolean = false;
	public staticcheck:{script:string ,resultfile:string} 
	  ={'script':'' ,'resultfile':''};

	public ifCyclomaticComplexity:boolean = false;
	public cyclomaticcomplexity:{script:string ,resultfile:string} 
	  ={'script':'' ,'resultfile':''}; 

	public ifUnitTest:boolean = false;
	public unittest:{script:string ,coveragestaticfile:string,testcasestaticfile:string} 
	  ={'script':'' ,'coveragestaticfile':'','testcasestaticfile':''}; 

}
export class codebuildBody {
    
	public tenantid:string = '';
	public builduuid:string = '';
	public buildimage:{tenantid:string,name:string,version:string}
	     = {'tenantid':'','name':'','version':''};
	public description:string = '';
	public isonebaseimage:boolean = true;     
	public frameworkcfg:{ frameworkuuid:string, tenantid:string }
		={'frameworkuuid':'', 'tenantid':''};
	public gitcfg:{giturl:string,branch:string,clonedir:string,monitorchange:boolean,triggersubdir:string}[]
			=[{'giturl':'','branch':'','clonedir':'','monitorchange':true,'triggersubdir':''}];
	          
	public buildscript:string='';
	public buildimagetype:string ="";
	public installfilesdir:string ="";
	public installscript:string ="";
	public runscript:string ="";
	public dockerfiledir:string ="";
	public imagedescfile:string ="";
	public staticcheck:{isused:boolean ,script:string ,resultfile:string} 
	  ={'isused':false , 'script':'' ,'resultfile':''};
	public cyclomaticcomplexity:{isused:boolean ,script:string ,resultfile:string} 
	  ={'isused':false , 'script':'' ,'resultfile':''}; 
	public unittest:{isused:boolean ,script:string ,coveragestaticfile:string,testcasestaticfile:string} 
	  ={'isused':false , 'script':'' ,'coveragestaticfile':'','testcasestaticfile':''}; 
	public continousintegration:boolean = false; 	                 

}
export class codebuildinfoview {
	public tenantid:string= '';
	public builduuid:string = '';
	public buildimage:{tenantid:string,name:string,version:string} = {'tenantid':'','name':'','version':''};
	public description:string='';
	public frameworkcfg:{frameworkuuid:string,tenantid:string}={'frameworkuuid':'','tenantid':''};
	public gitcfg:{giturl:string,branch:string,clonedir:string,monitorchange:boolean,triggersubdir:string}[]=[{'giturl':'','branch':'','clonedir':'','monitorchange':true,'triggersubdir':''}];
	public buildscript:string = '';
	public buildimagetype:string = '';
	public installfilesdir:string = '';
	public installscript:string = '';
	public runscript:string = '';
	public dockerfiledir:string = '';
	public imagedescfile:string ='';
	public staticcheck:{isused:boolean,script:string,resultfile:string} = {'isused':false,'script':'','resultfile':''};
	public cyclomaticcomplexity:{isused:boolean,script:string,resultfile:string} = {'isused':false,'script':'','resultfile':''};
	public unittest:{isused:boolean,script:string,coveragestaticfile:string,testcasestaticfile:string} = {'isused':false,'script':'','coveragestaticfile':'','testcasestaticfile':''};
	public continousintegration:boolean = false;
}
export class codebuildinfo {
	public tenantid:string= '';
	public builduuid:string = '';
	public buildimage:{tenantid:string,name:string,version:string} = {'tenantid':'','name':'','version':''};
	public description:string='';
	public frameworkcfg:{frameworkuuid:string,tenantid:string}={'frameworkuuid':'','tenantid':''};
	public gitcfg:{giturl:string,branch:string,clonedir:string,monitorchange:boolean,triggersubdir:string}[]=[{'giturl':'','branch':'','clonedir':'','monitorchange':true,'triggersubdir':''}];
	public buildscript:string = '';
	public buildimagetype:string = '';
	public installfilesdir:string = '';
	public installscript:string = '';
	public runscript:string = '';
	public dockerfiledir:string = '';
	public imagedescfile:string ='';
	public staticcheck:{isused:boolean,script:string,resultfile:string} = {'isused':false,'script':'','resultfile':''};
	public cyclomaticcomplexity:{isused:boolean,script:string,resultfile:string} = {'isused':false,'script':'','resultfile':''};
	public unittest:{isused:boolean,script:string,coverageresultfile:string,testcaseresultfile:string} = {'isused':false,'script':'','coverageresult':'','testcaseresult':''};
	public continousintegration:boolean = false;
	public updatetime:string= '';                
}

export class onebuild {
	public imagename:string = '';
	public uuid:string = '';
	public tenantid:string = '';
}
