import { Component } from "@angular/core";
import { ActivatedRoute, Router } from "@angular/router";
import { EventBroadcastService, LogISOLocalPipe,ISOLocalPipe } from "../shared/index";
import { LogsComponent } from  '../log/logs.component';
import { Src2imgService } from './src2img.service';
import { codebuildinfo } from './src2img';


@Component({
  moduleId: module.id,
  selector: 'app-logs',
  templateUrl: 'codebuild-log.component.html',
  styleUrls: ['codebuild-log.component.css'],
  directives: [LogsComponent],
  providers: [],
  pipes:[ISOLocalPipe]
})

export class CodebuildLogComponent{
	private reqType:string='';
	private id:string='';
	private instanceid:string='';
	private instances:{commitid:string,commitmsg:string,committime:string,buildstarttime:string,
										 committer:string,status:string,version:string,options:{sign:string,rangetime:string}
										 extend:boolean}[];
	private time:any;
  private cbinfo:codebuildinfo;
	constructor(private route:ActivatedRoute,
							private src2imgService:Src2imgService,
							private eventBroadcastService:EventBroadcastService,
							private router:Router) {
		this.reqType = 'container/?dc_pod_conid=';
	}
	ngOnInit() {
		this.instances=[];
		this.id = this.router.routerState.parent(this.route).params.value.id;
    this.getcontainer();
    this.cbinfo = new codebuildinfo();
    this.getcodebuild();
    	//this.freshcblog();
	}
  getcodebuild() {
    this.src2imgService.getCodeBuild(this.id).subscribe(res=>{
      this.cbinfo = res;
    },err=>{
      this.eventBroadcastService.broadcastError('获取构建信息失败');
    })
  }
	getcontainer() {
		let that = this;
		this.src2imgService.getIntances(this.id).subscribe(
			res=>{
				that.instances=_.map(res.instances,function(instance:{commitid:string,commitmsg:string,committime:string,buildstarttime:string,
                     committer:string,status:string,version:string}){
					
					let options:{sign:string,rangetime:string}={'sign':'',rangetime:''};
					if(instance.status =='initial'||instance.status=='running'){
						options.sign='realtime';
						options.rangetime='';
					}else{
						options.sign = 'history';
						options.rangetime='ALL';
					}
					
					let item:{commitid:string,commitmsg:string,committime:string,buildstarttime:string,
                     committer:string,status:string,version:string,
						        options:{sign:string,rangetime:string},extend:boolean}={
						'commitid':that.reqType+instance.commitid,'commitmsg':instance.commitmsg,'committime':instance.committime,'buildstarttime':instance.buildstarttime,
						'committer':instance.committer,'version':instance.version,'status':instance.status,
						'options':options,
						'extend':false
					};
					return item;
				})
        try{
         this.instances[0].extend=true;
        }catch(e){
              
        };
        
				
			},err=>{
				that.eventBroadcastService.broadcastError('获取Commit信息失败');
			})
	}
	freshcblog() {
    this.time = setInterval(()=>{this.getcontainer()},10000);
  }
  ngOnDestroy() {
    clearInterval(this.time);
  }
}