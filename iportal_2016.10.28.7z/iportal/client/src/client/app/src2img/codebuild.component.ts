import { Component, ViewChild } from '@angular/core';
import { Src2imgService } from './src2img.service';
import { EventBroadcastService, ISOLocalPipe } from '../shared/index';
import { MODAL_DIRECTIVES, ModalComponent } from 'ng2-bs3-modal/ng2-bs3-modal';
import { codebuild, codebuildinfoview } from './src2img';
import { ROUTER_DIRECTIVES,Router,ActivatedRoute } from '@angular/router';
import { ActiveProjectService } from '../app.service';
import { Headers, Http, Response} from '@angular/http';
import { framework,FrameworkComponent } from './framework/index';


@Component({
  moduleId:module.id,
  selector: 'cb',
  templateUrl:'codebuild.component.html' ,
  styleUrls:['codebuild.component.css'],
  directives:[MODAL_DIRECTIVES,ROUTER_DIRECTIVES,FrameworkComponent],
  pipes:[ISOLocalPipe],
  providers:[Src2imgService]
})

export class CodeBuildComponent {
  public codebulids:codebuild[];
  private cbinfo:codebuildinfoview;
  private frameworks:framework[];
  public gitcfg:{giturl:string,branch:string,clonedir:string,monitorchange:boolean,triggersubdir:string};
  public gitcfgs:{giturl:string,branch:string,clonedir:string,monitorchange:boolean,triggersubdir:string}[];
  public showflag:boolean;
  private isonebaseimage:boolean;
  private index:number;
  public selectId:number ;
  @ViewChild('modal') modal: ModalComponent;
  constructor(private src2imgService:Src2imgService,
              private eventBroadcastService :EventBroadcastService,
              private router:Router,
              private activeProjectService:ActiveProjectService,
              private route:ActivatedRoute,
              private _http: Http) {
  }
  ngOnInit() {
    this.gitcfgs = [];
    this.cbinfo = new codebuildinfoview();
    this.cbinfo.buildimagetype='auto';
    this.cbinfo.continousintegration=false;
    this.cbinfo.tenantid = this.activeProjectService.id;
    this.cbinfo.cyclomaticcomplexity.isused=false;
    this.cbinfo.unittest.isused=false;
    this.cbinfo.staticcheck.isused=false;
    this.showflag=false;
    this.isonebaseimage=true;
    this.gitcfg={'giturl':'','branch':'master','clonedir':'','monitorchange':true,'triggersubdir':''};
  }
  setcodebuild() {
    this.src2imgService.addCodeBuild(this.cbinfo).subscribe(res=>{
      this.eventBroadcastService.broadcastSuccess('创建代码构建成功');
    },err=>{
      this.eventBroadcastService.broadcastError('创建代码构建失败,请重试');
    });
  }
  selectframework(frame:framework) {
    this.cbinfo.frameworkcfg.frameworkuuid = frame.uuid;
    this.isonebaseimage=frame.isonebaseimage;
  }
  onSubmit() {
    this.cbinfo.gitcfg = this.gitcfgs;
    this.setcodebuild();
    this.backtocblist();
  }
  addsubgit(gitcfg:{giturl:string,branch:string,clonedir:string,monitorchange:boolean,triggersubdir:string}) {
    this.gitcfgs.push(gitcfg);
  }
  deletesubgit(gitcfg:{giturl:string,branch:string,clonedir:string,monitorchange:boolean,triggersubdir:string}) {
    this.gitcfgs = _.filter(this.gitcfgs, function(item){ 
      return (item.giturl != gitcfg.giturl)||(item.branch != gitcfg.branch)||(item.clonedir != gitcfg.clonedir)||(item.monitorchange != gitcfg.monitorchange)||(item.triggersubdir != gitcfg.triggersubdir)
    });
  }
  backtocblist() {
    this.router.navigate(['../../list'],{relativeTo:this.route});
  }
  getclonedir(search:string,config:{giturl:string,branch:string,clonedir:string,monitorchange:boolean,triggersubdir:string}) {
    this.index= search.lastIndexOf('/');
    if(this.index!=-1) {
      config.clonedir=search.substring(this.index+1,search.length);
    }else{
      config.clonedir='';
    }
    }
}
