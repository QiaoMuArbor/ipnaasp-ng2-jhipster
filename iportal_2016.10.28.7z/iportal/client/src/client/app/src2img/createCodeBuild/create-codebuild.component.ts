import { Component} from '@angular/core';
import { Headers, Http, Response} from '@angular/http';
import { ROUTER_DIRECTIVES,Router,ActivatedRoute } from '@angular/router';
import { Src2imgService } from '../src2img.service';
import { EventBroadcastService, ISOLocalPipe } from '../../shared/index';
import { createCodeBuild,codebuildBody} from '../src2img';
import { ActiveProjectService } from '../../app.service';
import {FrameworkComponent} from '../framework/index';
import {gitUrlCfgComponent} from './gitUrlCfg-component'

@Component({
  moduleId:module.id,
  selector: 'create-codebuild',
  templateUrl:'create-codebuild.component.html' ,
  styleUrls:['create-codebuild.component.css'],
  directives:[ROUTER_DIRECTIVES,FrameworkComponent,gitUrlCfgComponent],
  providers:[Src2imgService]
})

export class CreateCodeBuildComponent {
   public CbBody:codebuildBody;
   public createCb:createCodeBuild;
   public moreSet:boolean;
  constructor(private src2imgService:Src2imgService,
              private eventBroadcastService :EventBroadcastService,
              private router:Router,
              private activeProjectService:ActiveProjectService,
              private route:ActivatedRoute,
              private _http: Http) {
     this.CbBody = new codebuildBody;
     this.createCb =new createCodeBuild;
     this.moreSet = false;
  }

  createCodeBuild(){

  }

  selectframework(event:any){

  }
  
}