import { Component,Input, Output, EventEmitter} from '@angular/core';
import { Headers, Http, Response} from '@angular/http';
import { ROUTER_DIRECTIVES,Router,ActivatedRoute } from '@angular/router';
import { Src2imgService } from '../src2img.service';
import { EventBroadcastService, ISOLocalPipe } from '../../shared/index';
import { ActiveProjectService } from '../../app.service';

@Component({
  moduleId:module.id,
  selector: 'gitUrlCfg',
  templateUrl:'gitUrlCfg-component.html' ,
  directives:[ROUTER_DIRECTIVES],
})

export class gitUrlCfgComponent {
  @Input() gitCfgs: Array<{gitUrl:string,branch:string,cloneDir:string}>;
  @Output() gitCfgsValueChange = new EventEmitter<Array<{gitUrl:string,branch:string,cloneDir:string}>>();
 
  public newGitCfg:{gitUrl:string,branch:string,cloneDir:string};
  constructor(private src2imgService:Src2imgService,
              private eventBroadcastService :EventBroadcastService,
              private router:Router,
              private activeProjectService:ActiveProjectService,
              private route:ActivatedRoute,
              private _http: Http) {
       this.initGitCfg();
  }
  

delGitCfg(delItem:any){
    this.gitCfgs = _.without(this.gitCfgs, delItem);
    this.gitCfgsValueChange.emit(this.gitCfgs);
}
addGitCfg(newGitCfg:any){

    if (this.checkGitCfg(newGitCfg)) {
      this.gitCfgs.push(newGitCfg);
      this.gitCfgsValueChange.emit(_.clone(this.gitCfgs));
      this.initGitCfg();
    }
}
initGitCfg(){
   this.newGitCfg = {'gitUrl':'','branch':'','cloneDir':''};
}
checkGitCfg(newGitCfg:any){
  return true;
}

}