import { Component, ViewChild } from '@angular/core';
import { Src2imgService } from './src2img.service';
import { EventBroadcastService, ISOLocalPipe } from '../shared/index';
import { MODAL_DIRECTIVES, ModalComponent } from 'ng2-bs3-modal/ng2-bs3-modal';
import { codebuild, codebuildinfo } from './src2img';
import { ROUTER_DIRECTIVES,Router,ActivatedRoute } from '@angular/router';
import { ActiveProjectService } from '../app.service';
import { Headers, Http, Response} from '@angular/http';
import { framework,FrameworkComponent } from './framework/index';



@Component({
  moduleId:module.id,
  selector: 'cb-modify',
  templateUrl:'codebuild-modify.component.html' ,
  styleUrls:['codebuild.component.css'],
  directives:[MODAL_DIRECTIVES,ROUTER_DIRECTIVES,FrameworkComponent],
  pipes:[ISOLocalPipe],
  providers:[Src2imgService]
})

export class CodeBuildModifyComponent {
  public codebulids:codebuild[];
  private cbinfo:codebuildinfo;
  private frameworks:framework[];
  private id:string;
  public staticcheck:boolean;
  public cyclomaticcomplexity:boolean;
  public unittest:boolean;

  public showflag:boolean;
  public edit:boolean = false;
  private isonebaseimage = true;

  public selectId:number ;
  public index:number;
  public gitcfg:{giturl:string,branch:string,clonedir:string,monitorchange:boolean,triggersubdir:string};
  public gitcfgs:{giturl:string,branch:string,clonedir:string,monitorchange:boolean,triggersubdir:string}[] =[];
  @ViewChild('modal') modal: ModalComponent;
  constructor(private src2imgService:Src2imgService,
              private eventBroadcastService :EventBroadcastService,
              private router:Router,
              private activeProjectService:ActiveProjectService,
              private route:ActivatedRoute,
              private _http: Http) {
  }
  ngOnInit() {
    this.id = this.router.routerState.parent(this.route).params.value.id;
    this.cbinfo = new codebuildinfo();
    this.getcodebuild();
    this.showflag=true;
    this.gitcfg={'giturl':'','branch':'master','clonedir':'','monitorchange':true,'triggersubdir':''};
  }

  getcodebuild() {
    this.src2imgService.getCodeBuild(this.id).subscribe(res=>{
      this.cbinfo = res;
      this.gitcfgs = res.gitcfg;
      console.log(this.gitcfgs);
    },err=>{
      this.eventBroadcastService.broadcastError('获取构建信息失败');
    })
  }

  setcodebuild() {
    this.cbinfo.gitcfg=this.gitcfgs;
    this.src2imgService.putCodeBuild(this.cbinfo).subscribe(res=>{
      this.eventBroadcastService.broadcastSuccess('更新成功');
      this.gotodetail();
    },err=>{
      this.eventBroadcastService.broadcastError('更新失败,请重试');
    });
  }
  selectframework(frame:framework) {
    this.cbinfo.frameworkcfg.frameworkuuid = frame.uuid;
    this.isonebaseimage = frame.isonebaseimage;
  }
  addsubgit(gitcfg:{giturl:string,branch:string,clonedir:string,monitorchange:boolean,triggersubdir:string}) {
    this.gitcfgs.push(gitcfg);
    this.gitcfg={'giturl':'','branch':'','clonedir':'','monitorchange':true,'triggersubdir':''};
  }
  deletesubgit(gitcfg:{giturl:string,branch:string,clonedir:string,monitorchange:boolean,triggersubdir:string}) {
  

    this.gitcfgs = _.filter(this.gitcfgs, function(item){ 
      return (item.giturl != gitcfg.giturl)||(item.branch != gitcfg.branch)||(item.clonedir != gitcfg.clonedir)||(item.monitorchange != gitcfg.monitorchange)||(item.triggersubdir != gitcfg.triggersubdir)
    });
  }
  onSubmit() {
    this.setcodebuild();
  }
  backtocblist() {
    this.router.navigate(['../../../list'],{relativeTo:this.route});
  }
  gotodetail() {
    this.router.navigate(['../log'],{relativeTo:this.route});
  }
  getclonedir(search:string,config:{giturl:string,branch:string,clonedir:string,monitorchange:boolean,triggersubdir:string}) {
    this.index= search.lastIndexOf('/');
    if(this.index!=-1) {
      config.clonedir=search.substring(this.index+1,search.length);
    }else{
      config.clonedir='';
    }
    }
}
