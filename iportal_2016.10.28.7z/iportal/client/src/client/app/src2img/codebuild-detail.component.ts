import { Component } from '@angular/core';
import { Src2imgService } from './src2img.service';
import { EventBroadcastService, ISOLocalPipe } from '../shared/index';
import { codebuild, codebuildinfoview, onebuild } from './src2img';
import { ROUTER_DIRECTIVES, ActivatedRoute } from '@angular/router';
import { ActiveProjectService } from '../app.service';

@Component({
  moduleId:module.id,
  selector: 'cb-detail',
  templateUrl:'codebuild-detail.component.html' ,
  styleUrls:['codebuild-detail.component.css'],
  directives:[ROUTER_DIRECTIVES],
  pipes:[ISOLocalPipe],
  providers:[Src2imgService]
})

export class CodeBuildDetailComponent {
  public cbdetail:{name:string,updatetime:string}={'name':'','updatetime':''};
  public build:{imagename:string,uuid:string,tenantid:string};
  public id:string = '';
  constructor(private src2imgService:Src2imgService,
              private eventBroadcastService :EventBroadcastService,
              private route:ActivatedRoute,
              private activeProjectService:ActiveProjectService) {
  }
  ngOnInit() {
    this.id = this.route.snapshot.params['id'];
    this.getcodebuild(this.id);
  }
  getcodebuild(id:string) {
    let that = this;
    this.src2imgService.getCodeBuild(id).subscribe(res=>{
      that.cbdetail.name = res.buildimage.name;
      that.cbdetail.updatetime = res.updatetime;
      that.build= {'imagename':res.buildimage.name,'uuid':res.builduuid,'tenantid':that.activeProjectService.id};
    },err=>{
      that.eventBroadcastService.broadcastError('获取构建信息失败');
    })
  }
  oneBuild() {
    this.src2imgService.oneBuild(this.build.uuid,this.build).subscribe(
      res=>{
        this.eventBroadcastService.broadcastSuccess('开始构建');
      },err=>{
        this.eventBroadcastService.broadcastError('构建失败,请重试');
      });
  }
}
