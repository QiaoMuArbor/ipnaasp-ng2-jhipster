import { Injectable }     from '@angular/core';
import { Http, Response } from '@angular/http';
import { Headers, RequestOptions } from '@angular/http';
import { Observable }     from 'rxjs/Observable';
import { AuthHttp } from '../shared/http/auth-http.service';
import { codebuild, codebuildinfo, codebuildinfoview , onebuild} from './src2img';
import { ActiveProjectService } from '../app.service';

@Injectable()
export class Src2imgService {
  private src2imgUrl = '/api/dev/v1/tenants/';  // URL to web API
  constructor(private http: AuthHttp,private activeProjectService:ActiveProjectService) {
    this.src2imgUrl+=this.activeProjectService.id+'/';
  }

  getCodeBuilds (): Observable<any> {
    return this.http.get(this.src2imgUrl+'codebuilds');
  }

  addCodeBuild (cbinfo:codebuildinfoview): Observable<any> {
    let that =this;
    return that.http.post(that.src2imgUrl+'codebuilds',cbinfo)
      .map(res=> {
        return res;
      })
      .catch(that.handleError);
  }

  getCodeBuild (id: string): Observable<any> {
    return this.http.get(this.src2imgUrl+'codebuilds/'+id);
  }

  getIntances(id:string) {
    let url:string = this.src2imgUrl +'codebuilds/'+id+'/instances';
    return this.http.get(url);
  }

  delete(id: string) {
    return this.http.delete(this.src2imgUrl+'codebuilds/'+id);
  }
  oneBuild(id:string,build:onebuild) {
    return this.http.put(this.src2imgUrl+'codebuilds/'+id+'/onebuild',build);
  }
  putCodeBuild(cbinfo:codebuildinfo): Observable<any>{
    return this.http.put(this.src2imgUrl+'codebuilds/'+cbinfo.builduuid,cbinfo);
  }

  handleError (error: any) {
    let errMsg:string;
    if(error.message) { 
       errMsg = error.message;
    } else {
       errMsg = (error.message) ? error.message :
            error.status ? `${error.status} - ${error.statusText}` : 'Server error';
    }
   
    
    return Observable.throw({message:errMsg,status:error.status});
  }
}