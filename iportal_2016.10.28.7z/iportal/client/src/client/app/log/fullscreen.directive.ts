import {Directive, ElementRef, Input} from "@angular/core";

@Directive({
  selector: '[fullscreen]'
})

export class FullScreen {
  private el:HTMLElement;

/*
  @Input('isFullScreen')
  set bottom(isFullScreen:boolean) {
    if (isFullScreen) {
      if (this.el.requestFullscreen) {
        this.el.requestFullscreen();
      }
      else if (this.el.msRequestFullscreen) {
        this.el.msRequestFullscreen();
      }
      else if (this.el.mozRequestFullScreen) {
        this.el.mozRequestFullScreen();
      }
      else if (this.el.webkitRequestFullScreen) {
        this.el.webkitRequestFullScreen();
      }
      this.el.style.height = '100%';
      this.el.style.width = '100%';
      this.el.childNodes[3].style.height = (window.screen.height - 100) + "px";
 this.el.children.namedItem("");
    } else {
      if (document.exitFullscreen) {
        document.exitFullscreen();
      } else if (document.msExitFullscreen) {
        document.msExitFullscreen();
      } else if (document.mozCancelFullScreen) {
        document.mozCancelFullScreen();
      } else if (document.webkitCancelFullScreen) {
        document.webkitCancelFullScreen();
      }
      this.el.style.height = '50%';
      this.el.style.width = '100%';
      this.el.childNodes[3].style.height = "480px";
    }

  }
*/

  constructor(el:ElementRef) {
    this.el = el.nativeElement;
  }
}
