import {Directive, ElementRef, HostListener, Input, Output, EventEmitter} from "@angular/core";

@Directive({
  selector: '[scroll]'
})
export class ScrollDirective {
  private el:HTMLElement;
  @Output('scrolltop') scrolltop = new EventEmitter<any>();
  @Output('scrollbottom') scrollbottom = new EventEmitter<any>();

  constructor(el:ElementRef) {
    this.el = el.nativeElement;
  }

  @HostListener('wheel', ['$event.wheelDelta']) onMouseWheel(wheelDelta:number) {
    if (wheelDelta > 0) {
      if (this.el.scrollTop === 0) {
        this.scrolltop.emit(null);
      }
    }
    if (wheelDelta < 0) {
      if (this.el.scrollTop + this.el.clientHeight === this.el.scrollHeight) {
        this.scrollbottom.emit(null);
      }
    }
  }

  @Input('scrollbottom')
  set bottom(length:number) {
    let that = this;
    if (that.el.scrollTop + that.el.clientHeight === that.el.scrollHeight) {
      setTimeout(function () {
        that.el.scrollTop = that.el.scrollHeight;
      }, 0);
    }
  }

  @Input('isOnTop')
  set scrollBottom(isOnTop:number) {
    this.el.scrollTop = this.el.scrollHeight;

  }

  @Input('isOnBottom')
  set scrollTop(isOnTop:number) {
    this.el.scrollTop = 0;
  }

}
