import {Component, Input} from "@angular/core";
import {DateFormat} from "../shared/pipes/function";
import {MODAL_DIRECTIVES} from "ng2-bs3-modal/ng2-bs3-modal";
import {EventBroadcastService} from "../shared/index";
import {ScrollDirective} from "./scroll.directive";
import {LogsService} from "./logs.service";
import {Subject} from "rxjs/Subject";
import {LogTimeComponent} from "./timeforlogs/logTime";
import {LogsContent} from "./logscontent/logsContent";
import {LogsExport} from "./logexporter/logsExport";


@Component({
  moduleId: module.id,
  selector: 'logs',
  templateUrl: 'logs.component.html',
  styleUrls: ['logs.component.css'],
  directives: [MODAL_DIRECTIVES, LogsContent, LogTimeComponent, ScrollDirective, LogsExport],
  providers: [DateFormat, LogsService]
})

export class LogsComponent {
  @Input("reqType") reqType:string;
  @Input("options") options:{sign:string,rangetime:string};
  freshTimeInterval:string;
  startTime:any;
  endTime:any;
  keywords:string;
  logFresh:any;
  bottom:boolean;
  blackskin:boolean;
  isOn:boolean;
  isloading:boolean;
  isRealtime:boolean;
  page:number;
  total:number;
  topOrBottom:boolean;
  deployLogs:any[];
  private searchTermStream = new Subject<string>();
  private freshTimeIntervalStream = new Subject<string>();
  loglevels:string[];
  level:string;
  typeId:string;
  clicknum:number;
  private isOnTop:boolean;
  private isOnBottom:boolean;

  constructor(private logsService:LogsService,
              private eventBroadcastService:EventBroadcastService,
              private dateformat:DateFormat) {

  }

  ngOnInit() {
    this.clicknum = 0;
    this.isloading = false;
    this.isRealtime = true;
    this.isOn = true;
    this.blackskin = true;
    this.freshTimeInterval = "10";
    this.keywords = '';
    this.bottom = true;
    this.loglevels = ['DEBUG', 'INFO', 'WARN', 'ERROR', 'FATAL', 'All'];
    this.level = 'All';
    this.judgeSearch();
    this.getSearchStream().subscribe();
    this.getIntervalStream().subscribe();
  }

  initSearchData() {
    this.deployLogs = [];
    this.page = 0;
    this.total = 0;
  }

  judgeSearch() {
    if (this.options && this.options.sign === 'history') {
      this.isRealtime = false;
      this.initSearchData();
      this.getHistoryLogs(this.page);
    } else {
      this.initRealTimeLogs();
    }
  }

  levelSearch() {
    if (!this.isRealtime) {
      this.initSearchData();
      this.getHistoryLogs(this.page);
    }
    else {
      return;
    }
  }

  globalSearch(term:string) {
    this.searchTermStream.next(term);
  }

  getSearchStream() {
    let that = this;
    return that.searchTermStream
      .debounceTime(300)
      .distinctUntilChanged().map(() => {
        if (!that.isRealtime) {
          that.initSearchData();
          that.getHistoryLogs(that.page);
        }
        else {
          return;
        }
      });
  }


  setFreshTimeInterval(item:string) {
    this.freshTimeIntervalStream.next(item);
  }

  getIntervalStream() {
    let that = this;
    return that.freshTimeIntervalStream
      .debounceTime(1000)
      .distinctUntilChanged().map(() => {
        if (that.freshTimeInterval.length != 0 && that.freshTimeInterval.match("^([1-9][0-9]*)$")) {
          if (that.logFresh) {
            clearInterval(that.logFresh);
            that.initRealTimeLogs();
          }
        }
        else {
          if (that.logFresh) {
            that.freshTimeInterval = "10";
            clearInterval(that.logFresh);
            that.initRealTimeLogs();
          }
        }
      });
  }


  searchByTime(data:any) {
    if (data.startTime == data.endTime) {
      if (this.isRealtime) {
        return;
      }
      this.isRealtime = !this.isRealtime;
      this.isOn = true;
      this.initRealTimeLogs();
    }
    else {
      if (this.isRealtime) {
        this.isRealtime = !this.isRealtime;
        clearInterval(this.logFresh);
      }
      this.initSearchData();
      this.startTime = data.startTime;
      this.endTime = data.endTime;
      this.getHistoryLogs(this.page);
    }
  }

  freshRealTimeLogs() {
    let that = this;
    this.logFresh = setInterval(() => {
      that.startTime = that.dateformat.IsoLocalTime(new Date(that.endTime).getTime());
      that.endTime = that.dateformat.IsoLocalTime(new Date(that.endTime).getTime() + parseInt(that.freshTimeInterval) * 1000);
      that.getRealTimeLogs();
    }, parseInt(that.freshTimeInterval) * 1000);
  }

  getPreviousLogs() {
    if (this.isloading) {
      return;
    }
    if (!this.isRealtime) {
      if (Math.ceil(this.total / this.buildHistoryLogStruct().perPage) >= (this.page + 2)) {
        this.page += 1;
        this.topOrBottom = true;
        this.isOnTop = !this.isOnTop;
        this.getHistoryLogs(this.page);
      } else {
        if (this.deployLogs.length == 0) {
          return;
        }
        this.eventBroadcastService.broadcastSuccess('已获取全部日志');
      }
    }
  }

  getNextLogs() {
    if (this.isloading) {
      return;
    }
    if (!this.isRealtime) {
      if (this.page - 1 >= 0) {
        this.page -= 1;
        this.topOrBottom = false;
        this.isOnBottom = !this.isOnBottom;
        this.getHistoryLogs(this.page);
      } else {
        if (this.deployLogs.length == 0) {
          return;
        }
        this.eventBroadcastService.broadcastSuccess('已获取全部日志');
      }
    }
  }

  getHistoryLogs(page:number) {
    let logStruct = this.buildHistoryLogStruct();
    if (this.options && this.options.rangetime === 'ALL') {
      logStruct.startTime = this.dateformat.IsoLocalTime(0);
      logStruct.endTime = this.dateformat.IsoLocalTime(new Date().getTime());
    }
    logStruct.page = page;
    let that = this;
    if (!that.isValid(logStruct)) {
      return;
    }
    this.isloading = true;
    that.logsService.getHistoryLogs(logStruct)
      .subscribe(logs => {
        that.total = logs.total;
        that.deployLogs = logs.logData;
        that.isloading = false;
      }, error=> {
        that.isloading = false;
      });
  }

  getRealTimeLogs() {
    let logStruct = this.buildRealtimeLogStruct();
    let that = this;
    if (!that.isValid(logStruct)) {
      return;
    }
    that.logsService.getRealTimeLogs(logStruct)
      .subscribe((logs => {
        if (logs.logData) {
          if (logs.logData.length > 0 && (that.deployLogs.length + logs.logData.length) > 600) {
            that.deployLogs = logs.logData;
          } else {
            that.deployLogs = that.deployLogs.concat(logs.logData);
          }
        }
      }), error=> {
      });
  }

  initRealTimeLogs() {
    let that = this;
    that.initSearchData();
    that.endTime = that.dateformat.IsoLocalTime(new Date().getTime());
    that.startTime = that.dateformat.IsoLocalTime(new Date(that.endTime).getTime() - parseInt(this.freshTimeInterval)
      * 1000);
    let logStruct = this.buildRealtimeLogStruct();
    if (!that.isValid(logStruct)) {
      return;
    }
    this.isloading = true;
    that.logsService.getRealTimeLogs(logStruct)
      .subscribe((logs => {
        that.deployLogs = logs.logData;
        that.isloading = false;
      }), error=> {
        that.isloading = false;
      });
    that.freshRealTimeLogs();
  }

  isOnLogs() {
    this.isOn = !this.isOn;
    if (this.isOn) {
      this.initRealTimeLogs();
    } else {
      clearInterval(this.logFresh);
    }
  }

  switchSkin() {
    this.blackskin = !this.blackskin;
  }

  setFullScreen() {
    let that = this;
    let fullscreenDoc = document.getElementById("fullscreen");
    let deploylogDoc = document.getElementById("deploylog");
    let contentde = document.getElementById("content");
    let isFullScreen = false;

    if (fullscreenDoc.webkitRequestFullScreen) {
      fullscreenDoc.webkitRequestFullScreen();
    }
    document.addEventListener("webkitfullscreenchange", function () {
      if (isFullScreen == false && that.clicknum == 0) {
        fullscreenDoc.style.height = "100%";
        fullscreenDoc.style.width = "100%";
        deploylogDoc.style.height = (window.screen.height - 100) + "px";
        contentde.style.height = "100%";
        (<HTMLInputElement>document.getElementById("img-fullscreen")).src = "../../../images/apps/fullscreen-exit.png";
        that.clicknum = 1;
      }
      if (isFullScreen == true) {
        fullscreenDoc.style.height = "50%";
        fullscreenDoc.style.width = "100%";
        deploylogDoc.style.height = "480px";
        contentde.style.height = "100%";
        (<HTMLInputElement>document.getElementById("img-fullscreen")).src = "../../../images/apps/fullscreen.png";
        that.clicknum = 0;

      }
      isFullScreen = true;
    }, false);

    if (isFullScreen == true || that.clicknum == 1) {
      document.webkitCancelFullScreen();
      document.addEventListener("webkitfullscreenchange", function () {
        fullscreenDoc.style.height = "50%";
        fullscreenDoc.style.width = "100%";
        deploylogDoc.style.height = "480px";
        contentde.style.height = "100%";
        (<HTMLInputElement>document.getElementById("img-fullscreen")).src = "../../../images/apps/fullscreen.png";
        that.clicknum = 0;
      }, false);
    }
  }


  /*buildRealtimeLogStruct() {
    return {
      type: this.reqType,
      level: this.level,
      keywords: this.keywords,
      startTime: this.startTime,
      endTime: this.endTime
    };
  }*/

  buildHistoryLogStruct() {
    return {
      type: this.reqType,
      level: this.level,
      keywords: this.keywords,
      startTime: this.startTime,
      endTime: this.endTime,
      page: 0,
      perPage: 300
    };
  }

buildRealtimeLogStruct(){
  return {
      type: this.reqType,
      level: this.level,
      keywords: this.keywords
    };
}
  isValid(logStruct:any):boolean {
    if (!logStruct.type) {
      this.eventBroadcastService.broadcastError('服务请求URL或参数错误,请检查');
      return false;
    }
    return true;
  }

  initExportMsg() {
    return {
      type: this.reqType,
      level: this.level,
      keywords: this.keywords,
      startTime: this.startTime,
      endTime: this.endTime
    };
  }

  ngOnDestroy() {
    if (this.logFresh) {
      clearInterval(this.logFresh);
    }
  }
}
