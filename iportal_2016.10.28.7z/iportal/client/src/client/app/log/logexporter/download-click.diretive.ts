import {Directive, ElementRef, Input, Renderer, Injectable} from '@angular/core';

@Directive({
  selector: '[downloadauto]'
})
export class DownloadDirective {
  private el:HTMLElement;

  @Input()
  set downloadauto(flag:string) {
    this.el.href = flag;
    if (this.el.href && this.el.href.indexOf('undefined') === -1) {
      this.el.click();
    }
  }

  constructor(el:ElementRef) {
    this.el = el.nativeElement;
  }
}

@Injectable()
export class CreateHtmlElComponent {
  constructor(private render:Renderer) {
  }

  createHtml_a(href:string,fileName:string) {
    let a:any;
    let html_a = this.render.createElement(a, 'a');
    html_a.href = href;
    //html_a.href="index.html";
    //html_a.target='_black';
    html_a.download = fileName;
    html_a.click();
  }
}
