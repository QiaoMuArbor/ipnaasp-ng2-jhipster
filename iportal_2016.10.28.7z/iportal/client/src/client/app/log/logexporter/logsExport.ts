import {Component, Input} from "@angular/core";
import {TOOLTIP_DIRECTIVES} from "ng2-bootstrap/ng2-bootstrap";
import {DateFormat} from "../../shared/pipes/function";
import {LogsService} from "../logs.service";
import {EventBroadcastService} from "../../shared/event-broadcast.component";
import {Http} from "@angular/http";
import {DownloadDirective, CreateHtmlElComponent} from "./download-click.diretive";

@Component({
  moduleId: module.id,
  selector: 'logs-export',
  directives: [TOOLTIP_DIRECTIVES, DownloadDirective],
  providers: [CreateHtmlElComponent, DateFormat],
  templateUrl: 'logsExport.html',
  styleUrls: ['logsExport.css']
})

export class LogsExport {
  @Input('exportMsg') exportMsg:any;
  fileUrl:string;
  isProgressing:boolean;
  fileName:string;
  sessionId:string;
  interval:any;

  constructor(private http:Http, private createHtmlEl:CreateHtmlElComponent, private eventBroadcastService:EventBroadcastService, private logsService:LogsService) {
  }

  ngOnInit() {
    this.isProgressing = false;
  }


  exportLogs(){
    if(!this.isProgressing){
      this.doExportLogs();
    }
    else {
      this.cancelExport();
    }
  }

  doExportLogs() {
    let that = this;
    let reqMsg = that.buildExportReqMsg();
    if(!reqMsg) return;
    this.isProgressing = true;

    that.logsService.sendExportLogsRequest(reqMsg)
      .subscribe(res => {
        if(res.id && res.file){
          that.sessionId = res.id;
          that.fileUrl = res.file;
          console.log(new Date().toISOString()+"sessionId="+that.sessionId+"  fileUrl"+that.fileUrl);
          that.getExportProcess();
        }
        else{
          that.eventBroadcastService.broadcastError('日志导出失败');
          that.isProgressing = false;
        }
      }, error=> {
        that.eventBroadcastService.broadcastError('日志导出失败');
        that.isProgressing = false;
      });
  }

  getExportProcess() {
    let that = this;
    if (!that.interval) {
      that.interval = setInterval(() => {
        let progress = 0;
        if(that.isProgressing){
        that.logsService.getProgress(that.sessionId)
          .subscribe(res => {
            progress = res.value;
            console.log(new Date().toISOString()+"process="+progress);
            if (progress == 100) {
              clearInterval(that.interval);
              console.log("download");
              that.downloadLogfile();
            }
          }, error=> {
            that.eventBroadcastService.broadcastError('日志导出失败');
            that.isProgressing = false;
            clearInterval(that.interval);
          });
      }
    }, 1500);
    }
  }

  cancelExport() {
    let that=this;
    if(that.sessionId && that.fileUrl) {
      that.isProgressing=false;
      console.log(new Date().toISOString()+"cancle");
      that.logsService.cancelExportedLogs(this.sessionId)
        .subscribe(() =>{
          if(that.interval){
           clearInterval(that.interval);
          }
          that.eventBroadcastService.broadcastSuccess('已取消日志导出');
          that.isProgressing = false;
        }
        ,error => {
          that.eventBroadcastService.broadcastError('日志导出失败');
          that.isProgressing = false;
           if(that.interval){
            clearInterval(that.interval);
           }
        });
     }
   }

  downloadLogfile() {
    let that = this;
    if (!that.fileUrl) {
      that.eventBroadcastService.broadcastError('日志导出失败');
      that.isProgressing = false;
      return;
    }
    that.createHtmlEl.createHtml_a(that.fileUrl, that.fileName);
    that.isProgressing = false;
  }


  buildExportReqMsg():any {
    if (!this.isFileNameValid(this.fileName)) {
      this.eventBroadcastService.broadcastError('导出文件名为空或格式错误（不能包含\\ / : * ? "< > |）');
      return;
    }
    return {
      type: this.exportMsg.type,
      level: this.exportMsg.level,
      keywords: this.exportMsg.keywords,
      startTime: this.exportMsg.startTime,
      endTime: this.exportMsg.endTime,
      fileName: this.fileName
    }
  }

  isFileNameValid(fileName:string) {
    if (!fileName || fileName.length == 0) {
      return false;
    }
    if (fileName.search("[\\\\/:*?'\"<>|：]") != -1) {
      return false;
    }
    return true;
  }

}
