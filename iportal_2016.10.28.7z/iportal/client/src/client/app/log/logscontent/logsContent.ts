import {Component, Input} from '@angular/core';

@Component({
  moduleId: module.id,
  selector: 'logs-content',
  templateUrl: 'logsContent.html',
  styleUrls: ['logsContent.css'],
  directives: [],
})

export class LogsContent {
  @Input('applogs') applogs:{timestamp:string,level:string,message:string}[];
  @Input('isloading') isloading:boolean;
  @Input('blackskin') blackskin:boolean;

  constructor() {
  }
}
