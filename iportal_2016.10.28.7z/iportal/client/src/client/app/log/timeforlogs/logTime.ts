import {Component, Output, EventEmitter} from "@angular/core";
import {DateFormat} from "../../shared/pipes/function";
import {EventBroadcastService} from "../../shared/index";

@Component({
  moduleId: module.id,
  selector: 'log-time',
  templateUrl: 'logTime.html',
  styleUrls: ['logTime.css'],
  providers: [DateFormat]
})

export class LogTimeComponent {
  timestate:boolean;
  timerange:string;
  startTime:string;
  endTime:string;
  @Output('searchbytime') searchbytime = new EventEmitter<any>();

  constructor(private dateformat:DateFormat,private eventBroadcastService:EventBroadcastService) {
  }

  ngOnInit() {
    this.startTime = '';
    this.endTime = '';
    this.timerange = 'realtime';
    this.timestate = true;
    let that = this;
    setTimeout(function () {
      that.search(0, 'm');
    }, 0);
  }

  search(num?:number, timesign?:string) {
    if (timesign === 'm') {
      this.startTime = this.dateformat.IsoLocalTime(new Date().getTime() - num * 60 * 1000);
      this.endTime = this.dateformat.IsoLocalTime(new Date().getTime());
    }
    if (timesign === 'h') {
      this.startTime = this.dateformat.IsoLocalTime(new Date().getTime() - num * 60 * 60 * 1000);
      this.endTime = this.dateformat.IsoLocalTime(new Date().getTime());
    }
    if(this.startTime>this.endTime){
      this.eventBroadcastService.broadcastError('开始时间不能大于结束时间');
      return;
    }
    this.searchbytime.emit({startTime: this.startTime, endTime: this.endTime});
  }

  switchTimestate() {
    this.timestate = !this.timestate;
    if (!this.timestate) {
      if (this.startTime === '' || this.endTime === '') {
        this.startTime = this.dateformat.IsoLocalTime(new Date().getTime() - 5 * 60 * 1000);
        this.endTime = this.dateformat.IsoLocalTime(new Date().getTime());
      }
    }
  }

  startTimeChange(event:any){
    this.startTime=this.dateformat.IsoLocalTime(new Date(event.target.value));
   }

  endTimeChange(event:any){
   this.endTime=this.dateformat.IsoLocalTime(new Date(event.target.value));
  }
}

