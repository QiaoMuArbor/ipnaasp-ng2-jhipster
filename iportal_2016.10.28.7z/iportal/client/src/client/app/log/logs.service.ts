import {Injectable} from "@angular/core";
import {Observable} from "rxjs/Observable";
import {MockCfg} from "../mock";
import {AuthHttp} from "../shared/index";
import {ActiveProjectService} from "../app.service";

@Injectable()
export class LogsService {
  private commonUrl:string;

  constructor(private http:AuthHttp, private activeProject:ActiveProjectService) {
    this.commonUrl = MockCfg.logsUrl + '/v1/tenants/' + this.activeProject.id + '/';
  }

 /* getRealTimeLogs(data:{type:string, level:string, keywords:string, startTime:string, endTime:string}):Observable<{ total:number, currentPage:number,perPage:number,logData:Array<{ message:string,timestamp:string}> }> {
    return this.getLogs(data.type, data.level, data.keywords, data.startTime, data.endTime, 0, 600);
  }*/

  getHistoryLogs(data:{type:string,level:string, keywords:string, startTime:string, endTime:string, page:number, perPage:number}):Observable<{ total:number, currentPage:number,perPage:number,logData:Array<{ message:string,timestamp:string}> }> {
    return this.getLogs(data.type, data.level, data.keywords, data.startTime, data.endTime, data.page, data.perPage);
  }

  getRealTimeLogs(data:{type:string,  level:string, keywords:string}):Observable<{ total:number, currentPage:number,perPage:number,logData:Array<{ message:string,timestamp:string}> }> {
    return this.getLogs(data.type, data.level, data.keywords, '', '', 0,100);
  }

  getLogs(type:string, level:string, keywords:string, startTime:string, endTime:string, page:number, perPage:number):Observable<{ total:number, currentPage:number,perPage:number,logData:Array<{ message:string,timestamp:string}> }> {
    let IsoStartTime = startTime.length==0 ? '': new Date(startTime).toISOString();
    let IsoEndTime = endTime.length==0 ? '': new Date(endTime).toISOString();
    let searchLevel = (level === "All") ? '' : level; 
    let url = this.commonUrl + type + "&start_time=" + IsoStartTime + 
              "&end_time=" + IsoEndTime + "&page=" + page + 
              "&per_page=" + perPage + "&level=" + searchLevel + 
              "&keywords=" + keywords;
       
    return this.http.get(url)
      .map(res => {
        let ret:{ total:number,
          currentPage:number,
          perPage:number,
          logData:Array<{ message:string,timestamp:string}>
        } = {
          total: 0,
          currentPage: 0,
          perPage: 0,
          logData: []
        };
        if (res.result) {
          ret = {
            total: res.total_count,
            currentPage: res.current_page,
            perPage: res.per_page,
            logData: res.result.reverse()
          };
        }
        return ret;
      })
  }

  sendExportLogsRequest(reqMsg:any):Observable<{ id:string, file:string}> {
    let IsoStartTime = new Date(reqMsg.startTime).toISOString();
    let IsoEndTime = new Date(reqMsg.endTime).toISOString();
    let searchLevel = (reqMsg.level === "All") ? '' :reqMsg.level;
    let url = this.commonUrl+"file/" + reqMsg.type + "&start_time=" + IsoStartTime + "&end_time=" + IsoEndTime + "&file_name=" + reqMsg.fileName;
    //+"&level=" + searchLevel + "&keywords=" + keywords;
   //let url = "http://10.93.63.59:1234/ops/v1.0/mt/log/file/ms/?ms_id=a3064716-0437-4f85-a480-d908b50ef1b6&file_name=logfile11&start_time=2016-10-11T14:36:57.206Z&end_time=2016-10-14T14:36:57.206Z";
    return this.http.get(url)
      .map(res => {
        return {id: res.id, file: res.file};
      })
  }


  getProgress(sessionId:string):Observable<{ file:string,value:number}> {
  let url = this.commonUrl+"file/?sessionid=" + sessionId;
  //let url = "http://10.93.63.59:1234/ops/v1.0/1/log/file/?sessionid=" + sessionId;
    return this.http.get(url)
      .map(res => {
        return {file: res.file, value: res.value};
      });
  }

  cancelExportedLogs(sessionId:string):Observable<{fileremove:string}> {
   let url = this.commonUrl+"file/?sessionid=" + sessionId;
   //let url = "http://10.93.63.59:1234/ops/v1.0/1/log/file";
    let body:{sessionid:string} = {sessionid: sessionId};
    return this.http.post(url, body)
        .map(res => {
        return {fileremove:res.fileremove};
      });
  }

}
