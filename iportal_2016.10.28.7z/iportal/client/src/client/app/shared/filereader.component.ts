import { Component, EventEmitter, Output, Input } from '@angular/core';

@Component({
  moduleId:module.id,
  providers:[],
  directives: [],
  pipes:[],
  selector: 'filereader',
  template:`
  <div class="upload">
    <input type="file" name="file" #source (change)="showPreview(source)"/>导入
  </div>
  `,
  styles:[`
  .upload {
    padding: 4px 10px;
    line-height: 25px;
    position: relative;
    cursor: pointer;
    color: #888;
    background: #fafafa;
    border: 1px solid #ddd;
    border-radius: 4px;
    overflow: hidden;
    display: inline-block;
    *display: inline;
    *zoom: 1
  }
  .upload input {
    width: initial;
    position: absolute;
    font-size: 100px;
    right: 0;
    top: 0;
    opacity: 0;
    filter: alpha(opacity=0);
    cursor: pointer;
  }

  .upload input:hover {
    color: #444;
    background: #eee;
    border-color: #ccc;
    text-decoration: none
  }
`]
})

export class FileReaderComponent {
  private fr:FileReader;
  @Input('buttonname') buttonname:string='upload';
  @Output() outputfile = new EventEmitter();
  constructor() {
    this.fr = new FileReader();
  }
  ngOnInit() {
  }
  showPreview(source:any) {
    let that = this;
    let file = source.files[0];
    let fileName:string = '';
    if(file){
      fileName = file.name;
      this.fr.readAsText(file);
    }
    this.fr.onloadend = function(e:any) {
      that.outputfile.emit({'fileContent':e.target.result,'fileName':fileName})
    };
  }
}
