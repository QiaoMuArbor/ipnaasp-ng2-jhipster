import { Pipe, PipeTransform } from '@angular/core';

@Pipe({ name: 'esDateFormat' })
export class EsDateFormatPipe implements PipeTransform {
	transform(value: string, exponent: number): string {
		if (value && value.length >= exponent) {
			return value.substring(0, exponent);
		}
		return '';
	}
}
