import {Component, Input, OnInit,AfterViewInit} from '@angular/core';
import { UUID } from 'angular2-uuid';
import { Pie, LegendData, SeriesData, PieData } from './ky-pie.interface.component';

@Component({
  moduleId: module.id,
  selector: 'ky-pie',
  templateUrl: 'ky-pie.html',
  styleUrls: ['ky-pie.component.css'],
})

export class KyPieComponent implements AfterViewInit {
  //that = this;
  pieData:Pie;
  id:string;
  usedColor: string;
  colorGroup = ['#5cb85c', '#1898eb', '#ffb46b', '#f66661'];
  radius = [65, 75];
  option:any = {
    title: [{
      text: 'noused',
      left:"center",
      x: '50%',
      y: '45%',
      textStyle: {
        color: '#1898eb',
        fontSize: 16
      },
      subtext: "20%",
      subtextStyle: {
        color: '#1898eb',
        fontSize: 16
      }
    }, {
      text: 'noused----title',
      left:"center",
      x: '50%',
      y: 0,
      textStyle: {
        color: '#1898eb',
        fontSize: 14
      }
    }],
    legend: {
      selectedMode: false,
      orient: 'horizontal',
      left: 'center',
      top: 0,
      itemWidth: 12,
      itemHeight: 12,
      itemGap: 20,
      tooltip: {
        show: false
      },
      data: []
    },
    legendHoverLink:false,
    series: {
      name: '',
      type: 'pie',
      hoverAnimation: false,
      radius: this.radius,
      avoidLabelOverlap: false,
      center: ['50%', '50%'],
      label: {
        normal: {
          show: false,
          position: 'center'
        },
        emphasis: {
          show: false,
          textStyle: {
            fontSize: '30',
            fontWeight: 'bold'
          }
        }
      },
      labelLine: {
        normal: {
          show: false
        },
        emphasis: {
          show: false
        }
      },
      data: []
    }
  };

  constructor() {
    this.id = UUID.UUID();
  }

  @Input()
  set data(newData:any) {
    if (!newData) {
      return;
    }
    this.pieData = newData;
  }


  totalValue() {
    let ret = 0;
    _.each(this.pieData.data, function (item:any) {
      ret = ret + item.value;
    });
    return ret;
  }

  setDataToOption() {
    let that = this;
    let dataLength = this.pieData.data.length;
    let total = this.totalValue();
    _.each(this.pieData.data, function (item:PieData) {
      let legend = <LegendData>{};
      legend.name = item.name;
      legend.icon = 'square';
      that.option.legend.data.push(legend);

      let series = <SeriesData>{};
      series.name = item.name;
      series.value = item.value;
      series.itemStyle = {'normal':{'color':''}};
      if(dataLength > 2) {
        series.itemStyle.normal.color = item.color || '';
      }
      else {
        let rate:number = Math.round(item.value * 100 / total);
        let color:string = that.setColor(item.name, rate);
        series.itemStyle.normal.color = color;
      }

      if(series.itemStyle.normal.color == '#e6e6e6'){
        series.itemStyle.emphasis = {'color':''};
        series.itemStyle.emphasis.color = '#f2f2f2';
      }

      that.option.series.data.push(series);

    });
    that.option.title[0].text = this.pieData.pieName;
    that.option.title[0].subtext = this.pieData.pieSubName;
    that.option.title[1].text = this.pieData.title;
    if(this.usedColor){
      that.option.title[0].textStyle.color = this.usedColor;
      that.option.title[0].subtextStyle.color = this.usedColor;
    }
  }

  getColor(rate: number) {
    let that = this;
    if (rate < 50) {
      return that.colorGroup[0];
    } else if (rate < 75) {
      return that.colorGroup[1];
    } else if (rate < 90) {
      return that.colorGroup[2];
    } else {
      return that.colorGroup[3];
    }
  }

  setColor(name: string, rate: number) {
    if(name.endsWith("unused")) {
      return '#e6e6e6';
    }
    else {
      this.usedColor = this.getColor(rate);
      return this.usedColor;}
  }


  changeOptionPosition(width:number, height:number) {
    //let minWidth = 180;
    let minHeight = this.radius[1] * 2 + 20 * 2;
    if (width < 150 || minHeight > height) {
      return;
    }
    this.option.legend.top = height / 2 + this.radius[1] + 15;
    this.option.title[0].y = height / 2   - 20;
    this.option.title[1].y = height / 2 - this.radius[1] - 20 - 20;
  }

  createCharts() {
    let dom:any = document.getElementById(this.id);
    let width = dom.clientWidth;
    let height = dom.clientHeight;
    this.changeOptionPosition(width, height);
    let myChart:any = echarts.init(dom, 'macarons');
    myChart.setOption(this.option);
  }

  ngAfterViewInit() {
    this.setDataToOption();
    this.createCharts();
  }

}
