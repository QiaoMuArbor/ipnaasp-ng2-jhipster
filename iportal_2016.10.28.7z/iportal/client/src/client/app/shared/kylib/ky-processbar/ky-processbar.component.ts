﻿import { Component,Input } from '@angular/core';
import {NgStyle} from '@angular/common';
import {NgModel} from '@angular/common';

@Component({
    selector: 'ky-processbar',
    template: `

		<div class="percent-text">
			<div [ngStyle]="addTextbar(percentage)">{{percentage}}%</div>
		</div>
		<div class="progress" >
		   	<div [ngStyle]="addbar(percentage)"></div>
		</div>
	`,
	styles:[`
		div.percent-text {
			margin-bottom:6px;
			font-size: 12px;
			color: #333;
			font-family:"Microsoft YaHei";
			
			width:300px;
		}
		div.progress {
			width: 300px;
			height:10px;
			background-color: #efefef;
			
		}
	`],
 // directives: [NgStyle]
})
export class ProcessBarComponent {
	@Input() percentage;

  addTextbar(type:string){
return {"text-align":"left","padding-left":type*3+"px"};
     }

  addbar(type:string){
    return {"background-color": "#53d769","margin":"left","width":type*3+"px","height":"10px","border-radius":"3px"};
  }
}
