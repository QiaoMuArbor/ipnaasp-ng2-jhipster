import {Input, Component, OnInit, EventEmitter, Output, ElementRef, Inject} from '@angular/core';
import {CORE_DIRECTIVES} from '@angular/common';
import {TreeStyle, TreeStatus, TreeModel, FoldingType, NodeEvent, RenamableNode, NodeSelectedEvent} from './tree.types';
import {TreeService} from './tree.service';
import {isLeftButtonClicked, isRightButtonClicked} from './common/utils/event.utils';
import * as _ from 'underscore';
import {applyNewValueToRenamable, isRenamable, isValueEmpty} from './common/utils/type.utils';
import {KY_CHECKBOX_DIRECTIVES} from "../../kylib/ky-checkbox/ky-checkbox.component";
declare const alertify: any;

@Component({
  moduleId: module.id,
  selector: 'tree-internal',
  styleUrls: ['ky-tree.component.css'],
  templateUrl: 'ky-tree.component.html',
  directives: [TreeInternalComponent,CORE_DIRECTIVES, KY_CHECKBOX_DIRECTIVES]
})
class TreeInternalComponent implements OnInit {
  @Input()
  private tree: TreeModel;

  @Input()
  private treeStyle: TreeStyle;

  @Input()
  private parentTree: TreeModel;

  @Input()
  private indexInParent: number;

  

  private isLeaf: boolean;
  private isSelected: boolean = false;
  private isMenuVisible: boolean = false;
  private plusImage: boolean = true;
  private checkBox: boolean = false;


  public constructor(
    @Inject(TreeService) private treeService: TreeService,
	  @Inject(ElementRef) private element: ElementRef) {
  }
  public ngOnInit(): void {
    this.indexInParent = 0;

    this.isLeaf = !Array.isArray(this.tree.children);
    this.tree._indexInParent = this.indexInParent;
	  this.setUpNodeSelectedEventHandler();
  }
  
  private setUpNodeSelectedEventHandler() {
    this.treeService.nodeSelected$
      .filter((e: NodeSelectedEvent) => this.tree !== e.node)
      .subscribe(_ => this.isSelected = false);
  }
  
  private isPlusImage() {
  	if(this.treeStyle) {
  		return this.treeStyle.isPlusImage;
  	}
  	return this.plusImage;
    
  }
  
  private isCheckBox() {
  	if(this.treeStyle) {
  		return this.treeStyle.isCheckBox;
  	}
    return this.checkBox;
  }

  private isFolder() {
    return !this.isLeaf;
  }

   // FOLDING -----------------------------------------------------------------------------------------------------------

  private isNodeExpanded(): boolean {
    return this.tree._foldingType === FoldingType.Expanded;
  }

  private switchFoldingType(e: any, tree: TreeModel): void {
    this.handleFoldingType(e.target.parentNode.parentNode, tree);
  }

  private getFoldingTypeCssClass(node: TreeModel): string {
    if (!node._foldingType) {
      if (node.children) {
        node._foldingType = FoldingType.Collapsed;
      } else {
        node._foldingType = FoldingType.Leaf;
      }
    }

    return node._foldingType.cssClass;
  }
  
  private getFoldingImageTypeCssClass(node: TreeModel): string {
    //if (!node._foldingImageType) {
      if (node.children) {
        node._foldingImageType = FoldingType.NodeImage;
      } else {
        node._foldingImageType = FoldingType.LeafImage;
      }
   // }

    return node._foldingImageType.cssClass;
  }

  private getNextFoldingType(node: TreeModel): FoldingType {
    if (node._foldingType === FoldingType.Expanded) {
      return FoldingType.Collapsed;
    }

    return FoldingType.Expanded;
  }

  private handleFoldingType(parent: TreeModel, node: TreeModel) {
    if (node._foldingType === FoldingType.Leaf) {
      return;
    }

    node._foldingType = this.getNextFoldingType(node);
  }


  private onNodeSelected(e: MouseEvent) {
    if (isLeftButtonClicked(e)) {
      this.isSelected = true;
        this.treeService.nodeSelected$.next({node: this.tree});
    }
  } 
  private getComponentType(){
    let isPlusImage = this.treeStyle.isPlusImage;
    let isCheckBox = this.treeStyle.isCheckBox;
    if( isPlusImage === true && isCheckBox === false) {
      return 'file_no_chk';
    }
    else if( isPlusImage === true && isCheckBox === true) {
      return 'file_chk';
    }
    else if( isPlusImage === false && isCheckBox === false) {
      return 'no_file_no_chk';
    }
    else if( isPlusImage === false && isCheckBox === true) {
      return 'no_file_chk';
    }
    return 'null';
  }
}

@Component({
  selector: 'ky-tree',
  providers: [TreeService],
  template: `<tree-internal [tree]="tree" [treeStyle]="treeStyle"></tree-internal>`,
  directives: [TreeInternalComponent]
})
export class KyTreeComponent implements OnInit {
  @Input()
  private tree: TreeModel;

  @Input()
  private treeStyle: TreeStyle;

  @Output()
  private nodeSelected: EventEmitter<any> = new EventEmitter();

  constructor(@Inject(TreeService) private treeService: TreeService) {
  }

  public ngOnInit(): void { 

    this.treeService.nodeSelected$.subscribe((e: NodeEvent) => {
      this.nodeSelected.emit(e);
    });
   
  }
}
export const KY_TREE_DIRECTIVES = [KyTreeComponent];
