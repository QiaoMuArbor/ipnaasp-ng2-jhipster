import {Component, EventEmitter, Input, Output} from "@angular/core";

@Component({
  selector: 'ky-date',
  template: `
    <input [(ngModel)]="defaultValue" readonly="readonly" (blur)="onChange($event)" (focus)="onChange($event)"  type="text" onclick="WdatePicker({el:document.getElementsByName('query.startTime')[0],dateFmt:'yyyy-MM-dd HH:mm:ss',skin:'zte_date',preLoad:'true'})"
       class="Wdate" />
    `
})
export class DateComponent {

  @Output() inputChange:EventEmitter<any> = new EventEmitter();
  @Input() defaultValue:string;

  private onChange(value:any) {
    this.inputChange.emit(value);
  };
}
