import {Component, Input} from '@angular/core';

@Component({
  moduleId: module.id,
  selector: 'ky-breadcrumb',
  styleUrls:['ky-breadcrumb.css'],
  template: `
    <ol class="ky-breadcrumb">
      <sapn class="prefix">您现在所在的位置&nbsp;&nbsp;:&nbsp;&nbsp;</sapn>
      <li *ngFor="let link of links;let isLast=last">
        <a href="{{link.url}}" *ngIf="link.url&&!isLast">{{link.name}}</a>
        <span *ngIf="!link.url||isLast" [ngClass]="{curLink:isLast}">{{link.name}}</span>
        <span class="divider" *ngIf="!isLast">&gt;</span>
      </li>
    </ol>
  `
})

export class KyBreadcrumbComponent{
  @Input() links: any = [];
}
export const KY_BREADCRUMB_DIRECTIVES = [KyBreadcrumbComponent];
