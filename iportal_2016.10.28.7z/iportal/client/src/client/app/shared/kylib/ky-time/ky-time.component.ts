import { Component,Input,Output } from '@angular/core';
import {NgStyle} from '@angular/common';

@Component({
    selector: 'ky-time',
    template: `
<!--isShowClear:false-->
    <input readonly="readonly" type="text" onclick="WdatePicker({el:document.getElementsByName('query.startTime')[0],dateFmt:'HH:mm:ss',skin:'zte_time',preLoad:'true',isShowToday:false})"
       class="Wdate"/>
    `,

    directives: [NgStyle],
  styles: [`
  div.percent-text {
    margin-bottom:6px;
    font-size: 12px;
    color: #333;
    font-family:"Microsoft YaHei";
    margin:auto;
    width:300px;
}
div.progress {
    width: 300px;
    height:10px;
    background-color: #eeeeee;
    margin:auto;
}
  `]
})
export class TimeComponent {
	@Output() result:string;
}
