import {Component, Input, OnInit} from '@angular/core';

@Component({
  moduleId: module.id,
  selector: 'ky-notify',
  templateUrl: 'ky-notify.html',
  styleUrls:['ky-notify.css']
})

export class KyNotifyComponent implements OnInit {
  @Input() type: String;
  @Input() show: boolean;
  @Input() errMsgs: string[] = [];
  tipClass: any = {};

  ngOnInit() {
    let tipTypeList = ['alert', 'success'];

    if (_.contains(tipTypeList, this.type)) {
      this.tipClass[`${this.type}`] = true;
    } else {
      this.tipClass[`success`] = true;
    }
  }

  closeTip(index) {
    this.errMsgs.splice(index, 1);
  }
}
