
import {Directive, TemplateRef} from '@angular/core';
import {KyTabDirective} from './ky-tab.directive';



@Directive({selector: '[kytabHeading]'})
export class KyTabHeadingDirective {
  public templateRef:TemplateRef<any>;
  public constructor(templateRef:TemplateRef<any>, tab:KyTabDirective) {
    tab.headingRef = templateRef;
  }
}

