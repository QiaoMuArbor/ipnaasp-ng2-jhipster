import {Component, Input, AfterViewInit} from '@angular/core';

@Component({
  moduleId: module.id,
  selector: 'ky-help',
  template: `
    <i class="tip-imag" data-toggle="tooltip" data-placement="right" [title]="title"></i>
  `,
  styleUrls: ['ky-help.css']
})

export class KyHelpComponent implements AfterViewInit {
  @Input() title: String;

  ngAfterViewInit() {
    $('[data-toggle="tooltip"]').tooltip();
  }
}

