import {Component, Input} from '@angular/core';
@Component({
    selector: 'ky-pagenotfound',

    template: `
 
<div class="row">
    <div class="left">
        <img src="images/kylib/404page.png">
    </div>
    <div class="right">
        <p class="p-align">这个页面打不开了</p>
        <br>
        <span class="span-align">您可以尝试返回 <a href="{{startpage}}" class="link-404">首页</a> 或再次 <a href="" onclick="history.back(-1);"
                                                                       class="link-404">刷新</a></span>
    </div>
    </div>
	`,
    styles: [`
		 .left {
            position: relative;
            float: left;
            margin-left: 5%;
           
        }

        .right {
            position: relative;
            float:left;
            margin-left: 30px;
            font-family:"Microsoft YaHei";
        }
		a.link-404 {  
			color:#1898eb;
			font-family:"Microsoft YaHei";
		}
		
		p.p-align {
  font-size:24px;
  color:#333333;
  margin-top:70px;
  margin-bottom: 22px;
}

span.span-align{
  font-size:14px;
  color:#666666;
  margin-top:0px;
}
		
	`]
})
export class PageNotFoundComponent {
    @Input() startpage:string;
}
