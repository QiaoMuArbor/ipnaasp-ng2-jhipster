import { Component,Input,Output } from '@angular/core';
import {NgStyle} from '@angular/common';

@Component({
    selector: 'ky-calendar',
    template: `
    <input readonly="readonly" type="text" onclick="WdatePicker({el:document.getElementsByName('query.startTime')[0],dateFmt:'yyyy-MM-dd',skin:'zte_calendar',preLoad:'true'})"
       class="Wdate"/>
    `,
	styles:[`
		div.percent-text {
			margin-bottom:6px;
			font-size: 12px;
			color: #333;
			font-family:"Microsoft YaHei";
			margin:auto;
			width:300px;
		}
		div.progress {
			width: 300px;
			height:10px;
			background-color: #eeeeee;
			margin:auto;
		}
	`],
 directives: [NgStyle]
})
export class CalendarComponent {
	@Output() result:string;
}
