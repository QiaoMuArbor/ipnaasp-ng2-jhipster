import {Component, Input, Output, EventEmitter, OnInit} from '@angular/core';
import {NgClass} from '@angular/common';
import {KyButtonComponent} from "../index";


@Component({
    moduleId: module.id,
    selector: 'ky-modal',
    styleUrls: ['./ky-modal.css'],
    templateUrl: './ky-modal.component.html',
    directives: [NgClass, KyButtonComponent]
})

export class KyModalComponent {
    @Input() title:string = '确认';
    @Input() type:string = '';
    @Input() message:string = '确认要执行此操作么？';
    @Input() confirmText:string = '确认';
    @Input() cancelText:string = '取消';
    @Input() id:string;
    @Input() conformButtonType:string;

    iconType ='question';
    iconClass :any = {'fa-question-circle':false,
        'fa-check-circle':false,
        'fa-exclamation-circle':false};

    typeList = ['question', 'check', 'exclamation']

    @Output() actionButtonDown = new EventEmitter();

    confirmButtonDown() {
        this.actionButtonDown.emit("event");
    }

    determine() {
        let that = this;
        if(that.type && _.contains(that.typeList,that.type)){
            that.iconType = that.type;
        }
        that.iconClass[`fa-${that.iconType}-circle`] = true;
        that.iconClass[`ky-modal-${that.iconType}-icon`] = true;
    }

    ngOnInit() {
        this.determine();
    }

}

