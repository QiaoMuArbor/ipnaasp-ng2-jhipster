import {Directive, TemplateRef, ViewContainerRef, Inject} from '@angular/core';

export interface KeyAttribute {
  [key:string]:any;
}

@Directive({
  selector: '[kyTransclude]',
  properties: ['kyTransclude']
})
export class KyTranscludeDirective {
  public viewRef:ViewContainerRef;

  private _ngTransclude:TemplateRef<any>;

  private set kyTransclude(templateRef:TemplateRef<any>) {
    this._ngTransclude = templateRef;
    if (templateRef) {
      this.viewRef.createEmbeddedView(templateRef);
    }
  }

  private get kyTransclude():TemplateRef<any> {
    return this._ngTransclude;
  }

  public constructor(@Inject(ViewContainerRef) _viewRef:ViewContainerRef) {
    this.viewRef = _viewRef;
  }
}