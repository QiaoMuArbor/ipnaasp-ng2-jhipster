import {
  forwardRef,
  Component,
  Input,
  EventEmitter,
  Output
} from '@angular/core';

import {NG_VALUE_ACCESSOR, ControlValueAccessor} from '@angular/forms';
import {UUID} from 'angular2-uuid';
import {Observable} from 'rxjs/Observable';
import {BooleanFieldValue} from '../core/boolean-field-value'

const noop = () => {};

export const KY_TEXT_INPUT_CONTROL_VALUE_ACCESSOR: any = {
  provide: NG_VALUE_ACCESSOR,
  useExisting: forwardRef(() => KyTextInput),
  multi: true
};

@Component({
  moduleId: module.id,
  selector: 'ky-text-input',
  templateUrl: 'ky-text-input.html',
  styleUrls: ['ky-text-input.css'],
  providers: [KY_TEXT_INPUT_CONTROL_VALUE_ACCESSOR]
})

export class KyTextInput implements ControlValueAccessor {
  private _focused: boolean = false;
  private _value: any = '';

  /** Callback registered via registerOnTouched (ControlValueAccessor) */
  private _onTouchedCallback: () => void = noop;
  /** Callback registered via registerOnChange (ControlValueAccessor) */
  private _onChangeCallback: (_: any) => void = noop;

  /** Readonly properties. */
  get empty() { return this._value == null || this._value === ''; }
  get inputId(): string { return `${this.id}`; }
  get isShowHintLabel(){ return this._focused && this.hintLabel!='';}

  @Input() id: string = `ky-input-${UUID.UUID()}`;
  @Input() name: string = null;
  @Input() hintLabel: string = '';
  @Input() @BooleanFieldValue() disabled: boolean = false;

  @Input() max: string | number = null;
  @Input() maxLength: number = null;
  @Input() min: string | number = null;
  @Input() minLength: number = null;
  @Input() placeholder: string = '';
  @Input() @BooleanFieldValue() readOnly: boolean = false;
  @Input() @BooleanFieldValue() required: boolean = false;
  @Input() type: string = 'text';
  @Input() tabIndex: number = null;
  @Input() pattern: string = '';

  private _blurEmitter: EventEmitter<FocusEvent> = new EventEmitter<FocusEvent>();
  private _focusEmitter: EventEmitter<FocusEvent> = new EventEmitter<FocusEvent>();

  @Output('blur')
  get onBlur(): Observable<FocusEvent> {
    return this._blurEmitter.asObservable();
  }

  @Output('focus')
  get onFocus(): Observable<FocusEvent> {
    return this._focusEmitter.asObservable();
  }

  get value(): any { return this._value; };
  @Input() set value(v: any) {
    v = this._convertValueForInputType(v);
    if (v !== this._value) {
      this._value = v;
      this._onChangeCallback(v);
    }
  }

  _handleFocus(event: FocusEvent) {
    this._focused = true;
    this._focusEmitter.emit(event);
  }

  _handleBlur(event: FocusEvent) {
    this._focused = false;
    this._onTouchedCallback();
    this._blurEmitter.emit(event);
  }

  _handleChange(event: Event) {
    this.value = (<HTMLInputElement>event.target).value;
    this._onTouchedCallback();
  }

  /**
   * Implemented as part of ControlValueAccessor.
   * TODO: internal
   */
  writeValue(value: any) {
    this._value = value;
  }

  /**
   * Implemented as part of ControlValueAccessor.
   * TODO: internal
   */
  registerOnChange(fn: any) {
    this._onChangeCallback = fn;
  }

  /**
   * Implemented as part of ControlValueAccessor.
   * TODO: internal
   */
  registerOnTouched(fn: any) {
    this._onTouchedCallback = fn;
  }

  private _convertValueForInputType(v: any): any {
    switch (this.type) {
      case 'number': return parseFloat(v);
      default: return v;
    }
  }
}

export const KY_TEXT_INPUT_DIRECTIVES = [KyTextInput];
