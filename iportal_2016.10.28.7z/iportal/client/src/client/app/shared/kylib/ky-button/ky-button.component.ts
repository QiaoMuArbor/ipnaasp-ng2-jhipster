import {Component, Input} from '@angular/core';

@Component({
  moduleId: module.id,
  selector: 'ky-button',
  templateUrl: 'ky-button.html',
  styleUrls:['ky-button.css']
})

export class KyButtonComponent {
  @Input() type: String;
  @Input() disabled: boolean;

  buttonClass: any = {};
  isShowCreateIcon: boolean = false;

  ngOnInit() {
    let buttonTypeList = ['common', 'create', 'cancel', 'warning', 'table-footer'];

    if(_.contains(buttonTypeList, this.type)) {
      this.buttonClass[`ky-${this.type}-button`] = true;
    } else {
      this.buttonClass[`ky-common-button`] = true;
    }

    this.isShowCreateIcon = this.type === 'create';
  }
}

export const KY_BUTTON_DIRECTIVES = [KyButtonComponent];

