import {Component, Input, Output, EventEmitter, forwardRef, OnInit} from '@angular/core';
import { NG_VALUE_ACCESSOR, ControlValueAccessor } from '@angular/forms';

/*all below codes are for the [(ngModel)]  for the custom by-select component*/
const noop = () => {};

export const CUSTOM_KYSELECTCOMPONENT_CONTROL_VALUE_ACCESSOR: any = {
  provide: NG_VALUE_ACCESSOR,
  useExisting: forwardRef(() => KySelectComponent),
  multi: true
};
/*all up codes are for the [(ngModel)]  for the custom by-select component*/

@Component({
  moduleId: module.id,
  selector: 'ky-select',
  templateUrl: 'ky-select.component.html',
  styleUrls: ['ky-select.component.css'],
  providers:[CUSTOM_KYSELECTCOMPONENT_CONTROL_VALUE_ACCESSOR],
})

export class KySelectComponent implements ControlValueAccessor {

  // @Input() selected:any;
  @Input() placeholder:string="请选择";
  @Input() options: any[];
  @Input() disabled: any;
  @Input() identifyValue:any;
  //set ngModel bind value
  @Input() ngModelBindVaule:any='';

  NgModelBindVaule(inputOption:any):any{
    if(this.ngModelBindVaule===-1)
    {
      return -1;
    }
    else{
      if(this.ngModelBindVaule==null || this.ngModelBindVaule===''){
          return inputOption;
      }
      else{
        return inputOption[this.ngModelBindVaule];
      }
    }
  }

  //what the select dropdown show in the menu
  @Input() public displayBy: string;

  public displayValue(item:any): string {
    return this.displayBy ? item[this.displayBy] : item;
  }
  /*all below codes are for the [(ngModel)]  for the custom by-select component*/
  private innerValue: any = '';

  private onTouchedCallback: () => void = noop;
  private onChangeCallback: (_: any) => void = noop;

  get value(): any {
    return this.innerValue;
  }

  set value(v: any) {
    if (v !== this.innerValue) {
      this.innerValue = typeof(v) == 'object'&& v != null ? this.NgModelBindVaule(v): v;
      this.onChangeCallback(v);
    }
  }

  onBlur() {
    this.onTouchedCallback();
  }

  writeValue(value: any =-1) {
    if (value !== this.innerValue) {
      this.innerValue = typeof(value) == 'object' && value != null? this.NgModelBindVaule(value): value;
    }

  }

  registerOnChange(fn: any) {
    this.onChangeCallback = fn;
  }

  registerOnTouched(fn: any) {
    this.onTouchedCallback = fn;
  }
  /*all up codes are for the [(ngModel)]  for the custom by-select component*/
}

export const KY_SELECT_DIRECTIVES = [KySelectComponent];
