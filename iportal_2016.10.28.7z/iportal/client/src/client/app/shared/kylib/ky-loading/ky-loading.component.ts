import {Component, Input} from '@angular/core';

@Component({
  moduleId: module.id,
  selector: 'ky-loading',
  styleUrls:['ky-loading.css'],
  template: `
    <div class="ky-loading" *ngIf="show" [ngClass]="{'use-background':usebackground}">
       <i class="fa fa-spinner fa-pulse fa-fw"></i>
       <span>加载中...</span>
    </div>
  `
})

export class KyLoadingComponent{
  @Input() show: boolean;
  @Input() usebackground:boolean;
}
export const KY_LOADING_DIRECTIVES = [KyLoadingComponent];
