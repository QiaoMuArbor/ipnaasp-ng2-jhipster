export interface PieData {
    value:number,
    name:string,
    color?:string
}


export interface Pie {
  data:PieData[],
  title:string,
  pieName:string,
  pieSubName:string
}


export interface LegendData {
  name: string,
  icon: string
}

export interface SeriesData {
  value: number,
  name: string,
  itemStyle: {
    normal: {
      color: string
    },emphasis?: {
      color: string
    }
  }
}
