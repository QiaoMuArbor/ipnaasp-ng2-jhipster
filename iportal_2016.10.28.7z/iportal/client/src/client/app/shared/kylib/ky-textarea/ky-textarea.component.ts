import {Component, Input,OnInit} from '@angular/core';

@Component({
  moduleId: module.id,
  selector: 'ky-textarea',
  styleUrls:['ky-textarea.css'],
  template: `
<label class="ky-class-vertical-align-top">{{labelContext}}</label>
<textarea class="ky-class-textarea"  [attr.maxlength]="maxlen" [(ngModel)]="textContext">{{defaultContext}}</textarea>
<div>
<label class="ky-class-vertical-align-right" >({{textContext.length}}/{{maxlen}})</label>
</div>
  `
})

export class KyTextAreaComponent implements OnInit{
  @Input() maxlen: number;
  @Input() defaultContext:string;
  @Input() labelContext:string;
  useContextLength:number;
  private textContext: string = '';
  public ngOnInit():void {
    this.useContextLength = this.defaultContext.length;
    this.textContext = this.defaultContext;
  }

}
export const KY_TEXTAREA_DIRECTIVES = [KyTextAreaComponent];
