import { Component, ElementRef, ViewChild, Input, ViewEncapsulation, EventEmitter, Output } from '@angular/core';
import { AgGridNg2 } from 'ag-grid-ng2/main';
import * as _ from 'underscore';
import { UUID } from 'angular2-uuid';
import { KY_BUTTON_DIRECTIVES } from "../ky-button/ky-button.component";

@Component({
  moduleId: module.id,
  selector: 'ky-grid',
  templateUrl: 'ky-grid.html',
  styleUrls: ['ky-grid.css'],
  directives: [AgGridNg2, KY_BUTTON_DIRECTIVES],
  encapsulation: ViewEncapsulation.None
})

export class KyGridComponent {
  private defaultGridOptions:any = {
    rowSelection: 'multiple',
    rowClass: 'ky-grid-row',
    headerHeight: 36,
    rowHeight: 36,
    enableSorting: true,
    suppressCellSelection: true,
    suppressRowClickSelection: true,
    overlayNoRowsTemplate: `<div class="ky-grid-noData-row">没有记录</div>`,
    showCheckbox: true,
    icons: {
      checkboxChecked: '<img src="images/icon_select_selected.png">',
      checkboxUnchecked: '<img src="images/icon_select_disabled.png">'
    }
  };

  private _gridOptions:any = this.defaultGridOptions;
  private minPageSize:number = 10;
  private pageSize:number = 10;
  private currentPageRowCount:number = 0;
  private gridHeight:string;
  private isEmptyData = true;
  private times:number = 0;

  pagePanelId:string = UUID.UUID();

  @Input() columnDefs:any[] = [];
  @Input() data:any[] = [];
  @Input() rowCount:number;

  @Input()
  get gridOptions() {
    return this._gridOptions;
  };

  set gridOptions(options:any) {
    if (options) {
      this._gridOptions = _.extend(this.defaultGridOptions, options);
    }
  };

  @Output() selectionChanged:EventEmitter<any> = new EventEmitter();


  private setModelType(rowModelType:string) {
    this._gridOptions.rowModelType = rowModelType;
  }

  private setGridData() {
    this.setModelType('pagination');
    this.setDataSource();
  }

  private getDataSourceRows(params:any) {
    if (this.data.length == 0) {
      this.isEmptyData = true;
      this.currentPageRowCount = 1;
      params.successCallback([], 0);
    } else if (this.data.length == this.rowCount) {
      this.isEmptyData = false;
      let currentPageData = this.data.slice(params.startRow, params.endRow);
      this.currentPageRowCount = currentPageData.length;
      params.successCallback(currentPageData, this.rowCount);
    } else {
      this.isEmptyData = false;
      this.currentPageRowCount = this.data.length;
      params.successCallback(this.data, this.rowCount);
    }
  }

  private setDataSource() {
    let _datasource:any = {
      pageSize: this.pageSize,
      rowCount: this.rowCount,
      getRows: params => this.getDataSourceRows(params)
    };
    setTimeout(()=>this._gridOptions.api.setDatasource(_datasource), 0);
  }

  private setGridCellClass() {
    _.map(this._gridOptions.columnDefs, function (cloumnDef:any) {
      if (cloumnDef.align == 'center') {
        cloumnDef.cellClass = 'ky-grid-cell-align-center';
      } else {
        cloumnDef.cellClass = 'ky-grid-cell-align-left';
      }
    });
  }

  @ViewChild('grid') grid:ElementRef;

  ngAfterViewChecked() {
    this._gridOptions.columnApi.sizeColumnsToFit(this.grid.elementDef.nativeElement.clientWidth);
  }

  onFilterChanged(newFilter) {
    setTimeout(() => this._gridOptions.api.setQuickFilter(newFilter), 100);
  }

  private getGridHeight() {
    return this._gridOptions.headerHeight + (this.currentPageRowCount + 1) * this._gridOptions.rowHeight + 19 + 'px';
  }

  checkboxHeaderRendererFunc(params) {
    let that = this;
    let eHeader = document.createElement('div');
    eHeader.className = 'ky-grid-checkbox-header';
    let cb = document.createElement('input');
    cb.setAttribute('type', 'checkbox');
    eHeader.appendChild(cb);

    cb.addEventListener('change', function (e) {
      if ($(this)[0].checked) {
        setTimeout(() => that._gridOptions.api.selectAll(), 0);
      } else {
        setTimeout(() => that._gridOptions.api.deselectAll(), 0);
      }
    });

    return eHeader;
  }

  private setCheckBoxSelection() {
    if (this.data.length > 0 && this._gridOptions.showCheckbox) {
      let checkboxConfig = {
        headerCellTemplate: params => this.checkboxHeaderRendererFunc(params),
        checkboxSelection: true,
        width: 36,
        align: 'center'
      };
      if (this.times > 0) {
        this._gridOptions.columnDefs.shift();
        this.times--;
      }
      this._gridOptions.columnDefs.unshift(checkboxConfig);
      this.times++;
      setTimeout(()=>this.setFooterCheckBoxSelection(), 0);
    }
  }

  private setPageGroup() {
    setTimeout(()=>
      document.getElementById(`pageGroup-${this.pagePanelId}`).hidden = this.rowCount >= 0 && this.rowCount <= this.minPageSize, 0);
  }

  private setColumnClass() {
    for (let columnDef of this._gridOptions.columnDefs) {
      if (!columnDef.headerCellTemplate || columnDef.headerCellTemplate == '') {
        columnDef.headerClass = 'ky-grid-header';
      }
    }
  }

  ngOnChanges() {
    this.rowCount = this.data.length;
    this.setGridData();
    this.gridHeight = this.getGridHeight();
    this._gridOptions.columnDefs = this.columnDefs;
    this.setCheckBoxSelection();
    this.setColumnClass();
    this.setGridCellClass();
    this.setPageGroup();
    setTimeout(()=> {
      this.setGridOperation();
      this._gridOptions.api.setColumnDefs(this._gridOptions.columnDefs);
      this._gridOptions.api.refreshView();
    }, 0);
  }

  ngAfterViewInit() {
    document.getElementById('pagePanel').id = `pagePanel-${this.pagePanelId}`;
    document.getElementById('pageGroup').id = `pageGroup-${this.pagePanelId}`;
  }

  setFooterCheckBoxSelection() {
    let that = this;
    let ePagePanel = document.getElementById(`pagePanel-${this.pagePanelId}`);
    $('.ky-grid-footer-checkbox').remove();
    let cb = document.createElement('input');
    cb.setAttribute('type', 'checkbox');
    cb.className = 'ky-grid-footer-checkbox';
    ePagePanel.appendChild(cb);

    cb.addEventListener('change', function (e) {
      if ($(this)[0].checked) {
        setTimeout(() => that._gridOptions.api.selectAll(), 0);
      } else {
        setTimeout(() => that._gridOptions.api.deselectAll(), 0);
      }
    });
  }

  private setGridOperation() {
    let that = this;
    let ePagePanel = document.getElementById(`pagePanel-${this.pagePanelId}`);
    $('.ky-table-footer-button').remove();
    let isDisabled = this.isOperationButtonDisabled();
    for (let index in this._gridOptions.operations) {
      let bt = document.createElement('button');
      let operation = that._gridOptions.operations[index];
      bt.setAttribute('id', `button-${this.pagePanelId}-${index + 1}`);
      bt.innerText = operation.text;
      bt.className = 'ky-table-footer-button';
      bt.style.position = 'absolute';
      bt.style.left = index * 100 + 50 + 'px';
      bt.disabled = isDisabled;
      ePagePanel.appendChild(bt);

      bt.addEventListener('click', function (e) {
        operation.callback(that._gridOptions.api.getSelectedRows());
      });
    }
  }

  onSelectionChanged() {
    let isDisabled = this.isOperationButtonDisabled();
    for (let index in this._gridOptions.operations) {
      document.getElementById(`button-${this.pagePanelId}-${index + 1}`).disabled = isDisabled;
    }
    this.selectionChanged.emit(this._gridOptions.api.getSelectedRows());
  }

  private isOperationButtonDisabled() {
    return this._gridOptions.api.getSelectedRows().length == 0;
  }
}







