import {Component, ElementRef, Renderer, EventEmitter, Output, Input, SimpleChange} from '@angular/core';

/*An example of a customised slider:

$("#example").ionRangeSlider({
    min: 0,
    max: 10000,
    from: 1000,
    to: 9000,
    type: 'double',
    prefix: "$",
    grid: true,
    grid_num: 10
});
You can also initialise slider with data-* attributes of input tag:

data-step＝"1"
data-min="0"
data-max="10000"
data-from="1000"
data-to="9000"
data-type="double"
data-prefix="$"
data-postfix
data-grid="true"
data-grid-num="10"*/

@Component({
  selector: 'ion-slider',
  template: `
    <div class="range">
    <input type="text"/>
    </div>
    <div class="value">
      <input type="text" name="val" [(ngModel)]="val" (change)="setVal()"/>
      <span *ngIf="options.postfix">({{options.postfix}})</span>
    </div>
  `,
  styles: [`
  .range{
    width:400px;
    display:inline-block;
  }

  .value{
    display:inline-block;
    
    margin:0 20px;
    position: relative;
    top: 32px;
  }
  .value input{
    width:50px;
  }

  `]
})
export class IonSliderComponent {
  @Input() options: any;
  @Input() value: any;

  @Output() valueChange = new EventEmitter();

  val: string;

  private slider: any;
  private max: number;

  private confOptions: any;
  constructor(private renderer: Renderer, private el: ElementRef) {
    // code...
  }

  /*ngOnChanges(changes:{{ from: any, to: any }: SimpleChange}) {*/
  ngOnChanges(changes: { [propertyName: string]: SimpleChange }) {
    if (!changes.value) return;
    if (_.isEqual(changes.value.currentValue, changes.value.previousValue)) {
      return;
    }

    let that = this;
    this.confOptions = _.extend({
      grid: false,
      step: 1,
      hide_min_max: true,
      hide_from_to: true,
      onChange: function(a: any) {
        //console.log(a);
        that.setVal(a.from);
      },
      onFinish: function(a: any) {
        that.emitData();
      }
    }, this.options);

    let rangeDom = $(this.el.nativeElement).find(".range>input")[0];

    $(rangeDom).ionRangeSlider(this.confOptions);

    this.slider = $(rangeDom).data("ionRangeSlider");
    this.renderer.setElementStyle(this.el.nativeElement, "display", 'inline-block');

    this.val = this.value || 0;
    this.setVal(null);
  }
  ngOnDestroy() {
    // DESTROY - destroys slider and restores original input field
    this.slider.destroy();
  }

  setVal(val: number = null) {
    //console.log('setRange:' + sliderFrom + ',' + sliderTo);
    if (val!==null) {
      //滑动条移动了
      this.val = val + '';
      return;
    }

    let _from = this.val;
    if (!_from || isNaN(_from)) {
      this.val = this.confOptions.min;
    }
    if (this.val > this.confOptions.max) {
      this.val = this.confOptions.max;
    }

    this.slider.update({
      from: this.val || 0
    });

    this.emitData();
    return;
  }


  private emitData() {
    this.valueChange.emit((isNaN(this.val) ? null : this.val));
  }


}

