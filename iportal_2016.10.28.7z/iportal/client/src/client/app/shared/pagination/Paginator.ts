import {Component, EventEmitter, Input, Output} from '@angular/core';
import {BasePaginator} from './BasePaginator';

@Component({
    moduleId: module.id,
    selector: 'paginator',
    styleUrls: ['pagination.css'],
    template: `
<nav>
    <ul class="pagination">
        <li [ngClass]="{ 'disabled': currentPage === 1 }">
            <a (click)="changePage(1)">&lt;&lt;</a>
        </li>
        <li [ngClass]="{ 'disabled': currentPage === 1 }">
            <a (click)="changePage(currentPage - 1)" aria-label="Next">
                <span aria-hidden="true">&lt;</span>
            </a>
        </li>
        <li *ngFor="let page of getPages()" [ngClass]="{ 'active': currentPage === page }">
            <a (click)="changePage(page)">{{ page }}</a>
        </li>
        <li [ngClass]="{ 'disabled': currentPage === getTotalPagesCount() }">
            <a (click)="changePage(currentPage + 1)" aria-label="Previous">
                <span aria-hidden="true">&gt;</span>
            </a>
        </li>
        <li [ngClass]="{ 'disabled': currentPage === getTotalPagesCount() }">
            <a (click)="changePage(getTotalPagesCount())">&gt;&gt;</a>
        </li>
    </ul>
</nav>
`,
})
export class Paginator extends BasePaginator {
    @Input('total') total: number;
    @Input('onPage') onPage: number;
    @Input('maxVisible') maxVisible: number;
    @Input('tofirstpage') tofirstpage: boolean;
    @Output('onPageSelected') onPageSelected = new EventEmitter<any>();

    changePage(page: number): boolean {
        const isPageChanged = super.changePage(page);
        if (isPageChanged)
            this.onPageSelected.emit(page);

        return isPageChanged;
    }

}

