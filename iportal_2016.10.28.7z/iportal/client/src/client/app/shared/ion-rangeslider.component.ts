import {Component, ElementRef, Renderer, EventEmitter, Output, Input,SimpleChange} from '@angular/core';

/*An example of a customised slider:

$("#example").ionRangeSlider({
    min: 0,
    max: 10000,
    from: 1000,
    to: 9000,
    type: 'double',
    prefix: "$",
    grid: true,
    grid_num: 10
});
You can also initialise slider with data-* attributes of input tag:

data-step＝"1"
data-min="0"
data-max="10000"
data-from="1000"
data-to="9000"
data-type="double"
data-prefix="$"
data-postfix
data-grid="true"
data-grid-num="10"*/

@Component({
  selector: 'ion-rangeslider',
  template: `
    <div class="range">
    <input type="text"/>
    </div>
    <div class="from">
      最小值
      <input type="text" name="from" [(ngModel)]="from" (change)="setRange()"/>
      <span *ngIf="options.postfix">({{options.postfix}})</span>
    </div>
    <div class="to">
      最大值
      <input type="text" name="to" [(ngModel)]="to" (change)="setRange()"/>
      <span *ngIf="options.postfix">({{options.postfix}})</span>
    </div>
  `,
  styles: [`
  .range{
    width:400px;
    display:inline-block;
  }

  .from,.to{
    display:inline-block;
    
    margin:0 20px;
    position: relative;
    top: 32px;

  }
  .from input,.to input{
    width:50px;
  }

  `]
})
export class IonRangeSliderComponent {
  @Input() options: any;
  @Input() value: { from: any, to: any };

  @Output() valueChange = new EventEmitter();

  from: string;
  to: string;

  private slider: any;
  private max: number;

  private confOptions: any;
  constructor(private renderer: Renderer, private el: ElementRef) {
    // code...
  }

  /*ngOnChanges(changes:{{ from: any, to: any }: SimpleChange}) {*/
   ngOnChanges(changes: {[propertyName: string]: SimpleChange}) {
    if(_.isEqual(changes.value.currentValue,changes.value.previousValue)) {
      return;
    }

    let that = this;
    this.confOptions = _.extend({
      type: 'double',
      grid: false,
      step:1,
      hide_min_max: true,
      hide_from_to: true,
      onChange: function(a: any) {
        that.setRange(a.from, a.to);
      },
      onFinish: function(a: any) {
        that.emitData();
      }
    }, this.options);

    this.max = this.confOptions.max;
    this.confOptions.max += this.options.step;

    let rangeDom = $(this.el.nativeElement).find(".range>input")[0];

    $(rangeDom).ionRangeSlider(this.confOptions);

    this.slider = $(rangeDom).data("ionRangeSlider");
    this.renderer.setElementStyle(this.el.nativeElement, "display", 'inline-block');

    this.from = this.value.from || '';
    this.to = this.value.to || 'max';
    this.setRange(null,null);
  }
  ngOnDestroy() {
    // DESTROY - destroys slider and restores original input field
    this.slider.destroy();
  }

  setRange(sliderFrom: number = null, sliderTo: number = null) {
    //console.log('setRange:' + sliderFrom + ',' + sliderTo);

    if (sliderFrom || sliderTo) {
      //滑动条移动了
      if (this.confOptions.max == sliderTo) {
        this.to = 'max';
      }
      else {
        this.to = sliderTo + '';
      }

      if (this.confOptions.max == sliderFrom) {
        this.from = '0';
      } else {
        this.from = sliderFrom + '';
      }
      return;
    }

    let to = this.to;
    if (!this.to || isNaN(this.to)) {
      to = this.confOptions.max;
      this.to = 'max';
    }
    if (!this.from || isNaN(this.from)) {
      this.from = this.confOptions.min;
    }

    this.slider.update({
      from: this.from || 0,
      to: to
    });

    this.emitData();
    return;
  }


  private emitData(){
    let outputData = { from: isNaN(this.from) ? null : this.from, to: isNaN(this.to) ? null : this.to };
    this.valueChange.emit(outputData);
  }


}

