import { Component, Input, Output, EventEmitter, ViewChild } from '@angular/core';
import { MODAL_DIRECTIVES, ModalComponent } from 'ng2-bs3-modal/ng2-bs3-modal';

@Component({
  moduleId:module.id,
  selector: 'zte-modal-del',
  templateUrl:'modal-del.component.html' ,
  styleUrls:[],
  directives:[MODAL_DIRECTIVES],
  providers:[]
})

export class ModalDeleteComponent {
  @ViewChild('modal') modal: ModalComponent;
  @Input() content:string;
  @Input() type:string;
  @Output() delChange = new EventEmitter<any>();
  constructor() {
  }
  del() {
    this.delChange.emit(true);
    this.modal.close();
  }
}
