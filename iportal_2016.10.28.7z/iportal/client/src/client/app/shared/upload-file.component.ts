import {Component, Input,AfterContentInit,ElementRef,Renderer} from '@angular/core';
import {FILE_UPLOAD_DIRECTIVES, FileUploader} from 'ng2-file-upload/ng2-file-upload';

// const ip address
//const URL = '/api/swr/slimage/upload?resourcetype=servicelet&name=upload_test&vertype=5g_test&version=v1.0';

@Component({
  selector: 'upload-file',
  template: `
<div>
    <a class="uploadBtn" href="javascript:;">
        <span class="btnVal"><i class="fa fa-upload" aria-hidden="true"></i>&nbsp;&nbsp;{{btnVal||"上传文件"}}</span>
        <input type="file" ng2FileSelect [uploader]="uploader" />
    </a>
    <div *ngIf="uploader.queue.length > 0" class="uploadInfo">
      <span>{{uploader.queue[uploader.queue.length-1].file?.name}}</span>
      <span>({{uploader.queue[uploader.queue.length-1].file?.size/1024/1024 | number:'.2' }} MB)</span>
      <span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;进度&nbsp;&nbsp;</span>
      <div class="upload-process">
        <!--<span *ngIf="uploader.queue[uploader.queue.length-1].isUploading">上传中...</span>-->
        <!--<span *ngIf="uploader.queue[uploader.queue.length-1].isSuccess">上传成功!</span>-->
        <span *ngIf="uploader.queue[uploader.queue.length-1].isError">上传失败!</span>
        <span *ngIf="uploader.queue[uploader.queue.length-1].progress==0">等待上传</span>
        <span *ngIf="uploader.queue[uploader.queue.length-1].progress>0" class="upload-progress">
        {{uploader.queue[uploader.queue.length-1].progress}}%
        </span>
        <span *ngIf="uploader.queue[uploader.queue.length-1].progress>0" [style.width.%]="uploader.queue[uploader.queue.length-1].progress" class="progress-active"></span>
       
      </div>
       <a style="margin-left: 20px" href="javascript:;" (click)="del(uploader.queue[0])">删除</a>
    </div>   
</div>
  `,
  directives: [FILE_UPLOAD_DIRECTIVES],
  styles:[`
    a.uploadBtn{
      min-width: 120px;
      height: 32px;
      color: #fff;
      background-color: #5cb85c;
      cursor: pointer;
      display: inline-block;
      border-radius: 3px;
      position: relative;
      padding: 0 10px;
    }
    a.uploadBtn span.btnVal{
      position: absolute;
      width: 100%;
      line-height: 32px;
      text-align: center;
      color: #fff;
      margin: 0;
      top: 0;
      left: 0;
    }
    a.uploadBtn input[type='file']{
      width: 220px;
      height: 32px;
      opacity: 0;
      margin-left: -100px;
    }
    div.uploadInfo{
      display: inline-block;
      vertical-align: sub;
      margin-left: 30px;
    }
    span.upload-progress{
      display: inline-block;
      height: 20px;
      width: 100px;
      position: absolute;
      bottom: 14px;
      left: 0;
      width: 100%;
    }
    div.upload-process{
      display: inline-block;
      background: #f3f3f3;
      width: 200px;
      text-align: center;
      border-radius: 3px;
      font-size: 12px;
      position: relative;
      height: 16px;
      vertical-align: middle;
    }
    span.progress-active{
      background-color: #5CB85C;
      height: 16px;
      display: inline-block;
      position: absolute;
      left: 0;
      border-radius: 3px;
    }
  `]
})

export class UploadFileComponent implements AfterContentInit {
  @Input() uploader:FileUploader;
  @Input() btnVal:string;

  constructor(private el:ElementRef,private rander:Renderer) {
    this.rander.setElementStyle(this.el.nativeElement,'display','inline-block');
  }

  ngAfterContentInit() {
    this.uploader.options.headers = [{name:"Access-Token",value:localStorage.getItem("Access-Token")}];
    this.uploader.onAfterAddingFile = function(item:any){
        if(this.uploader && this.uploader.queue.length>1){
          this.uploader.queue = [item.uploader.queue.pop()];
        }else{
          this.uploader = item.uploader;
        }
    }
  }

  del(item: any){
    item.remove();
    this.el.nativeElement.getElementsByTagName("input")[0].value = "";
  }
}

