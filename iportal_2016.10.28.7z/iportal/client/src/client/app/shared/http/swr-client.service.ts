// Observable Version
import { Injectable }     from '@angular/core';
import { Observable }     from 'rxjs/Observable';
import { AuthHttp }  from './auth-http.service';
import { FileUploader} from 'ng2-file-upload/ng2-file-upload';
import { ActiveProjectService } from '../../app.service';

export class ImageTagInfo {
  constructor(
    public describe:any={},
    public isPublic:boolean
    ){ 
  }
}

@Injectable()
export class SwrClientService {
  private API_URL = '/api/swr/v1/tenants';  // URL to web API
  //private API_URL = '/api/srepoworker/v1.0';  // URL to web API
  private tenant_id:string = '';
  constructor(private authHttp: AuthHttp,private activeProjectService:ActiveProjectService ) {
    this.tenant_id = this.activeProjectService.id;
  }

  getImageList(name?:string,version?:string){
    let url = `${this.API_URL}/${this.tenant_id}/images?1=1`;
    if(version) {
      url+=`&version=${version}`
    }
    if(name) {
      url+=`&name=${name}`
    }
    return this.authHttp.get(url)
          .map(res=>res.list||[])
          .map(list=>_.map(list,function(image){image.tagNum=image.tags.length; return image;}));
  }

  getPubilcImageList(reponame?:string,name?:string){
    let url = `${this.API_URL}/${this.tenant_id}/images?publicview=yes`;
    if(reponame) {
      url+=`&reponame=${reponame}`
    }
    if(name) {
      url+=`&name=${name}`
    }
    return this.authHttp.get(url)
          .map(res=>res.list||[])
          .map(list=>_.map(list,function(image){image.tagNum=image.tags.length; return image;}));
  }

  getTagVersionList(name?:string) {
    let url = `${this.API_URL}/${this.tenant_id}/images?1=1`;
    if(name) {
      url+=`&name=${name}`
    }
    let versionList:any;
    return this.authHttp.get(url)
          .map(res=>res.list[0].tags||[]);

  }

  getPublicTagVersionList(reponame?:string,name?:string){
    let url = `${this.API_URL}/${this.tenant_id}/images?publicview=yes`;
    if(reponame) {
      url+=`&reponame=${reponame}`
    }
    if(name) {
      url+=`&name=${name}`
    }
    return this.authHttp.get(url)
          .map(res=>res.list[0].tags||[]);
    
  }

  getImageByName(name:string,reponame?:string){
    if(reponame && this.activeProjectService.id != reponame) {
      return this.getPubilcImageList(reponame,name).map(list=>list[0]||{});
    }else{
      return this.getImageList(name).map(list=>list[0]||{});
    }
  }


  deleteImage(image:any){
    let that = this;
    return Observable.from(image.tags)
          .flatMap((tag)=>{
            return this.deleteImageTag(tag.id);
          })
          .toArray();
  }

  deleteImageTag(id:string){
    let that = this;
    return that.authHttp.delete(`${this.API_URL}/${this.tenant_id}/images/${id}`)
                .map(res => { return res;})
  }

  getImageTag(id:string){
      let that = this;
      return that.authHttp.get(`${this.API_URL}/${this.tenant_id}/images/${id}`)
                  .map(res => { return res;})
  }

  getTagIdByNameAndTag(name:string,version:string){
    let that = this;
    return that.getImageList(name,version)
              .map(res =>{
                  let image =  (res[0])||{} ;
                  let tag = _.findWhere(image.tags,{"version":version});
                   if(!tag) {
                      throw({message:'Not found tag!'});
                   }
                  return tag.id;
              });
  }

  importImage(name:string,version:string,tarUploader:FileUploader,tagInfo:ImageTagInfo){
    return this.uploadImageFile(name,version,tarUploader)
           .flatMap(()=>{
             return this.getTagIdByNameAndTag(name,version);
           })
        .flatMap( tagId =>{
              return this.updateImageTagInfo(tagId,tagInfo);
          })
  }

  buildBin2Image(name:string,version:string,tarUploader:FileUploader,tagInfo:ImageTagInfo){
    return this.uploadBinFiles(name,version,tarUploader)
          .flatMap(()=>{
             return this.build(name,version);
           })  
          .flatMap(()=>{
             return this.getTagIdByNameAndTag(name,version);
           })
          .flatMap( tagId =>{
                return this.updateImageTagInfo(tagId,tagInfo);
            })    
  }

  updateImageTagInfo(id:string,tagInfo:ImageTagInfo){
    let that = this;
    let body= {"desc": JSON.stringify(tagInfo.describe) ,"publicview":(tagInfo.isPublic?"yes":"no")}
    return that.authHttp.put(`${this.API_URL}/${this.tenant_id}/images/${id}`,body);
  }
  updateImageTagDescribe(id:string,describe:any){
    let that = this;
    let body= {"desc": JSON.stringify(describe)}
    return that.authHttp.put(`${this.API_URL}/${this.tenant_id}/images/${id}`,body);
  }
  updateImageTagPublic(id:string,isPublic:boolean){
    let that = this;
    let body = {"publicview":(isPublic?"yes":"no")}
    return that.authHttp.put(`${this.API_URL}/${this.tenant_id}/images/${id}`,body);
  }
  

  uploadImageFile(name:string,version:string,uploader:FileUploader){
    let that = this;
    return this.uploadFile('upload',name,version,uploader);
  }
  uploadBinFiles(name:string,version:string,uploader:FileUploader){
    let that = this;
    return this.uploadFile('build',name,version,uploader);
  }

  private uploadFile(filetype:string,name:string,version:string,uploader:FileUploader){
    let that = this;
    return Observable.create((observer:any) => {
      _.each(uploader.queue, function(q:any) {
        q.url = that.API_URL + "/" + that.tenant_id + '/images/'+filetype+'?name=' + name + '&version=' + version;
        console.log(q.url)
        q.upload();
      });

      uploader.onErrorItem = function(item: any, response: any, status: any, headers: any) {
        observer.error({ message: item.file.name + '上传失败，' + response });
        return  observer.complete();
      };
      uploader.onCompleteAll = function() {
        let errorItem = _.findWhere(uploader.queue, { isError: true });
        if (!errorItem) {
          observer.next('upload success');
          return  observer.complete();
        }
      };
    });
  }
  
  private build(name:string,version:string){
    let that = this;
    return that.authHttp.put(`${this.API_URL}/${this.tenant_id}/images/build?&name=${name}&version=${version}`,{});
  }



}



  // getImageTagsList(name:string):Observable<Image[]> {
  //       let that = this;
  //       return that.authHttp.get(`${this.API_URL}/${this.tenant_id}/images?name=${name}`)
  //               .map(res => { return res;});
  // }

  // getPublicTmageTagesList(name:string){
  //   return this.authHttp.get(`${this.API_URL}/${this.tenant_id}/images`)
  //             .map(res =>{
  //                 let images:Array<Image>;
  //                 images =  _.map(res.list,function (_reponame) {
  //                   return _reponame.reponame == this.tenant_id && _reponame.name == name;
  //                 });

  //                 let tages:Array<ImageTag>;
  //                 tages = _.map(images.tags,function(tag){
  //                       return tag.publicview == "yes";
  //                 });
  //                 images.tags = tages;
  //                 return {"list":images};
  //             });
  // }

  // getImage(name:string,version:string):Observable<Image> {
  //       let that = this;
  //       return that.authHttp.get(`${this.API_URL}/${this.tenant_id}/images?name=${name}&version=${version}`)
  //               .map(res => { return res.list[0];});
  // }
