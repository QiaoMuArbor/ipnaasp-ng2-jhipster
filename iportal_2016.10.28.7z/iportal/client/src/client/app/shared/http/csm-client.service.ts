import { Injectable } from '@angular/core';
import { ActiveProjectService } from '../../app.service';
import { Observable }     from 'rxjs/Observable';


import { AuthHttp } from './auth-http.service';


@Injectable()
export class CmsService{
  apiCsBaseUrl:string = '/api/csmworker/v1/tenants';

  constructor(private activeProject: ActiveProjectService, private http: AuthHttp) {

  }

  getCommonServiceAndResouceListUx() :Observable<any>{
    let that = this;
    return that.getCommonServices()
      .flatMap( cslistRes => {
        return Observable.from(cslistRes.services);
      } )
      .flatMap( res => {
        return that.getResourcesByCommonServiceId(res.service_id,"available",res.displayname)
          .map(res => {
            return res;
          })
          .catch(err => {
            return Observable.throw(err);
          });
      });
  }

  getResourceByServiceIdUx(service_id:string) :Observable<any>{
    let that = this;
    return that.getResourcesByCommonServiceId(service_id)
      .map(res => {
        return res.resources;
      })
  }


  getCommonServicesUx() :Observable<any>{
    let that = this;
    return that.getCommonServices()
      .map(res => {
        return res.services;
      })
  }

  getCommonServiceUx(serviceid:string) :Observable<any>{
    let that = this;
    return that.getCommonServiceByServiceId(serviceid)
      .map(res => {
        return res;
      })
  }

  getResourcesListUx():Observable<any>{
    let that = this;
    return that.getResources()
      .map(res => {
        return res.resources;
      })
  }



  getCommonServices() :Observable<any>{
    let that = this;
    return that.http.get(`${that.apiCsBaseUrl}/${that.activeProject.id}/commonservices`);
  }

  private  getCommonServiceByServiceId(serviceid: string) :Observable<any>{
    let that = this;
    return that.http.get(`${that.apiCsBaseUrl}/${that.activeProject.id}/commonservices/${serviceid}`);
  }


  private getResourcesByCommonServiceId(service_id:string,status="available",displayname? :string) :Observable<any>{
    let that = this;
    return that.http.get(`${that.apiCsBaseUrl}/${that.activeProject.id}/csresources`)
      .map(res => {
        let xxx = "xxx";
         let csResoures = _.filter(res.resources,function (item) {
          return item.service_id == service_id && item.status == status;
        })
        if (displayname === undefined){
          return {"resources":csResoures,"service_id":service_id};
        }else{
          return {"displayname":displayname,"resources":csResoures,"service_id":service_id};
        }
      })
      .catch(error => {
        let emptyobj :Array<any> = [];
        let obj = {"displayname":displayname,"resources":emptyobj,"service_id":service_id};
        return  Observable.throw(obj);
      })
  }

  private getResources(): Observable<any>{
    let that = this;
    return that.http.get(`${that.apiCsBaseUrl}/${that.activeProject.id}/csresources`)
  }

  private getResourceByResourceId(resource_id:string): Observable<any>{
    let that = this;
    return that.http.get(`${that.apiCsBaseUrl}/${that.activeProject.id}/csresources/${resource_id}`)
  }

}
