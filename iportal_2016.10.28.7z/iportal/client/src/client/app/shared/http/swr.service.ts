import { Injectable } from '@angular/core';
import {ActiveProjectService} from '../../app.service';

import { AuthHttp } from './index';


@Injectable()
export class SwrService{
  apiBaseUrl:string = '/api/srepoworker/v1.0';

  constructor(private activeProject: ActiveProjectService, private http: AuthHttp) {
    this.apiBaseUrl = this.apiBaseUrl+'/'+this.activeProject.id;
  }

  getList(verType: string = '') {
    let that = this;
    return that.http.get(that.apiBaseUrl)
      .map(res => {
        let list = res.version;
        list = _.filter(list, function(item) {
          return item.vertype.indexOf(that.activeProject.id + '_' + verType) == 0;
        });
        return list;
      });
  }

}
