import {Component, OnInit, ElementRef, Input, Output, OnChanges, SimpleChange, EventEmitter, Self} from '@angular/core';
import {NgControl, ControlValueAccessor} from '@angular/common';

@Component({
    selector: 'select2',
    template: '<select class="select2"></select>',
    providers:[NgControl],
    styles:[`
    .select2{
      width:200px;
    }
    `]
})
export class Select2Component implements OnInit, OnChanges, ControlValueAccessor {
    private _selectElement: any;
    @Input() placeholder: string;
    @Input() multiple: boolean = true;
    @Input() value: any;
    @Input() data: Array<any> = new Array<any>();
    @Output('selectvalue') _change: EventEmitter<any> = new EventEmitter<any>();
   
    constructor(@Self() cd: NgControl, public element: ElementRef) {
      cd.valueAccessor = this;
    }
    
    ngOnInit() {
      this._selectElement = jQuery(this.element.nativeElement.childNodes[0]);
      this.setDataSelect2(this.data);
      let that = this;
      this._selectElement.on("change", function(e:any) { 
        that._change.emit(that._selectElement.select2("data"));
      });
    }
    
    ngOnChanges(changes: {[propertyName: string]: SimpleChange}) {
      if (changes['data']) {
        if (this._selectElement) {
            this.setDataSelect2(changes['data'].currentValue);
        }
      }
    }
    
    writeValue(value: any): void {
      this.setValueSelect2(value);
    }
    
    registerOnChange(fn: () => any): void {
      this._change.subscribe(fn); 
    }
    
    registerOnTouched(fn: () => any): void { }
    
    private setDataSelect2(data: Array<any>) {
      this._selectElement.select2({
        data: data,
        language:'zh-CN',
        //theme: 'bootstrap',
        //minimumInputLength: 2,
        maximumSelectionLength: 10,
        placeholder: this.placeholder,
        multiple: this.multiple
    });
    }
    
    private setValueSelect2(value: any) {
      this._selectElement.select2({
        //theme: 'bootstrap',
        placeholder: this.placeholder,
        multiple: this.multiple
      }).val(value).trigger('change');
    }
}