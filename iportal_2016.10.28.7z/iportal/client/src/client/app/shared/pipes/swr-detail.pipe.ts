import { Pipe, PipeTransform } from '@angular/core';
@Pipe({ name: 'SwrDetailPipe' })
export class SwrDetailPipe implements PipeTransform {
  transform(value:any) {
    if (value == "unavailable") {
      return "不可用";
    }
    if (value == "available") {
      return "可用";
    }
    if (value == "building") {
      return "构建中";
    }
    if (value == "uploading") {
      return "上传中";
    }
  }
}
