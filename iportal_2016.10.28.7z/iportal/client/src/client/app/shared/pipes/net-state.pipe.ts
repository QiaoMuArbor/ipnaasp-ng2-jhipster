import { Pipe, PipeTransform } from '@angular/core';
@Pipe({ name: 'NetStatePipe' })
export class NetStatePipe implements PipeTransform {
  transform(value:any) {
    if (value == "ACTIVE") {
      return "正常";
    }
    else{
      return "异常";
    }
  }
}
