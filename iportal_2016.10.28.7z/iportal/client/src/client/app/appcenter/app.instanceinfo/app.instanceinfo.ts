import {Component} from "@angular/core";
import {ROUTER_DIRECTIVES, Router} from "@angular/router";
import {Http, Response} from "@angular/http";
import {MockCfg} from "../../mock";
import {DateFormat} from "../../shared/pipes/function";
import {ActiveProjectService} from "../../app.service";

@Component({
  moduleId: module.id,
  selector: 'app-instanceinfo',
  templateUrl: 'app.instanceinfo.html',
  styleUrls: ['app.instanceinfo.css'],
  directives: [ROUTER_DIRECTIVES],
  providers: [DateFormat]
})

export class AppInstanceInfoComponent {
  private podId:string;

  private podName:string;
  private runStatus:string;
  private created_at:string;
  private nodeIP:string;
  private reqUrl:string;
  constructor(private router:Router, private _http:Http, private dateFormat:DateFormat,private activeProject: ActiveProjectService) {
    this.reqUrl=MockCfg.vnpmUrl + this.activeProject.id+ MockCfg.podurlsuffix+'/';
  }

  ngOnInit() {
    this.getParams();
    this.getInstanceInfo();
  }

  getParams() {
    this.router.routerState.queryParams.subscribe(params => {
      this.podId = params['id'];
    });
  }

  getInstanceInfo() {
    let that = this;
    this._http.request(this.reqUrl + this.podId)
      .subscribe((res:Response) => {
        let tmp = res.json();
        that.created_at = that.dateFormat.IsoLocalTime(new Date(tmp.created_at).getTime());
        that.podName = tmp.pod_name;
        that.nodeIP = tmp.node_ip;
        that.runStatus = tmp.run_status;
      });
  }
}
