export class Service {
  created_at:string;
  deploy_status:string;
  name:string;
  orch_name:string;
  progress:string;
  run_status:string;
  updated_at:string;
  uuid:string;
  ver_type:string;
  version:string;
  type:string;
  isShowTopo:boolean;
  alarm_num:number;
  ms_list:Array<MicroService>;

  constructor() {
    this.isShowTopo = false;
  }
}

export class MicroService {
  created_at:string;
  orch_name:string;
  pod_list:Array<Pod>;
  run_status:string;
  updated_at:string;
  uuid:string;
  ver_type:string;
  version:string;
  alarm_num:number;
}

export class Pod {
  created_at:string;
  pod_name:string;
  run_status:string;
  updated_at:string;
  uuid:string;
  alarm_num:number;
}

export class CommonClass{
  mslist:Array<CommonClass>=[];
  created_at:string;
  name:string;
  run_status:string;
  uuid:string;
  alarm_num:number;
  classtype:string;
  restype:string;
  imageurl:string;
  constructor(created_at:string, name:string, run_status:string,
              uuid:string, alarm_num:number, classtype:string,
              responsetype:string,imageurl:string) {
    this.uuid=uuid;
    this.created_at = created_at;
    this.name = name;
    this.run_status = run_status;
    this.uuid = uuid;
    this.alarm_num = alarm_num;
    this.classtype = classtype;
    this.restype=responsetype;
    this.imageurl=imageurl;
  }
}
export class containerinfo {
  ip:string;
  name:string;
  uuid:string;
  ready:boolean;


  constructor(ip:string, name:string, uuid:string, ready:boolean) {
      this.ip = ip;
      this.name = name;
      this.uuid = uuid;
          this.ready = ready;
      }

  constructor(ip:string, name:string, uuid:string) {
    this.ip = ip;
    this.name = name;
    this.uuid = uuid;
  }
}
export class link{
  name:string;
  url:string;

  constructor(name:string, url:string) {
      this.name = name;
      this.url = url;
      }
}
export class delinfo{
  uuid:string;
  type:string;


  constructor(uuid:string, type:string) {
      this.uuid = uuid;
      this.type = type;
      }
}
