export class Schedule{
  scheduleid: string;
  starttime: string;
  endtime: string;
  level: string;
  enable: boolean;

  constructor(){
    
  }
}
