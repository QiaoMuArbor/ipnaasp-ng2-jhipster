import {Component, ViewChild} from "@angular/core";
import {ActivatedRoute, Router, ROUTER_DIRECTIVES} from "@angular/router";
import {Response} from "@angular/http";
import {AuthHttp} from "../../../shared/index";
import {MockCfg} from "../../../mock";
import {Container} from "./app.container"
import {Policy} from "./app.policy"
import {ActiveProjectService} from "../../../app.service";
import {DateFormat} from "../../../shared/pipes/function";
import {EventBroadcastService} from "../../../shared/event-broadcast.component";
import forEach = require("core-js/fn/array/for-each");

@Component({
  moduleId: module.id,
  selector: 'app-mselastic',
  templateUrl: 'app.mselastic.html',
  styleUrls: [`../app.elastic.css`],
  directives: [ROUTER_DIRECTIVES],
  providers: [DateFormat]
})

export class AppMsElasticComponent {
  msId:any;
  timeout:any;
  containers:Array<Container> = [];
  newPolicy:Policy = new Policy();
  isUpdate:boolean = false;
  currentContainer:string = undefined;
  currentPolicy:string = undefined;
  epsurl:string;
  mock:any = {
    "auto_policy": [
      {
        "container": "c2",
        "policy": [
          {
            "param_name": "CPU",
            "enable": false,
            "scaleInThreshold": 10,
            "scaleOutThreshold": 80,
            "value": ""
          },
          {
            "param_name": "NEMORY",
            "enable": true,
            "scaleInThreshold": 10,
            "scaleOutThreshold": 80,
            "value": ""
          }
        ]
      },
      {
        "container": "c1",
        "policy": [
          {
            "param_name": "CPU",
            "enable": true,
            "scaleInThreshold": 10,
            "scaleOutThreshold": 80,
            "value": ""
          },
          {
            "param_name": "NEMORY",
            "enable": true,
            "scaleInThreshold": 10,
            "scaleOutThreshold": 80,
            "value": ""
          }
        ]
      }
    ]
  };

  constructor(private router:Router, private route:ActivatedRoute, private activeProject:ActiveProjectService,
              private _http:AuthHttp, private dateformat:DateFormat, private eventBroadcastService:EventBroadcastService) {
    this.newPolicy.param_name = '';
    this.epsurl = MockCfg.epsUrl + this.activeProject.id + "/microservices/";
  }

  ngOnInit() {
    this.getParams();
    this.getAutoPolicies();
    this.timeout = setInterval(() => {
      // 刷新信息;
      this.addPolicyname();
    }, 1000);
  }

  getParams() {
    this.router.routerState.queryParams.subscribe(params => {
      this.msId = params['id'];
    });
  }

  //now is mock/获取所有
  getAutoPolicies() {
    this._http.get(this.epsurl + this.msId + "/bps")
      .subscribe((res) => {
        let tmp = res.auto_policy;
        tmp.forEach((data:any) => {
          let policys:Array<Policy> = [];
          if (data.policy != null) {
            policys = data.policy;
          }
          let name:string = data.container;
          let container:Container = new Container(name, policys);
          this.containers.push(container);
        });
      });
  }

  // getAutoPolicies() {
  //
  //       let tmp = this.mock.auto_policy;
  //       tmp.forEach((data:any) =>{
  //         let policys:Array<Policy> = data.policy;
  //         let name:string = data.container;
  //         let container:Container = new Container(name, policys);
  //         this.containers.push(container);
  //       });
  // }

  openUpdate(container:string, policy:string) {
    this.isUpdate = true;
    this.currentContainer = container;
    this.currentPolicy = policy;
  }

  closeUpdate() {
    this.isUpdate = false;
    this.currentContainer = undefined;
    this.currentPolicy = undefined;
  }

  addPolicyname() {
    if (this.newPolicy.param_name === '' || this.newPolicy.param_name === 'cpu_usage_rate' || this.newPolicy.param_name === 'memory_usage_rate') {
      this.newPolicy.param_name = (<HTMLInputElement>document.getElementById("nameSelect")).value;
    }
  }

  addPolicyName(name:string) {
    this.newPolicy.param_name = name;
  }

  addPolicyScaleInThreshold(scaleInThreshold:string) {
    this.newPolicy.scaleInThreshold = parseInt(scaleInThreshold);
  }

  addPolicyScaleOutThreshold(scaleOutThreshold:string) {
    this.newPolicy.scaleOutThreshold = parseInt(scaleOutThreshold);
  }

  addPolicyEnable(enable:string) {
    if (enable === "true") {
      this.newPolicy.enable = true;
    } else {
      this.newPolicy.enable = false;
    }
  }

  //增加
  addPolicy(containerName:string) {
    let that = this;
    let isAdd:boolean = true;
    let select = (<HTMLInputElement>document.getElementById("enableSelect")).value;
    that.addPolicyEnable(select);
    let tempPolicy:Policy = new Policy();
    tempPolicy.param_name = that.newPolicy.param_name;
    tempPolicy.scaleInThreshold = that.newPolicy.scaleInThreshold;
    tempPolicy.scaleOutThreshold = that.newPolicy.scaleOutThreshold;
    tempPolicy.enable = that.newPolicy.enable;
    if (tempPolicy.param_name === '' || tempPolicy.scaleInThreshold === undefined || tempPolicy.scaleOutThreshold === undefined) {
      that.eventBroadcastService.broadcastError('参数不能为空！');
      return;
    }
    if ((tempPolicy.scaleInThreshold > tempPolicy.scaleOutThreshold) || !this.isLegal(tempPolicy.scaleInThreshold) || !this.isLegal(tempPolicy.scaleOutThreshold)) {
      this.eventBroadcastService.broadcastError("参数不正确！")
      return;
    }
    this.containers.forEach((container:Container) => {
      if (container.name === containerName) {
        container.policys.forEach((policy:Policy)=> {
          if (policy.param_name === tempPolicy.param_name) {
            that.eventBroadcastService.broadcastError('策略名称已存在！');
            that.newPolicy.param_name = '';
            isAdd = false;
            return;
          }
        });
        if (isAdd) {
          container.policys.push(tempPolicy);
          this._http.post(this.epsurl + this.msId + "/bps", this.getJson(containerName, tempPolicy))
            .subscribe((res) => {
              this.newPolicy.param_name = '';
              this.containers = [];
              this.getAutoPolicies();
            });
        }
      }
    });
  }

  //修改
  modifyPolicy(container:any, policy:any) {
    if(policy.enable==="true"||policy.enable===true){
      policy.enable=true;
    }else{
      policy.enable=false;
    }
    if ((policy.scaleInThreshold > policy.scaleOutThreshold) || !this.isLegal(policy.scaleInThreshold) || !this.isLegal(policy.scaleOutThreshold)) {
      this.eventBroadcastService.broadcastError("参数不正确！")
    } else {
      this.eventBroadcastService.broadcastSuccess('策略修改成功！');
      this._http.put(MockCfg.epsUrl + this.activeProject.id + "/microservices/" + this.msId + "/bps", this.getJson(container, policy))
        .subscribe((res) => {
          this.containers = [];
          this.getAutoPolicies()
        });
    }
    this.closeUpdate();
  }

  isLegal(number:number):boolean {
    if (number < 1 || number > 100) {
      return false;
    }
    return true;
  }

  getJson(container:any, policy:any):any {

    let json = {
      "container": container + "",
      "policy": [
        {
          "param_name": policy.param_name,
          "enable": policy.enable,
          "scaleInThreshold": parseInt(policy.scaleInThreshold + ""),
          "scaleOutThreshold": parseInt(policy.scaleOutThreshold + ""),
          "value": ""
        }
      ]
    }
    return json;
  }

  //删除
  deletePolicy(container:any, policy:any) {
    //本地删除
    this.containers.forEach((con:any)=> {
      if (con.name === container) {
        con.policys = _.without(con.policys, policy);
      }
    });
    this._http.delete(this.epsurl + this.msId + "/bps?container=" + container + "&policy=" + policy.param_name)
      .subscribe((res) => {
        this.containers = [];
        this.getAutoPolicies()
      });
  }

}
