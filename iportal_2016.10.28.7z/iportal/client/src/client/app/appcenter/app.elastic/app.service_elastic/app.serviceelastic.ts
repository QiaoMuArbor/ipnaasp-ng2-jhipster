import {Component, ViewChild} from "@angular/core";
import {ActivatedRoute, Router, ROUTER_DIRECTIVES} from "@angular/router";
import {MODAL_DIRECTIVES, ModalComponent} from "ng2-bs3-modal/ng2-bs3-modal";
import {AuthHttp} from "../../../shared/index";
import {DateFormat} from "../../../shared/pipes/function";
import {ActiveProjectService} from "../../../app.service";
import {Schedule} from "./app.schedule";
import {MockCfg} from "../../../mock";
import {EventBroadcastService} from "../../../shared/event-broadcast.component";

@Component({
  moduleId: module.id,
  selector: 'app-serviceelastic',
  templateUrl: 'app.serviceelastic.html',
  styleUrls: [`../app.elastic.css`],
  // directives: [MODAL_DIRECTIVES, ROUTER_DIRECTIVES, DateTimeComponent],
  directives: [MODAL_DIRECTIVES, ROUTER_DIRECTIVES],
  providers: [DateFormat]
})

export class AppServcieElasticComponent {
  @ViewChild('modal')
  modal:ModalComponent;

  serviceId:any;
  schedulelist:Array<Schedule> = [];
  serviceLevelsDesc:any;
  serviceLevels:Array<any> = [];
  newSchedule:Schedule = new Schedule();
  isUpdate:boolean = false;
  currentSchedule:string = undefined;
  epsurl:string;

  constructor(private router:Router, private route:ActivatedRoute, private activeProject:ActiveProjectService,
              private _http:AuthHttp, private eventBroadcastService:EventBroadcastService, private dateformat:DateFormat) {
    this.newSchedule.level = "";
    this.newSchedule.enable = true;
    this.epsurl = MockCfg.epsUrl + this.activeProject.id + "/scheduled/services/";
  }

  ngOnInit() {
    this.serviceLevelsDesc = new Map();
    this.getParams();
    this.getScheduleList();
    this.getLevelsDes();
  }

  getParams() {
    this.router.routerState.queryParams.subscribe(params => {
      this.serviceId = params['id'];
    });
  }

  openUpdate(scheduleid:string) {
    this.isUpdate = true;
    this.currentSchedule = scheduleid;
  }

  closeUpdate() {
    this.isUpdate = false;
    this.currentSchedule = undefined;
  }

  //获取服务级别描述
  getLevelsDes() {
    this._http.get(MockCfg.epsUrl + this.activeProject.id + "/services/" + this.serviceId + "/bps")
      .subscribe(res => {
        let tmp = res.capacity_level;
        tmp.forEach((des:any) => {
          this.serviceLevelsDesc.set(des.level, des.desc)
        });
        tmp.forEach((des:any) => {
          this.serviceLevels.push(des.level)
        });
      });
    // this.serviceLevelsDesc.set("1", "1000");
    // this.serviceLevelsDesc.set("2", "2000");
    // this.serviceLevelsDesc.set("3", "3000");
    // this.serviceLevels.push("1");
    // this.serviceLevels.push("2");
    // this.serviceLevels.push("3");
  }


  //查询弹缩计划列表
  getScheduleList() {
    this._http.get(this.epsurl + this.serviceId)
      .subscribe((res) => {
        if (res.schedule_list === undefined) {
          this.schedulelist = [];
        } else {
          this.schedulelist = res.schedule_list;
        }
      });
  }

  // //mock
  // getScheduleList() {
  //   let temp:any = {
  //     "schedule_list": [
  //       {
  //         "scheduleid": "Sche_1",
  //         "starttime": "2016/05/16 13:05:00",
  //         "endtime": "2016/05/17 14:05:00",
  //         "level": "2",
  //         "enable": true
  //       },
  //       {
  //         "scheduleid": "Sche_2",
  //         "starttime": "2016/05/18 13:05:00",
  //         "endtime": "2016/05/19 14:05:00",
  //         "level": "1",
  //         "enable": true
  //       }
  //     ]
  //   }
  //   this.schedulelist = temp.schedule_list;
  // }

  //增加弹缩计划
  addSchedule() {
    let that = this;
    let isAdd:boolean = true;
    if (that.newSchedule.scheduleid === undefined || that.newSchedule.starttime === undefined || that.newSchedule.endtime === undefined || that.newSchedule.level === "") {
      that.eventBroadcastService.broadcastError('参数不能为空！');
      isAdd = false;
    }else if (that.newSchedule.endtime <= that.newSchedule.starttime) {
      that.eventBroadcastService.broadcastError('起始日期应小于截止日期！');
      isAdd = false;
    }else if(!that.isAddTimeIntervalLegal(that.newSchedule)){
      that.eventBroadcastService.broadcastError('计划日期有重叠！');
      isAdd = false;
    }else if(that.newSchedule.endtime <= that.getCurrentTime()){
      that.eventBroadcastService.broadcastError('日期已过期！');
      isAdd = false;
    }
    that.schedulelist.forEach((schedule:Schedule)=> {
      if (schedule.scheduleid === that.newSchedule.scheduleid) {
        that.eventBroadcastService.broadcastError('计划名称已存在！');
        isAdd = false;
        that.newSchedule.scheduleid = undefined;
      }
    });

    if (isAdd) {
      that._http.post(that.epsurl + that.serviceId, that.newSchedule)
        .subscribe((res) => {
          that.getScheduleList()
        });
    }
  }
  getCurrentTime() {
    let fulltime:string;
    let currentDate:Date = new Date();
    let date:any = this.fomateNumber(currentDate.getDate());
    let year:number = currentDate.getFullYear();
    let mouth:any = this.fomateNumber(currentDate.getMonth()+1);
    let hour:any = this.fomateNumber(currentDate.getHours());
    let minute:any = this.fomateNumber(currentDate.getMinutes());
    let seconds:any = this.fomateNumber(currentDate.getSeconds());
    fulltime = year + "/" + mouth + "/" + date + " " + hour + ":" + minute + ":" + seconds;
    return fulltime;
  }

  fomateNumber(num:any):string{
    if (num >= 0 && num < 10) {
      return "0" + num;
    } else {
      return num;
    }
  }


  //修改弹缩计划
  modifySchedule(schedule:any) {
    let isAdd:boolean = true
    if (schedule.enable === "true") {
      schedule.enable = true;
    } 
    if(schedule.enable === "false"){
      schedule.enable = false;
    }
    if (schedule.endtime <= schedule.starttime ) {
      this.eventBroadcastService.broadcastError('起始日期应小于截止日期！！');
      isAdd = false;
    }else if(this.isModifyTimeIntervalLegal(schedule)){
      this.eventBroadcastService.broadcastError('计划日期有重叠！');
      isAdd = false;
    }
    if(isAdd){
      this._http.put(this.epsurl + this.serviceId + "?scheduleid=" + schedule.scheduleid, schedule)
        .subscribe((res) => {
          this.getScheduleList();
        });
    }
    this.closeUpdate();
  }

  //删除弹缩计划
  deleteSchedule(sid:string) {
    this._http.delete(this.epsurl + this.serviceId + "?scheduleid=" + sid)
      .subscribe(res=> {
        this.getScheduleList();
      });
  }

  //增加时判断时间段是否合法
  isAddTimeIntervalLegal(schedule:Schedule):boolean {
    let bool:boolean = true;
    this.schedulelist.forEach((sche:Schedule)=> {
      if ((sche.starttime >= schedule.starttime && sche.starttime <= schedule.endtime) || (sche.endtime >= schedule.starttime && sche.endtime <= schedule.endtime)) {
        bool = false;
      }
    });
    return bool;
  }
  //修改时判断时间段是否合法
  isModifyTimeIntervalLegal(schedule:Schedule):boolean {
    let bool:boolean = true;
    let filterlist:Array<any> = this.schedulelist;
    filterlist = filterlist.filter((item:any)=>item.scheduleid === schedule.scheduleid);
    filterlist.forEach((sche:Schedule)=> {
      if ((sche.starttime >= schedule.starttime && sche.starttime <= schedule.endtime) || (sche.endtime >= schedule.starttime && sche.endtime <= schedule.endtime)) {
        bool = false;
      }
    });
    return bool;
  }
  //下拉框变化时的响应
  showLevelDes(level:string):string {
    return this.serviceLevelsDesc.get(level);
  }
 //modify start time
  startChange(event:any, scheduleid:string) {
    this.schedulelist.forEach((schedule:Schedule)=> {
      if (schedule.scheduleid === scheduleid) {
        if (!(schedule.starttime === event.target.value)) {
          schedule.starttime = event.target.value;
          this.isUpdate = true;
          this.currentSchedule = scheduleid;
        }
      }
    })
  }
 //modify end time
  endChange(event:any, scheduleid:string) {
    this.schedulelist.forEach((schedule:Schedule)=> {
      if (schedule.scheduleid === scheduleid) {
        if (!(schedule.endtime === event.target.value)) {
          schedule.endtime = event.target.value;
          this.isUpdate = true;
          this.currentSchedule = scheduleid;
        }
      }
    })
  }
// add start time
  startAdd(event:any) {
    this.newSchedule.starttime = event.target.value;
  }
//add end time
  endAdd(event:any) {
    this.newSchedule.endtime = event.target.value;
  }
}
