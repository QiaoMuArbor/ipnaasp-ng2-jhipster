import {Policy} from "./app.policy"

export class Container {
	policys:Array<Policy>;
	name:string;
	
	constructor(name:string, policys:Array<Policy>) {
		this.name = name;
		this.policys = policys;
	}
}