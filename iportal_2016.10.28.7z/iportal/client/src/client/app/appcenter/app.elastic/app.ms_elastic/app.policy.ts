export class Policy {
	param_name: string;
	enable: boolean;
	scaleInThreshold: number;
	scaleOutThreshold: number;
	value: string
	
	constructor() {

	}
}