export class CommonTool{

  // 转换成本地时间;
  isoLocalTime(inputIntTime:any):any {
    if (!inputIntTime) {
      return null;
    }
    if (!isNaN(inputIntTime)) {
      inputIntTime = inputIntTime;
    } else {
      inputIntTime = Date.parse(inputIntTime);
    }
    let localTime:string = '';
    let offset:number = (new Date()).getTimezoneOffset();
    localTime = (new Date(inputIntTime - offset * 60000)).toISOString();
    localTime = localTime.substr(0, localTime.lastIndexOf('Z'));
    localTime = localTime.replace('T', ' ');
    return localTime;
  }

  changeLongNameStr(name:string):string {
    let str = "";
    if (name.length >= 30) {
      var str1 = name.substring(0, 10);
      var str2 = name.substring(name.length - 10);
      str = str1 + "..." + str2;
    }
    else {
      str = name;
    }
    return str;
  }

}
