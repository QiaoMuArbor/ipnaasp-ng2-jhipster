/**
 * Created by zte on 16-8-15.
 */
import { RouterConfig } from '@angular/router';
import {AppCenterComponent} from "./appcenter.component";
import {MSDetailRoutes} from "./app.detail/app.ms_detail/app.ms_detail_router";
import {PodDetailRoutes} from "./app.detail/app.pod_detail/app.pod_detail_router";
import {ConDetailRoutes} from "./app.detail/app.con_detail/app.con_detail_router";
import {ServiceDetailRoutes} from "./app.detail/app.service_detail/app.service_detail_router";

export const AppCenterRoutes: RouterConfig = [

  {
    path: 'app',
    children:[
      {
        path:'',
        component:AppCenterComponent
      },
      ...MSDetailRoutes,
      ...PodDetailRoutes,
      ...ConDetailRoutes,
      ...ServiceDetailRoutes
    ]
  }
];
