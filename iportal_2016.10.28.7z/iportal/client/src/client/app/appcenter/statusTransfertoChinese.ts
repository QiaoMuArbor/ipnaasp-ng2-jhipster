import { Pipe, PipeTransform } from '@angular/core';
@Pipe({ name: 'ToChinese' })
export class ToChinesePipe implements PipeTransform {
  transform(value:any) {
    if (!value) {return null;}
    if (!isNaN(value)) {value = value;}
    let statusOragin:string = value;
    let status = statusOragin.toLowerCase();
    return this.transferToChinese(status);
  }

  transferToChinese(status:string):any{
    let result:string = "部署中";
   switch (status) {
      case "deploying":result="部署中";break;
      case "get_quotas_fail":result="获取定额信息失败";break;
      case "get_cluster_ok":result="成功获取集群信息";break;
      case "get_cluster_fail":result="获取集群信息失败";break
      case "download_blueprint":result="下载蓝图中";break;
      case "download_blueprint_ok":result="下载蓝图成功";break;
      case "download_blueprint_fail":result="下载蓝图失败";break;
      case "allocate_port_fail":result="分配端口失败";break;
      case "splice_blueprint":result="实例化蓝图";break;
      case "splice_blueprint_ok":result="蓝图实例化成功";break
      case  "splice_blueprint_fail":result="蓝图实例化失败";break;
      case  "get_common_resource":result="获取公共资源";break;
      case  "get_common_resource_ok":result="获取公共资源成功";break;
      case  "get_common_resource_fail":result="获取公共资源失败";break;
      case "ms_creating":result="微服务创建中";break;
      case "deploy_fail":result="部署失败";break;
      case "deploy_ok":result="部署成功";break;
      case "deleting":result="删除中";break;
      case "deploy_updating":result="部署更新中";break;
      case "srvid_not_match_tenant":result="服务ID与租户不匹配";break;
      case "deleting_fail":result="删除失败";break;
     /**-----------------------------------------------------------------*/
     case "running":result="运行中";break;
     case "ms_error":result="微服务错误";break;
     case  "cluster_error":result="集群错误";break;
     case "updating":result="更新中";break;
     case "msb_reg_fail":result="msb注册失败";break;
     /**-----------------------------------------------------------------*/
     case "instance_error":result="实例错误";break;
     case "instance_num_not_match":result="实例数不匹配";break;
     /**-----------------------------------------------------------------*/
     case "pod_creating":result="pod创建中";break;

     default: result = status;break
    }
    return result;

  }
}

