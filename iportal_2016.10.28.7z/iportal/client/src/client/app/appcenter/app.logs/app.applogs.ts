import {Component} from "@angular/core";
import {Router} from "@angular/router";
import {LogsComponent} from "../../log/logs.component";


@Component({
  moduleId: module.id,
  selector: 'app-logs',
  templateUrl: 'app.applogs.html',
  styleUrls: ['app.applogs.css'],
  directives: [LogsComponent]
})

export class ApplogsComponent {
  reqType:string;
  typeString:any[];
  typeLevel:string;
  typeId:string;

  constructor(private  router:Router) {
  }

  ngOnInit() {
    this.typeString = ["service/?service_id=", "ms/?ms_id=", "ms_inst/?ms_inst_id=", "container/?container_id="];
    this.getRouteParams();
  }

  getRouteParams() {
    let that = this;
    that.router
      .routerState
      .queryParams
      .subscribe(params => {
        that.typeId = params['id'];
        that.typeLevel = params['level'];
      });
    if(that.typeLevel=="2"){
      that.router
        .routerState
        .queryParams
        .subscribe(params => {
          that.typeId = params['pod_name'];
        });
    }
    if(that.typeLevel=="3"){
      that.typeId=that.typeId.substring(9,21);
    }

    let num = parseInt(that.typeLevel);
    that.reqType = that.typeString[num] + that.typeId;
  }
}
