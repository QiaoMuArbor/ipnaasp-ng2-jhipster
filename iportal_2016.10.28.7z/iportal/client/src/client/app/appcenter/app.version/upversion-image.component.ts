import {AuthHttp} from '../../shared/index';
import {Component, Input} from '@angular/core';
import {Router, ActivatedRoute} from '@angular/router';
import {TOOLTIP_DIRECTIVES} from 'ng2-bootstrap/ng2-bootstrap';
import {MockCfg} from "../../mock";
import {ActiveProjectService} from "../../app.service";
import {SwrService} from "../../swr/swr.service";
import {DeployImageService1} from "./upVersion.service";
import {DeployImage} from "../../deploy/deploy-image";
import {DeployEnvComponent} from "../../deploy/deploy-env.component";
import {DeployVolumeMountComponent} from "../../deploy/deploy-volume-mount.component";
import {DeployPortComponent} from "../../deploy/deploy-port.component";
import {DeployPublicPortComponent} from "../../deploy/deploy-public-port.component";
import {DeployResoureComponent} from "../../deploy/deploy-resource.component";
import {DeployEpsComponent} from '../../deploy/deploy-eps.component'
import {EventBroadcastService} from "../../shared/event-broadcast.component";
import {ModalComponent} from "ng2-bs3-modal/ng2-bs3-modal";
import {SwrClientService} from "../../shared/http/swr-client.service";

@Component({
  moduleId: module.id,
  selector: 'upversion-image',
  templateUrl: 'upversion-image.component.html',
  styles: [`
	 .item-line > .advancedSetting{
	 	color:#238ff9;
	 }
	 .section-head > .title{
	 	border-bottom: #f5f5f5;
	 } 
	`],
  directives: [TOOLTIP_DIRECTIVES, DeployEnvComponent, DeployVolumeMountComponent, DeployPortComponent, DeployPublicPortComponent, DeployResoureComponent, DeployEpsComponent],
  providers: [DeployImageService1, SwrService,SwrClientService]
})

export class UpVersionByImageComponent {
  @Input() modal:ModalComponent;
  isCreating:boolean;
  deploy:DeployImage;
  versions:string[];
  oldVersion:string;

  private ms_ins_id:string;
  private orchName:string;
  private info:string[];
  private reponame:string;
  private name:string;
  private version:string;
  private request:any;
  private requestUrl:string;
  private notify:string;
  private oldver:string;
  private flesh:any;
  private tenantId:string;

  constructor(private swrClientService:SwrClientService
    ,private activeProjectService:ActiveProjectService,
              private deployImageService:DeployImageService1,
              private route:ActivatedRoute,
              private router:Router,
              private swrService:SwrService,
              public http:AuthHttp,
              private eventBroadcastService:EventBroadcastService,
              private activeProject:ActiveProjectService) {
    this.oldver = "";
  }

  ngDoCheck() {
    let newversion = this.deploy.image.version;
    if (this.oldver != newversion) {
      this.oldver = newversion;
      this.getAlreadyDetail(this.deploy.image.reponame,this.deploy.image.name, newversion);
    }
  }

  getAlreadyDetail(reponame:string,name:string,newversion:string){
    this.swrClientService.getTagIdByNameAndTag(name, newversion)
      .subscribe(tagId=>{
        this.swrClientService.getImageTag(tagId)
          .subscribe(res=>{
      let that = this;
      if(res.detail!=''){
        let res_detail = JSON.parse(res.detail);
        that.deploy.envs = res_detail.envs || [];
        that.deploy.resource = res_detail.resource||{};
        that.deploy.volumes = _.map(res_detail.volumes||[],function(volume){
          return {mountPath: volume.mountPath, type: volume.volumeType, value:volume.hostPath,pvcid:'' }
        });
        //"mountPath": "/home", "hostPath": "/home", "volumeType": "hostPath"
        that.deploy.inerPorts = res_detail.inerPorts || [];
        that.deploy.security = res_detail.security||false;
        that.deploy.stdin = res_detail.stdin||false;
        that.deploy.tty = res_detail.tty||false;
        that.deploy.status = res.status;
        that.deploy.eps = res_detail.epsPorts || [];
        console.log(that.deploy.status);
        // without add eps  parse
        if(res_detail.externalPorts.length != 0){
          for (let i = res_detail.externalPorts.length - 1; i >= 0; i--) {
            let newOutPort: {
              serviceName:string,
              containerPort: string,
              protocol: string,
              url: string,
              version: string,
              lbPolicy: string
            }={	serviceName:"",
              containerPort: "",
              protocol: "",
              url: "",
              version: "",
              lbPolicy: ""};
            newOutPort.serviceName    = res_detail.externalPorts[i].serviceName;
            newOutPort.containerPort  = res_detail.externalPorts[i].port;
            newOutPort.protocol       = res_detail.externalPorts[i].protocol;
            newOutPort.url            = res_detail.externalPorts[i].url;
            newOutPort.version        = res_detail.externalPorts[i].version;
            newOutPort.lbPolicy       = res_detail.externalPorts[i].lb_policy;
            that.deploy.outPorts.push(newOutPort);
          }
        }
      }else{
        that.deploy.outPorts =  [];
        that.deploy.envs =  [];
        that.deploy.resource ={cpu:1,memory:1};
        that.deploy.volumes = [];
        that.deploy.inerPorts =  [];
        that.deploy.security = false;
        that.deploy.stdin = false;
        that.deploy.tty = false;
        that.deploy.eps = []; //9-26 add
        that.deploy.clusterId ="";//10.10 add

      }
    });
  })
  }

  ngOnInit() {
    let that = this;
    this.router.routerState.queryParams.subscribe(params => {
          this.ms_ins_id = params['id'];
        });
     this.requestUrl = MockCfg.vnpmUrl + this.activeProject.id + MockCfg.msserviceurlsuffix +'/' + this.ms_ins_id;
    this.http.request(this.requestUrl)
      .subscribe(res => {
        this.orchName = res.orch_name;
        this.deploy.name = res.deploy_name;
        this.oldver = res.version;
        this.oldVersion = that.oldver;
        this.deploy.image.version = that.oldver;
        this.info = that.orchName.split("/");
        this.deploy.image.reponame = that.info[0];
        this.deploy.image.name = that.info[1];
        this.tenantId = res.bp_tenant_id;
        this.request = {
          "orch_name": this.deploy.name, //升级后的新的服务名字
          "version": this.deploy.image.version, //升级后的新服务版本
          "parameters": "",//用户输入参数
          "bp_tenant_id": this.tenantId
        };
        this.swrService.getImageVersion(this.info[0], this.info[1]).subscribe(res => {
          this.versions = res;
        });
       this.getAlreadyDetail(this.reponame, this.name, this.version);
      });
    this.isCreating = false;
    this.deploy = new DeployImage();
    this.deploy.dcId = "0";
    this.deploy.name = name;
    this.deploy.instanceNum = 1;
    this.deploy.resource = {cpu: 1, memory: 1};
    this.deploy.envs = [];
    this.deploy.volumes = [];
    this.deploy.inerPorts = [];
    this.deploy.outPorts = [];
    this.deploy.image = {reponame: that.reponame, name: that.name, version: that.version};
    this.deploy.stdin = false;
    this.deploy.security = false;
    this.deploy.tty = false;
    this.deploy.eps = [];//9.26 add
    this.deploy.clusterId ="";//10.10 add
  }

  deployImage() {
    if (this.deploy.image.version != this.oldVersion) {
      this.isCreating = true;
      this.deployImageService.depoy(this.tenantId,this.requestUrl, this.deploy).subscribe(() => {
          this.isCreating = false;
          this.eventBroadcastService.broadcastSuccess('开始升级!');
          this.modal.dismiss();
          this.router.navigate(['/project', this.activeProjectService.id, 'app']);
        },
        error => {
          this.eventBroadcastService.broadcastError(error.message);
        }
      );
    }
    else {
      this.notify = "选择版本与当前版本相同！";
      this.flesh = setInterval(() => {
        // 刷新信息;
        this.notify = "";
      }, 2000);
    }
  }

  radioSelect(type:string) {
    if (type == 'security') {
      this.deploy.security = this.deploy.security ? false : true;
    }
    if (type == 'stdin') {
      this.deploy.stdin = this.deploy.stdin ? false : true;
    }
    if (type == 'tty') {
      this.deploy.tty = this.deploy.tty ? false : true;
    }
    if (!this.deploy.stdin) {
      this.deploy.tty = false;
    }
  }

  historyBack() {
    window.history.back();
  }


  closeModel() {
    this.notify = "";
    this.modal.dismiss();
  }

}
