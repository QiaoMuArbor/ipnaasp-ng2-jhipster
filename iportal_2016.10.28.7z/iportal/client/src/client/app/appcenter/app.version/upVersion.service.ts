import {Injectable}     from '@angular/core';
import {LocalStorageService, AuthHttp} from '../../shared/index';
import {ActiveProjectService} from "../../app.service";
import {DeployImage} from "../../deploy/deploy-image";

@Injectable()
export class DeployImageService1 {
  userName:string;
  private vnpmUrl:string;

  constructor(private http:AuthHttp, private localStorageService:LocalStorageService,private activeProject:ActiveProjectService) {
    let user = this.localStorageService.get('user',true);
    this.userName = user.id;
    this.vnpmUrl = '/api/vnpm_deploy/v1/tenants/' + this.activeProject.id + '/microservices';  // URL to web
  }

  depoy(id:string,url:string,deployImage:DeployImage) {

    let tenentName = this.activeProject.id;
    deployImage.dcId = deployImage.dcId;
    let deployBody = {
      "orch_name":deployImage.name,     //升级后的新的服务名字
      "version":deployImage.image.version,           //升级后的新服务版本
      "bp_tenant_id":id,                  // id,
      "parameters":"",
      "common_info": {
        "cluster_info":{
          "cluster_id":deployImage.clusterId
        },
        "storage_info":{
          "pvcid":new Array()
        }
      },//10.10 add
      "deploymentconfig": {
        "kind": "DeploymentConfig",
        "apiVersion": "v1",
        "metadata": {
          "labels": {
            "template": deployImage.name
          },
          "name": deployImage.name,
          "namespace": tenentName
        },
        "spec": {
          "replicas": deployImage.instanceNum,
          "selector": {
            "name": deployImage.name
          },
          "template": {
            "metadata": {
              "labels": {
                "name": deployImage.name
              }
            },
            "spec": {
              "volumes": new Array(),
              "containers": [{
                "name": deployImage.name,
                "image": '/' + deployImage.image.reponame + "/" + deployImage.image.name + ":" + deployImage.image.version,
                "ports": new Array(),
                "env": new Array(),
                "resources": {
                  "limits": {
                    "memory": 0,
                    "cpu": 0
                  }
                },
                "volumeMounts": new Array(),
                "tty": deployImage.tty,
                "stdin": deployImage.stdin,
                "securityContext": {
                  "privileged": deployImage.security
                }
              }]
            }
          }
        },
        "status": {
          "latestVersion": 1
        },
        "eps_param":{
          "auto_policy":{
          }
        },
        "vnpm_param": {
          "vnpm_common": {
            "dc_id": deployImage.dcId,
            //"namespace": tenentName,
            "deploy_name": deployImage.name,
            "create_by": "",
            "orch_name": deployImage.image.reponame + "/" + deployImage.image.name,
            "version": deployImage.image.version
          },
          "vnpm_object": [{
            "name": deployImage.name,
            "kind": "DeploymentConfig",
            "route_list": new Array(),
            "networks": {
              "pod_type": "ct_minus",
              "network_plane": "std,control,media",
              "network_list": {
                "std": "net_api",
                "media": "media",
                "control": "control"
              }
            }
          }]
        }
      },
      "ms_info": {}
    };
    this.setDeployVolumes(deployImage, deployBody);
    this.setDeployContainerPorts(deployImage, deployBody);
    this.setDeployContainerEnvs(deployImage, deployBody);
    this.setDeployContainerResources(deployImage, deployBody);
    this.setDeployContainerVolumeMounts(deployImage, deployBody);
    this.setDeployZteParamPortList(deployImage, deployBody);
    this.setDeployContainerEps(deployImage, deployBody);
    deployBody.deploymentconfig.vnpm_param.vnpm_common.create_by = this.userName;
    console.log('deployimage'+deployBody);
    return this.http.put(url,deployBody);
  }

  private setDeployVolumes(deployImage:DeployImage, deployBody:any) {
    let volumes = deployBody.deploymentconfig.spec.template.spec.volumes;
    _.each(deployImage.volumes, function (volume, i) {
      if( "pvc"== volume.type){
        volumes.push({
          "name": "volume-" + i.toString(),
          "persistentVolumeClaim": {
            "claimName": volume.value
          }
        });
      }
      if("hostPath"==volume.type){
        volumes.push({
          "name": "volume-" + i.toString(),
          "hostPath": {
            "path": volume.value
          }
        });
      }

    });
  }
  private setDeployContainerPorts(deployImage:DeployImage, deployBody:any) {
    let ports = deployBody.deploymentconfig.spec.template.spec.containers[0].ports;
    _.each(deployImage.inerPorts, function (port, i) {
      ports.push({
        "containerPort": port.containerPort,
        "protocol": port.protocol
      });
    });
  }

  private setDeployContainerEnvs(deployImage:DeployImage, deployBody:any) {
    let envs = deployBody.deploymentconfig.spec.template.spec.containers[0].env;
    _.each(deployImage.envs, function (env, i) {
      envs.push({
        "name": env.name,
        "value": env.value
      });
    });
  }

  private setDeployContainerResources(deployImage:DeployImage, deployBody:any) {
    let limits = deployBody.deploymentconfig.spec.template.spec.containers[0].resources.limits;
    limits.memory = deployImage.resource.memory + 'Gi';
    limits.cpu = deployImage.resource.cpu;
  }

  private setDeployContainerVolumeMounts(deployImage:DeployImage, deployBody:any) {
    let volumes = deployBody.deploymentconfig.spec.template.spec.containers[0].volumeMounts;
    let pvcid = deployBody.common_info.storage_info.pvcid;
    _.each(deployImage.volumes, function (volume, i) {
      if( "pvc"== volume.type){
        pvcid.push(volume.pvcid); //add-pvcId-to-ms_info-pvcid[]
        volumes.push({
          "name": "volume-" + i.toString(),
          "mountPath": volume.mountPath
        });
      }
      if("hostPath"==volume.type){
        volumes.push({
          "name": "volume-" + i.toString(),
          "mountPath": volume.mountPath
        });
      }

    });
  }
  private setDeployZteParamPortList(deployImage:DeployImage, deployBody:any) {
    let ports = deployBody.deploymentconfig.vnpm_param.vnpm_object[0].route_list;

    _.each(deployImage.outPorts, function (port, i) {
      ports.push({
        "serviceName": port.serviceName,
        "version": port.version,
        "url": port.url,
        "protocol": port.protocol,
        "lb_policy": port.lbPolicy,
        "port": port.containerPort
      });
    });
  }

  private setDeployContainerEps(deployImage:DeployImage, deployBody:any) {
    let name = deployBody.deploymentconfig.eps_param.auto_policy;
    let  eps =  name[deployImage.image.name] = new Array();

    _.each(deployImage.eps, function (item, i) {
      eps.push({
        "param_name":item.name,
        "isDefault": true,
        "defaultValue":[
          item.value[0],
          item.value[1]
        ],
        "value":""
      });
    });
  }


}




