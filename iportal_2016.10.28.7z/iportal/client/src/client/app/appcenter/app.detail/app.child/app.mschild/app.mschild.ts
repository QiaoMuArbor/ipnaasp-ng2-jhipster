import {MODAL_DIRECTIVES} from "ng2-bs3-modal/ng2-bs3-modal";
import {Component,ViewChild} from '@angular/core';
import {ISOLocalPipe} from "../../../../shared/pipes/iso-local.pipe";
import {AuthHttp} from "../../../../shared/index";
import {CommonTool} from "../../../app.commontool";
import {ActivatedRoute,Router,ROUTER_DIRECTIVES} from '@angular/router';
import {MockCfg} from "../../../../mock";
import {ActiveProjectService} from "../../../../app.service";
@Component({
  moduleId: module.id,
  pipes:[ISOLocalPipe],
  providers:[CommonTool],
  selector: 'app-mschild',
  styleUrls:['../app.childresource.css'],
  templateUrl: 'app.mschild.html',
  directives: [MODAL_DIRECTIVES,ROUTER_DIRECTIVES],
})

export class MsChildResourceComponent {
  private ms_ins_id:string;
  private ChildResourceData:Array<any>;
  private msserviceurl:string;
  private srv_ins_id:string;
  private podurl:string;
  private currentalarmurl:string;

  constructor(public http:AuthHttp,private route: ActivatedRoute,private router: Router,
              private activeProject: ActiveProjectService){
    this.msserviceurl =MockCfg.vnpmUrl+this.activeProject.id+MockCfg.msserviceurlsuffix+'/';
    this.podurl =MockCfg.vnpmUrl+this.activeProject.id+MockCfg.podurlsuffix+'/';
    this.currentalarmurl=MockCfg.currentalarmUrl +this.activeProject.id+ '/statistics/current/';
  }
  ngOnInit(){
    this.router
      .routerState
      .queryParams
      .subscribe(params => {
        this.ms_ins_id = params['id'];
      });
    this.initData();
  }

  private initData() {
    this.ChildResourceData=[];
    this.http.request( this.msserviceurl+ this.ms_ins_id)
      .subscribe(res => {
        let ms =res;
        this.srv_ins_id =ms.srv_ins_id;
        if(!this.srv_ins_id)
        {
          this.srv_ins_id="";
        }
        let podidlist=ms.pod_list;
        for(let podid of podidlist)
        {
          this.getPodInstanceById(podid.pod_ins_id);
        }
      });
  }
  private getCurrentAlarmNum(pod:any,type:string) {
    this.http.request(this.currentalarmurl+type+'/' + pod.pod_name)
      .subscribe(res => {
          pod.alarm_num=res.total;
        },
        error => {
          pod.alarm_num = 0;
        }
      );
  }

  private getPodInstanceById(podid:any) {
    this.http.request( this.podurl+ podid)
      .subscribe(res => {
        let pod = res;
        pod.imageurl="../../../images/apps/pod.png";
        pod.fullname =pod.pod_name;
        pod.name=new CommonTool().changeLongNameStr(pod.pod_name);
        pod.created_at=new CommonTool().isoLocalTime(pod.created_at);
        this.getCurrentAlarmNum(pod,'name');
        this.ChildResourceData.push(pod);
      });
  }
}
