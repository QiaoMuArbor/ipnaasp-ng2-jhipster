import {Component,ViewChild, Input, Output, EventEmitter} from '@angular/core';
import {ActivatedRoute, Router, ROUTER_DIRECTIVES} from '@angular/router';
import {MockCfg} from "../../../mock";
import {ISOLocalPipe} from '../../../shared/pipes/iso-local.pipe';
import {CommonTool} from "../../app.commontool";
import {ActiveProjectService} from "../../../app.service";
import {ModalComponent,MODAL_DIRECTIVES} from "ng2-bs3-modal/ng2-bs3-modal";
import {containerinfo, link} from "../../TypeClass";
import {KY_BREADCRUMB_DIRECTIVES} from "../ky-breadcrumb.component";
import {TerminalService} from "../app.terminalservice";
import {ProgressBarComponent} from "../../progressbar";
import {UpVersionByImageComponent} from "../../app.version/upversion-image.component";
import { Injectable } from '@angular/core';
import {EventBroadcastService} from "../../../shared/event-broadcast.component";
import {AuthHttp} from "../../../shared/index";


@Component({
  moduleId: module.id,
  selector: 'ms_detail;',
  styleUrls: ['../app.detail.css'],
  templateUrl: 'app.ms_detail.html',
  directives: [KY_BREADCRUMB_DIRECTIVES,ROUTER_DIRECTIVES,MODAL_DIRECTIVES,ProgressBarComponent,UpVersionByImageComponent],
  providers: [CommonTool,TerminalService],
  pipes: [ISOLocalPipe]
})

@Injectable()
export class MSDetailComponent{

  @ViewChild('modal')modal:ModalComponent;
  @ViewChild('modalvup')modalvup:ModalComponent;
  @Output() valueChange = new EventEmitter<Array<any>>();

  private ms_ins_id:string="";
  private deploy_name:string="";
  private created_at:string="";
  private run_status:string="";
  private version:string="";
  private alarmnum:any=0;
  private replicas:number=0;
  private srv_ins_id:string="";
  private containerinfolist:Array<any>=[];
  private ms_pod_list:Array<any>=[];
  private bTitle = "版本升级";
  private isAuto:boolean=false;

  private links:Array<link>=[];
  private msserviceurl:string="";
  private tip:string="";
  private orchName:string='';
  private deployInfo:string="";
  private bulePrintList:any=[];

  private sVersion:string="";
  private inputParamArray:Array<string>=[];
  private value:Array<any>=[];
  private name:Array<any>=[];
  private flag:any=0;
  newV={"name":"","value":""};
  private flaghead:string="";
  private timer:any;
  private upVerfail:string="";
  private common:string="";
  private verflag:string="tip";
  private epsurl:string="";
  private podurl:string="";
  private currentalarmurl:string="";
  private deployType:string='';
  private ismirrorblue:string='';
  private projectBulePrintList:any;
  private commonBulePrintList:any;
  private tenantId:string="";
  private bp_tenant_id:string='';

    constructor(public http:AuthHttp, private route:ActivatedRoute, private router:Router
      ,private activeProject: ActiveProjectService,private terminalService:TerminalService,
                private eventBroadcastService: EventBroadcastService
              ) {
      this.replicas = 0;
      this.msserviceurl=MockCfg.vnpmUrl + this.activeProject.id+MockCfg.msserviceurlsuffix+'/';
      this.podurl=MockCfg.vnpmUrl + this.activeProject.id+MockCfg.podurlsuffix+'/';
      this.epsurl=MockCfg.epsUrl + this.activeProject.id + "/microservices/";
      this.currentalarmurl=MockCfg.currentalarmUrl +this.activeProject.id+ '/statistics/current/microservice_id/';
    }

    ngOnInit() {
      this.router
        .routerState
        .queryParams
        .subscribe(params => {
          this.ms_ins_id = params['id'];
        });
      this.getInitData();

    }

    openConsoleModal(){
      this.getContainers();
      this.modal.open();
    }

  private getInitData() {
    this.http.get( this.msserviceurl+ this.ms_ins_id)
        .subscribe(res => {
          let ms = res;
          this.ismirrorblue =this.isMirrorOrBlue(ms);
          this.srv_ins_id=ms.srv_ins_id;
          if(!this.srv_ins_id)
          {
            this.srv_ins_id="";
          }
          this.ms_pod_list=ms.pod_list;
          this.replicas = ms.replicas;
          this.deploy_name = ms.deploy_name;//todo:
          this.run_status = ms.run_status;
          this.created_at = ms.created_at;
          this.version =ms.version;
          this.created_at = new CommonTool().isoLocalTime(this.created_at);
          this.deployType =ms.deploy_type;
          this.orchName = ms.orch_name;
          this.bp_tenant_id= ms.bp_tenant_id;
        this.getProjectBulePrintList();
         this.getCommonBulePrintList();

          this.inputParamArray = ms.input_parameters;
          this.flag = this.orchName.indexOf("/");
          this.flaghead = this.orchName.substring(0,this.flag-1);
          this.tenantId = ms.bp_tenant_id;
          this.sVersion = this.version;
          this.getCurrentAlarmNum(ms);
          this.initlinks();
          this.getAutoStatus(ms);
          this.ismirrorblue =this.isMirrorOrBlue(ms);
        /*
        //mock servicelevel data
        this.commonBulePrintList=[
            {
              "reponame":"p-hyr",
              "name":"opstest",
              "tag":"service",
              "versions":[
                {
                  "id":2,
                  "created_at":"2016-10-20T01:48:39Z",
                  "updated_at":"2016-10-20T01:48:39Z",
                  "version":"v2",
                  "author":"",
                  "alias":"",
                  "publicview":"no"
                },
                {
                  "id":3,
                  "created_at":"2016-10-20T06:17:47Z",
                  "updated_at":"2016-10-20T06:17:47Z",
                  "version":"v4",
                  "author":"",
                  "alias":"",
                  "publicview":"no"
                }
              ]
            }
          ];*/

        });
    }
  private isMirrorOrBlue(item:any) {
      //单镜像
      if (item.deploy_type == 'dc') {

          return 'mirror';
      } else {

          return 'blue';
      }
    }
  getReplica(){
    this.http.get( this.msserviceurl+ this.ms_ins_id)
      .subscribe(res => {
        let ms = res;
        this.replicas = ms.replicas;
      });
  }
  modifyReplica(){
    let data = {"replicas": this.replicas+""};
    this.http.put(this.epsurl + this.ms_ins_id, data)
      .subscribe();
  }
  addRplica() {
    this.replicas++;
    let data = {"replicas": this.replicas+""};
    this.http.put(this.epsurl + this.ms_ins_id, data)
      .subscribe();
  }

  delReplica() {
    this.replicas--;
    if (this.replicas < 1)
      this.replicas = 1;
    let data = {"replicas": this.replicas+""}
    this.http.put(this.epsurl + this.ms_ins_id, data)
      .subscribe();
  }

  private getCurrentAlarmNum(ms:any) {
     this.http.get(this.currentalarmurl + ms.ms_ins_id)
        .subscribe(res => {
            this.alarmnum = res.total;
          },
          error => {
            this.alarmnum = 0;
          }
        );
    }
  private getContainers() {
      this.containerinfolist=[];
      for (let podid of this.ms_pod_list)
      {
        this.http.get(this.podurl + podid.pod_ins_id)
          .subscribe(res => {
            let pod = res;
            let hostip = pod.node_ip;
            let tmpcons = pod.containerStatuses;
            let containerId:any;
            for (let con of tmpcons) {
              let conidstr:string=con.containerID;
              containerId = conidstr.substr(conidstr.indexOf("://")+3, conidstr.length);
              let coninfo:containerinfo = new containerinfo(hostip, con.name, containerId,con.ready);
              this.containerinfolist.push(coninfo);
            }
          });
      }
    }
  private initlinks() {
      this.links=[];
      let applinkurl ="/project/"+this.activeProject.id+"/app";
      let applink = new link("应用中心",applinkurl);
      this.links.push(applink);

      if (this.srv_ins_id!="" && this.srv_ins_id!="undefined" &&this.srv_ins_id!=undefined)
      {
        let srvlinkurl="/project/"+this.activeProject.id+"/app/servicedetail?id="+this.srv_ins_id;
        let srvlink =new link("服务",srvlinkurl);
        this.links.push(srvlink)
      }
      let mslinkurl="/project/"+this.activeProject.id+"/app/msdetail?id="+this.ms_ins_id+"&srv_ins_id="+this.srv_ins_id;
      let mslink =new link("微服务详情","");


      this.links.push(mslink);
    }
  openTerminal() {
      let selectValue = document.getElementById("selectid").value;
      let tmp =selectValue.split("&");
      let hostIp = tmp[0];
      let containerId = tmp[1];
      let status = tmp[2];
      if(status=="false"){
        this.tip ="该容器非运行状态，无法打开远程终端！";
        return false;
      }else {
        this.tip ="";
      }
      this.terminalService.dcLinkTerminal(hostIp,containerId);
    }

    slectchange(){
      let selectValue = document.getElementById("selectid").value;
      let tmp =selectValue.split("&");
      let hostIp = tmp[0];
      let containerId = tmp[1];
      let status = tmp[2];
      if(status=="false"){
        this.tip ="该容器非运行状态，无法打开远程终端！";
      }else {
        this.tip ="";
      }
    }

  getProjectBulePrintList(){
      this.http.get(MockCfg.swrVerUrl+this.activeProject.id+"/bps?name="+this.orchName+"&tag=microservice")
        .subscribe(resb => {
          this.projectBulePrintList = resb.list;
        });
  }

  getCommonBulePrintList(){
    this.http.get(MockCfg.swrVerUrl+this.activeProject.id+"/bps?name="+this.orchName+"&tag=microservice&publicview=yes")
      .subscribe(resb => {
        this.commonBulePrintList = resb.list;
      });
  }

  getBulePrintList(){
    let that = this;
    this.bulePrintList =  that.projectBulePrintList;
    /*
    for (let i of that.commonBulePrintList)
    this.bulePrintList.push(i);
    */
  }

  getInputParam(){
    let i = 0;
    for (let inputParam of this.inputParamArray){
      this.name[i] = inputParam.name;
      this.value[i] = inputParam.value;
      i++;
    }
  }

  initNewV() {
    this.newV = { name: '', value: '' };
  }
  del(item:string){
    this.inputParamArray = _.without(this.inputParamArray, item);
  }

  add(newV:string){
    this.inputParamArray.push(newV);
    this.initNewV();
  }

  openVersionUpModal(){
    this.upVerfail = "";
    this.getInputParam();
    this.getBulePrintList();
    this.modalvup.open();
  }

  upMsVersion(){
    let  that = this;
    this.flag = that.orchName.indexOf("/");
    this.flaghead = that.orchName.substring(0,this.flag-1);
  let request={
      "orch_name": this.orchName,
      "version": this.sVersion,
      "parameters": this.inputParamArray,
      "bp_tenant_id": this.tenantId
    };
    this.http.put(this.msserviceurl+this.ms_ins_id,request).subscribe();
    this.eventBroadcastService.broadcastSuccess('开始升级!');
    this.modal.dismiss();
    this.router.navigate(['/project',this.activeProject.id,'app']);
  }

  selectVersion(vs:string) {
    if(this.version == vs)
      document.getElementById(this.verflag).style.display = "none";
    this.sVersion = vs;
    document.getElementById(this.sVersion).style.display = "block";
    if (vs != this.verflag && this.verflag != "tip") {
      document.getElementById(this.verflag).style.display = "none";
    }
    this.verflag = vs;
    this.upVerfail = "";
  }

  startUpVersion(){
    if(this.sVersion != this.version){
      this.modalvup.dismiss();
      this.upMsVersion();
    }
    else {
      this.upVerfail = "选择版本与当前版本相同!";
    }
  }

  isStopProcessbar(){
    this.http.get(this.msserviceurl+this.ms_ins_id )
      .subscribe( res => {
        if(res.run_status == "running"){
          document.getElementById("pbar").style.display = "none";
          this.bTitle = "版本升级";
          clearInterval(this.timer);
        };
    });
  }

  pauseAuto(){
    this.isAuto=false;
    //post
    this.http.put(this.epsurl + this.ms_ins_id, {"auto_enable": this.isAuto}).
    subscribe();
  }
  startAuto(){
    this.isAuto=true;
    //post
    this.http.put(this.epsurl + this.ms_ins_id, {"auto_enable": this.isAuto}).
    subscribe();
  }
  getAutoStatus(ms:any){
    this.http.get(this.epsurl + ms.ms_ins_id)
      .subscribe(res=>{
        this.isAuto=res.auto_enable;
      });
  }

}

