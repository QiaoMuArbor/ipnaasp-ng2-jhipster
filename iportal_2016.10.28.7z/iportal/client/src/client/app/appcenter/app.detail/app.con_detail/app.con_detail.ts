import {Component,ViewChild} from '@angular/core';
import {ActivatedRoute, Router, ROUTER_DIRECTIVES} from '@angular/router';
import {Headers, Http, Response} from '@angular/http';
import {MockCfg} from "../../../mock";
import {CommonTool} from "../../app.commontool";
import {ActiveProjectService} from "../../../app.service";
import {ModalComponent,MODAL_DIRECTIVES} from "ng2-bs3-modal/ng2-bs3-modal";
import {containerinfo, link} from "../../TypeClass";
import {KY_BREADCRUMB_DIRECTIVES} from "../ky-breadcrumb.component";
import {TerminalService} from "../app.terminalservice";
import {ISOLocalPipe} from "../../../shared/pipes/iso-local.pipe";
import {AuthHttp} from "../../../shared/index";


@Component({
  moduleId: module.id,
  selector: 'con_detail;',
  styleUrls: ['../app.detail.css'],
  templateUrl: 'app.con_detail.html',
  directives: [KY_BREADCRUMB_DIRECTIVES,ROUTER_DIRECTIVES,MODAL_DIRECTIVES],
  providers: [CommonTool,TerminalService],
  pipes: [ISOLocalPipe]
})

export class ConDetailComponent {

  @ViewChild('modal')
  modal:ModalComponent;

  private containerID:string;
  private deploy_name:string;
  private iconchar:string;
  private created_at:string;
  private run_status:string;
  private links:Array<link>;
  private podurl:string;
  private pod_ins_id:string;
  private pod_name:string;
  private container:any;
  private srv_ins_id:string;
  private disable:string;
  private statusmsg:string;

  constructor(public http:AuthHttp, private route:ActivatedRoute, private router:Router
    ,private activeProject: ActiveProjectService,private terminalService:TerminalService ) {
    this.podurl=MockCfg.vnpmUrl + this.activeProject.id+MockCfg.podurlsuffix+'/';
  }

  ngOnInit() {
    this.router
      .routerState
      .queryParams
      .subscribe(params => {
        this.containerID = params['id'];
        /*if(!this.containerID.includes("://")){
          this.containerID="docker://"+this.containerID;
        }*/
        this.pod_ins_id = params['pod_ins_id'];
        this.srv_ins_id = params['srv_ins_id'];
      });

    this.getInitData();

  }
  private getInitData() {
    let that=this;
    this.http.request( this.podurl+ this.pod_ins_id)
      .subscribe(res => {
        let pod =res;
        this.pod_name = pod.pod_name;
        let containertemplist = pod.containerStatuses;
        let commontool:CommonTool =new CommonTool();
        for(let con of containertemplist)
        {
          if (con.containerID ==that.containerID)
          {
            this.deploy_name =con.name;
            // this.iconchar =this.deploy_name.charAt(0);
            if (con.ready)
            {
              con.statusmsg="";
              this.disable ="";
              that.run_status ="running";
              that.created_at =commontool.isoLocalTime(con.state.running.startedAt);
            }else {
              this.disable ="disable";

              if (con.state.waiting!=undefined)
              {
                that.created_at=commontool.isoLocalTime(con.lastState.terminated.startedAt);
                that.statusmsg =con.state.waiting.message;
                that.run_status="waiting";
              }else {
                that.created_at=commontool.isoLocalTime(con.state.terminated.startedAt);
                that.statusmsg ="";
                that.run_status ="terminated";
              }
            }
            that.getContainerInfo(pod);
            that.initlinks(pod);
          }
        }

      });
  }
  private getContainerInfo(item:any) {
    let that =this;
    let hostip =  item.node_ip;
    let containerId:any;
    containerId = this.containerID.substr(that.containerID.indexOf("://")+3, that.containerID.length);
    that.container=new containerinfo(hostip, null, containerId,item.ready);

  }

  openTerminal(container:any) {
    this.terminalService.dcLinkTerminal(container.ip,container.uuid)
  }

  private initlinks(item:any) {
    this.links=[];
    let applinkurl ="/project/"+this.activeProject.id+"/app";
    let applink = new link("应用中心",applinkurl);
    this.links.push(applink);

    if (this.srv_ins_id!="" &&this.srv_ins_id!="undefined" &&this.srv_ins_id!=undefined)
    {
      let srvlinkurl="/project/"+this.activeProject.id+"/app/srvdetail?id="+this.srv_ins_id;
      let srvlink =new link("服务",srvlinkurl);
      this.links.push(srvlink);

      let mslinkurl="/project/"+this.activeProject.id+"/app/msdetail?id="+item.ms_ins_id;
      let mslink =new link("微服务",mslinkurl);
      this.links.push(mslink);

      let podlinkurl ="/project/"+this.activeProject.id+"/app/poddetail?id="+this.pod_ins_id+"&srv_ins_id="+this.srv_ins_id;
      let podlink =new link("微服务实例",podlinkurl);
      this.links.push(podlink);
    }else{
      let mslinkurl="/project/"+this.activeProject.id+"/app/msdetail?id="+item.ms_ins_id;
      let mslink =new link("微服务",mslinkurl);
      this.links.push(mslink);

      let podlinkurl ="/project/"+this.activeProject.id+"/app/poddetail?id="+this.pod_ins_id;
      let podlink =new link("微服务实例",podlinkurl);
      this.links.push(podlink);
    }

    let conlink =new link("容器","");
    this.links.push(conlink);

  }

}

