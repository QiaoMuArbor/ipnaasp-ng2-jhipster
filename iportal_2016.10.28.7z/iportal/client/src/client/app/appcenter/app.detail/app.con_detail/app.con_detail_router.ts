import {ConDetailComponent} from "./app.con_detail";
import {AppContainerInfoComponent} from "../../app.containerinfo/app.containerinfo";
import {ApplogsComponent} from "../../app.logs/app.applogs";
import {AppkpiComponent} from "../../app.kpi/app.appkpi";
import { RouterConfig } from '@angular/router';
export const ConDetailRoutes: RouterConfig = [

  {
    path: 'condetail',
    component:ConDetailComponent,
    children:[
      {
        path:'',
        redirectTo:'instanceinfo',
        pathMatch:null
      },
      {
        path:'kpi',
        component:AppkpiComponent
      },
      {
        path:'logs',
        component:ApplogsComponent
      },

      {
        path:'instanceinfo',
        component:AppContainerInfoComponent
      }

    ]
  }
];

