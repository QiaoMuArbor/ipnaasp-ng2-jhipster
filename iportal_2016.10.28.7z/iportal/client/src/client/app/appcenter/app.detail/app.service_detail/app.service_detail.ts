import {Component, ViewChild} from '@angular/core';
import {ActivatedRoute, Router, ROUTER_DIRECTIVES} from '@angular/router';
import {MockCfg} from "../../../mock";
import {CommonTool} from "../../app.commontool";
import {ActiveProjectService} from "../../../app.service";
import {ModalComponent, MODAL_DIRECTIVES} from "ng2-bs3-modal/ng2-bs3-modal";
import {containerinfo, link} from "../../TypeClass";
import {KY_BREADCRUMB_DIRECTIVES} from "../ky-breadcrumb.component";
import {TerminalService} from "../app.terminalservice";
import {EventBroadcastService} from "../../../shared/event-broadcast.component";
import {ISOLocalPipe} from "../../../shared/pipes/iso-local.pipe";
import {AuthHttp} from "../../../shared/index";


@Component({
  moduleId: module.id,
  selector: 'service_detail;',
  styleUrls: ['../app.detail.css'],
  templateUrl: 'app.service_detail.html',
  directives: [KY_BREADCRUMB_DIRECTIVES, ROUTER_DIRECTIVES, MODAL_DIRECTIVES],
  providers: [CommonTool, TerminalService],
  pipes: [ISOLocalPipe]
})

export class ServiceDetailComponent {
  @ViewChild('modalup') modalup:ModalComponent;
  @ViewChild('modal') modal:ModalComponent;
  @ViewChild('modalelastic') modalelastic:ModalComponent;
  private srv_ins_id:string;
  private deploy_name:string;
  private created_at:string;
  private run_status:string;
  private alarmnum:any;
  private containerinfolist:Array<any> = [];
  serviceLevelsDesc:any = new Map();
  private currentlevel:string = "default";
  private currentleveldes:string = "";
  private isAuto:boolean = true;
  serviceLevels:Array<any> = [];

  private links:Array<link>;
  private serviceurl:string;
  private msid_list:Array<any>;
  private msserviceurl:string;
  private podserviceurl:string;
  private tip:string = "";
  private sVersion:string;
  private orchName:string='';
  private version:string;
  private inputParamArray:Array<any> = [];
  private bulePrintList:string;
  private common:string = "";
  private bTitle:string = "版本升级";
  private flaghead:string = "";
  private upVerfail:string;
  private name:Array<any> = [];
  private value:Array<any> = [];
  timeout:any;
  newV = {"name": "", "value": ""};
  private verflag = "tip";
  private epsurl:string;
  private currentalarmurl:string;
  private projectBulePrintList:any;
  private commonBulePrintList:any;
  private flag:any;
  private tenantId:string="";
  private bp_tenant_id:string='';


  constructor(public http:AuthHttp, private router:Router
    , private activeProject:ActiveProjectService, private terminalService:TerminalService,
              private eventBroadcastService:EventBroadcastService) {
    this.serviceurl = MockCfg.vnpmUrl + this.activeProject.id + MockCfg.serviceurlsuffix + '/';
    this.msserviceurl = MockCfg.vnpmUrl + this.activeProject.id + MockCfg.msserviceurlsuffix + '/';
    this.podserviceurl = MockCfg.vnpmUrl + this.activeProject.id + MockCfg.podurlsuffix + '/';
    this.epsurl = MockCfg.epsUrl + this.activeProject.id + "/services/";
    this.currentalarmurl = MockCfg.currentalarmUrl + this.activeProject.id + '/statistics/current/service_id/';
  }

  ngOnInit() {
    this.router
      .routerState
      .queryParams
      .subscribe(params => {
        this.srv_ins_id = params['id'];
      });
    this.getInitData();
    this.getLevelsDes();

    this.timeout = setInterval(() => {
      // 刷新信息;// this.getElasticParam();
      this.getElasticParam();
    }, 10000);
  }

  openConsoleModal() {
    this.getContainers();
    this.modal.open();
  }

  openElasticModal() {
    let schedules:Array<any> = [];
    let enable:boolean = true;
    let currenttime:any = this.getCurrentTime();
    this.http.get(MockCfg.epsUrl + this.activeProject.id + "/scheduled/services/" + this.srv_ins_id)
      .subscribe(res => {
        schedules = res.schedule_list;
        if(schedules != undefined){
          schedules.forEach((schedule:any)=> {
            if (currenttime > schedule.starttime && currenttime < schedule.endtime && schedule.enable && schedule.enable === true) {
              enable = false;
            }
          });
        }
        if (enable) {
          this.modalelastic.open();
        }else {
          this.eventBroadcastService.broadcastError('当前不能手动弹缩！');
        }
      });
  }

  private getInitData() {
    this.http.request(this.serviceurl + this.srv_ins_id)
      .subscribe(res => {
        let service = res;
        this.orchName = service.orch_name;
        this.bp_tenant_id =service.bp_tenant_id;
        this.version = service.version;
        this.inputParamArray = service.input_parameters;
        this.msid_list = service.ms_list;
        this.deploy_name = service.deploy_name;//todo:
        // this.iconchar =this.deploy_name.charAt(0);
        this.run_status = service.run_status;
        this.version = service.version;
        this.created_at = service.created_at;
        this.sVersion = this.version;
        this.created_at = new CommonTool().isoLocalTime(this.created_at);
        this.getCurrentAlarmNum(service);
        this.initlinks();
        this.getProjectBulePrintList();
        this.getCommonBulePrintList();
      });
  }


  //获取服务级别描述
  getLevelsDes() {
    this.http.get(MockCfg.epsUrl + this.activeProject.id + "/services/" + this.srv_ins_id + "/bps")
      .subscribe(res => {
        let tmp = res.capacity_level;
        if(tmp !=undefined)
        {
          tmp.forEach((des:any) => {
            this.serviceLevelsDesc.set(des.level, des.desc)
          });
          tmp.forEach((des:any) => {
            this.serviceLevels.push(des.level)
          });
        }
      });
    // this.serviceLevelsDesc.set("1", "1000");
    // this.serviceLevelsDesc.set("2", "2000");
    // this.serviceLevelsDesc.set("3", "3000");
    // this.serviceLevels.push("1");
    // this.serviceLevels.push("2");
    // this.serviceLevels.push("3");
  }

  //下拉框变化时的响应
  getLevelDes(level:string) {
    this.currentleveldes = this.serviceLevelsDesc.get(level);
  }

  //手动设置当前级别
  modifyLevel() {
    let json:any = {
      "auto_enable": false,
      "current_level": this.currentlevel
    }
    this.http.put(this.epsurl + this.srv_ins_id, json).subscribe();
  }

  //获取当前级别和弹缩状态
  getElasticParam() {
    this.http.get(this.epsurl + this.srv_ins_id)
      .subscribe(res => {
        if (res.current_level != undefined) {
          this.currentlevel = res.current_level;
          this.isAuto = res.auto_enable;
          this.getLevelDes(res.current_level);
        }
      });
  }

  //打开自动弹缩
  enableAutoElastic() {
    let schedules:Array<any> = [];
    let enable:boolean = true;
    let currenttime:any = this.getCurrentTime();
    this.http.get(MockCfg.epsUrl + this.activeProject.id + "/scheduled/services/" + this.srv_ins_id)
      .subscribe(res => {
        schedules = res.schedule_list;
        if(schedules != undefined){
        schedules.forEach((schedule:any)=> {
          if (currenttime > schedule.starttime && currenttime < schedule.endtime && schedule.enable && schedule.enable === true) {
            enable = false;
          }
        });
        }
        if (enable) {
          this.isAuto = true;
          let json:any = {
            "auto_enable": true,
            "current_level": this.currentlevel
          }
          this.http.put(this.epsurl + this.srv_ins_id, json).subscribe();
        }else{
          this.eventBroadcastService.broadcastError('当前不能自动弹缩！');
        }
      });
  }

  getCurrentTime() {
    let fulltime:string;
    let currentDate:Date = new Date();
    let date:any = this.fomateNumber(currentDate.getDate());
    let year:number = currentDate.getFullYear();
    let mouth:any = this.fomateNumber(currentDate.getMonth()+1);
    let hour:any = this.fomateNumber(currentDate.getHours());
    let minute:any = this.fomateNumber(currentDate.getMinutes());
    let seconds:any = this.fomateNumber(currentDate.getSeconds());
    fulltime = year + "/" + mouth + "/" + date + " " + hour + ":" + minute + ":" + seconds;
    return fulltime;
  }

  fomateNumber(num:any):string{
    if (num >= 0 && num < 10) {
      return "0" + num;
    } else {
      return num;
    }
  }

  //关闭自动弹缩
  disableAutoElastic() {
    this.isAuto = false;
    let json:any = {
      "auto_enable": false,
      "current_level": this.currentlevel
    }
    this.http.put(this.epsurl + this.srv_ins_id, json).subscribe();
  }

  private getCurrentAlarmNum(item:any) {
    this.http.request(this.currentalarmurl + item.srv_ins_id)
      .subscribe(res => {
          this.alarmnum = res.total;
        },
        error => {
          this.alarmnum = 0;
        }
      );
  }

  private getContainers() {
    this.containerinfolist = [];
    this.tip = "";
    for (let msid of this.msid_list) {
      this.http.request(this.msserviceurl + msid.ms_ins_id)
        .subscribe(res => {
          let ms = res;
          let podid_list = ms.pod_list;
          for (let podid of podid_list) {
            this.http.request(this.podserviceurl + podid.pod_ins_id)
              .subscribe(res => {
                let pod = res;
                let hostip = pod.node_ip;
                let tmpcons = pod.containerStatuses;
                let containerId:any;
                for (let con of tmpcons) {
                  let conidstr:string = con.containerID;
                  containerId = conidstr.substr(conidstr.indexOf("://") + 3, conidstr.length);
                  let coninfo:containerinfo = new containerinfo(hostip, con.name, containerId, con.ready);
                  this.containerinfolist.push(coninfo);
                }
              })
          }
        });
    }
  }

  private initlinks() {
    this.links = [];
    let applinkurl = "/project/" + this.activeProject.id + "/app";
    let applink = new link("应用中心", applinkurl);
    this.links.push(applink);

    let srvlinkurl = "/project/" + this.activeProject.id + "/app/servicedetail?id=" + this.srv_ins_id;
    let srvlink = new link("服务", "");
    this.links.push(srvlink)
  }

  openTerminal() {

    let selectValue = document.getElementById("selectid").value;
    let tmp = selectValue.split("&");
    let hostIp = tmp[0];
    let containerId = tmp[1];
    let status = tmp[2];
    if (status == "false") {
      this.tip = "该容器非运行状态，无法打开远程终端！";
      return false;
    } else {
      this.tip = "";
    }
    this.terminalService.dcLinkTerminal(hostIp, containerId);
  }

  slectchange() {
    let selectValue = document.getElementById("selectid").value;
    let tmp = selectValue.split("&");
    let hostIp = tmp[0];
    let containerId = tmp[1];
    let status = tmp[2];
    if (status == "false") {
      this.tip = "该容器非运行状态，无法打开远程终端！";
    } else {
      this.tip = "";
    }
  }

  slectchange() {
    let selectValue = document.getElementById("selectid").value;
    let tmp = selectValue.split("&");
    let hostIp = tmp[0];
    let containerId = tmp[1];
    let status = tmp[2];
    if (status == "false") {
      this.tip = "该容器非运行状态，无法打开远程终端！";
    } else {
      this.tip = "";
    }
  }

  getProjectBulePrintList(){
    this.http.get(MockCfg.swrVerUrl+this.activeProject.id+"/bps?name="+this.orchName+"&tag=service")
      .subscribe(resb => {
        this.projectBulePrintList = resb.list;
      });
  }

  getCommonBulePrintList(){
    this.http.get(MockCfg.swrVerUrl+this.activeProject.id+"/bps?name="+this.orchName+"&tag=service&publicview=yes")
      .subscribe(resb => {
        this.commonBulePrintList = resb.list;
      });
  }

  getBulePrintList(){
    let that = this;
    this.bulePrintList =  that.projectBulePrintList;
    /*
     for (let i of that.commonBulePrintList)
     this.bulePrintList.push(i);
     */
  }

  getInputParam(){
    let i = 0;
    for (let inputParam of this.inputParamArray){
      this.name[i] = inputParam.name;
      this.value[i] = inputParam.value;
      i++;
    }
  }

  initNewV() {
    this.newV = { name: '', value: '' };
  }
  del(item:string){
    this.inputParamArray = _.without(this.inputParamArray, item);
  }

  add(newV:string){
    this.inputParamArray.push(newV);
    this.initNewV();
  }

  openVersionUpModal(){
    this.getInputParam();
    this.getBulePrintList();
    this.modalup.open();
  }

  upMsVersion(){
    let  that = this;
    this.flag = that.orchName.indexOf("/");
    this.flaghead = that.orchName.substring(0,this.flag-1);
    let request={
      "orch_name": this.orchName,
      "version": this.sVersion,
      "parameters": this.inputParamArray,
      "bp_tenant_id": this.tenantId
    };
    this.http.put(this.serviceurl+this.srv_ins_id,request).subscribe();
    this.eventBroadcastService.broadcastSuccess('开始升级!');
    this.modal.dismiss();
    this.router.navigate(['/project',this.activeProject.id,'app']);
  }

  selectVersion(vs:string) {
    if(this.version == vs)
      document.getElementById(this.verflag).style.display = "none";
    this.sVersion = vs;
    document.getElementById(this.sVersion).style.display = "block";
    if (vs != this.verflag && this.verflag != "tip") {
      document.getElementById(this.verflag).style.display = "none";
    }
    this.verflag = vs;
    this.upVerfail = "";
  }

  startUpVersion(){
    if(this.sVersion != this.version){
      this.modalup.dismiss();
      this.upMsVersion();
    }
    else {
      this.upVerfail = "选择版本与当前版本相同!";
    }
  }

  ngOnDestroy() {
    clearInterval(this.timeout);
  }

}

