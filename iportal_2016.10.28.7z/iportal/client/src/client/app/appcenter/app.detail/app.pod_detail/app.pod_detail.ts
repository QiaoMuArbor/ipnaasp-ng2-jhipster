import {Component,ViewChild} from '@angular/core';
import {ActivatedRoute, Router, ROUTER_DIRECTIVES} from '@angular/router';
import {MockCfg} from "../../../mock";
import {CommonTool} from "../../app.commontool";
import {ActiveProjectService} from "../../../app.service";
import {ModalComponent,MODAL_DIRECTIVES} from "ng2-bs3-modal/ng2-bs3-modal";
import {containerinfo, link} from "../../TypeClass";
import {KY_BREADCRUMB_DIRECTIVES} from "../ky-breadcrumb.component";
import {TerminalService} from "../app.terminalservice";
import {ISOLocalPipe} from "../../../shared/pipes/iso-local.pipe";
import {AuthHttp} from "../../../shared/index";


@Component({
  moduleId: module.id,
  selector: 'ms_detail;',
  styleUrls: ['../app.detail.css'],
  templateUrl: 'app.pod_detail.html',
  directives: [KY_BREADCRUMB_DIRECTIVES,ROUTER_DIRECTIVES,MODAL_DIRECTIVES],
  providers: [CommonTool,TerminalService],
  pipes: [ISOLocalPipe]
})

export class PodDetailComponent {

  @ViewChild('modal')
  modal:ModalComponent;

  private pod_ins_id:string;
  private deploy_name:string;
  private iconchar:string;
  private created_at:string;
  private run_status:string;
  private alarmnum:any;

  private containerinfolist:Array<any>=[];
  private pod_name:string;
  private pod:any;
  private links:Array<link>;
  private podurl:string;
  private srv_ins_id:string;
  private currentalarmurl:string;
  constructor(public http:AuthHttp, private route:ActivatedRoute, private router:Router
    ,private activeProject: ActiveProjectService,private terminalService:TerminalService ) {
    this.podurl=MockCfg.vnpmUrl + this.activeProject.id+MockCfg.podurlsuffix+'/';
    this.currentalarmurl=MockCfg.currentalarmUrl +this.activeProject.id+ '/statistics/current/name/';
  }

  ngOnInit() {
    this.router
      .routerState
      .queryParams
      .subscribe(params => {
        this.pod_ins_id = params['id'];
        this.srv_ins_id = params['srv_ins_id'];
      });

    this.getInitData();

  }

  openConsoleModal(){
    this.getContainers();
    this.modal.open();
  }
  private getInitData() {
    let that=this;
    this.http.request( this.podurl+ this.pod_ins_id)
      .subscribe(res => {
        that.pod = res;
        that.pod_name =that.pod.pod_name;
        that.deploy_name = that.pod.pod_name;//todo:
        // that.iconchar =that.deploy_name.charAt(0);
        that.run_status = that.pod.run_status;
        that.created_at = that.pod.created_at;
        that.created_at = new CommonTool().isoLocalTime(this.created_at);
        that.getCurrentAlarmNum(that.pod);
        that.initlinks();
      });
  }

  private getCurrentAlarmNum(pod:any) {
    this.http.request(this.currentalarmurl + pod.pod_ins_id)
      .subscribe(res => {
          this.alarmnum = res.total;
        },
        error => {
          this.alarmnum = 0;
        }
      );
  }

  private getContainers() {
    this.containerinfolist=[];
    let tmpcons = this.pod.containerStatuses;
    let hostip=this.pod.node_ip;
    let containerId:any;
    for (let con of tmpcons) {
      let conidstr:string = con.containerID;
      containerId = conidstr.substr(conidstr.indexOf("://")+3, conidstr.length);
      let coninfo:containerinfo = new containerinfo(hostip, con.name, containerId,con.ready);
      this.containerinfolist.push(coninfo);
    }
  }

  private initlinks() {
    this.links=[];
    let applinkurl ="/project/"+this.activeProject.id+"/app";
    let applink = new link("应用中心",applinkurl);
    this.links.push(applink);

    if (this.srv_ins_id!="" && this.srv_ins_id!="undefined" &&this.srv_ins_id!=undefined )
    {
      let srvlinkurl="/project/"+this.activeProject.id+"/app/servicedetail?id="+this.srv_ins_id;
      let srvlink =new link("服务",srvlinkurl);
      this.links.push(srvlink)

      let mslinkurl="/project/"+this.activeProject.id+"/app/msdetail?id="+this.pod.ms_ins_id;
      let mslink =new link("微服务",mslinkurl);
      this.links.push(mslink);
    }else {
      let mslinkurl="/project/"+this.activeProject.id+"/app/msdetail?id="+this.pod.ms_ins_id;
      let mslink =new link("微服务",mslinkurl);
      this.links.push(mslink);
    }
    let podlink =new link("微服务实例","");
    this.links.push(podlink);

  }
  openTerminal() {

    let selectValue = document.getElementById("selectid").value;
    let tmp =selectValue.split("&");
    let hostIp = tmp[0];
    let containerId = tmp[1];
    let status = tmp[2];
    if(status=="false"){
      this.tip ="该容器非运行状态，无法打开远程终端！";
      return false;
    }else {
      this.tip ="";
    }
    this.terminalService.dcLinkTerminal(hostIp,containerId);
  }

  slectchange(){
    let selectValue = document.getElementById("selectid").value;
    let tmp =selectValue.split("&");
    let status = tmp[2];
    if(status=="false"){
      this.tip ="该容器非运行状态，无法打开远程终端！";
    }else {
      this.tip ="";
    }
  }
}

