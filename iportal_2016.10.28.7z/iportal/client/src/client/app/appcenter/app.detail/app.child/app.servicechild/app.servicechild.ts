import {MODAL_DIRECTIVES} from "ng2-bs3-modal/ng2-bs3-modal";
import {Component,ViewChild} from '@angular/core';
import {ISOLocalPipe} from "../../../../shared/pipes/iso-local.pipe";
import {AuthHttp} from "../../../../shared/index";
import {CommonTool} from "../../../app.commontool";
import {ActivatedRoute,Router,ROUTER_DIRECTIVES} from '@angular/router';
import {MockCfg} from "../../../../mock";
import {ActiveProjectService} from "../../../../app.service";
@Component({
  moduleId: module.id,
  pipes:[ISOLocalPipe],
  providers:[CommonTool],
  selector: 'app-mschild',
  styleUrls:['../app.childresource.css'],
  templateUrl: 'app.servicechild.html',
  directives: [MODAL_DIRECTIVES,ROUTER_DIRECTIVES],
})

export class ServiceChildResourceComponent {
  private ChildResourceData:Array<any>;
  private serviceurl:string;
  private srv_ins_id:string;
  private msserviceurl:string;
  private currentalarmurl:string;

  constructor(public http:AuthHttp,private route: ActivatedRoute,private router: Router,
              private activeProject: ActiveProjectService){
    this.serviceurl =MockCfg.vnpmUrl+this.activeProject.id+MockCfg.serviceurlsuffix+'/';
    this.msserviceurl =MockCfg.vnpmUrl+this.activeProject.id+MockCfg.msserviceurlsuffix+'/';
    this.currentalarmurl=MockCfg.currentalarmUrl + this.activeProject.id+'/statistics/current/';
  }
  ngOnInit(){
    this.router
      .routerState
      .queryParams
      .subscribe(params => {
        this.srv_ins_id = params['id'];
      });
    this.initData();
  }

  private initData() {
    this.ChildResourceData=[];
    this.http.request( this.serviceurl+ this.srv_ins_id)
      .subscribe(res => {
        let msidlist=res.ms_list;
        for(let msid of msidlist)
        {
          this.getMsInstanceById(msid.ms_ins_id);
        }
      });
  }
  private getCurrentAlarmNum(item:any,type:string) {
    this.http.request(this.currentalarmurl+type+'/' + item.ms_ins_id)
      .subscribe(res => {
          item.alarm_num=res.total;
        },
        error => {
          item.alarm_num = 0;
        }
      );
  }

  private getMsInstanceById(msid:any) {
    this.http.request( this.msserviceurl+ msid)
      .subscribe(res => {
        let ms = res;
        ms.imageurl="../../../images/apps/ms.png";

        if(ms.deploy_name==''||ms.deploy_name==undefined){
          ms.name=new CommonTool().changeLongNameStr(ms.ms_ins_id);
          ms.fullname =ms.ms_ins_id;
        }else{
          ms.name=new CommonTool().changeLongNameStr(ms.deploy_name);
          ms.fullname =ms.deploy_name;
        }
        ms.created_at=new CommonTool().isoLocalTime(ms.created_at);
        this.getCurrentAlarmNum(ms,'microservice_id');
        this.ChildResourceData.push(ms);
      });
  }
}
