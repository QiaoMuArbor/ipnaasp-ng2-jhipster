import {ApplogsComponent} from "../../app.logs/app.applogs";
import {AppkpiComponent} from "../../app.kpi/app.appkpi";
import {AppCurrentAlarmComponent} from "../../app.currentalarm/app.currentalarm";
import {AppEventComponent} from "../../app.event/app.event";
import {AppServiceAddressComponent} from "../../app.serviceaddress/app.serviceaddress";
import {ServiceDetailComponent} from "./app.service_detail";
import {ServiceChildResourceComponent} from "../app.child/app.servicechild/app.servicechild";
import {AppServcieElasticComponent} from "../../app.elastic/app.service_elastic/app.serviceelastic";
import { RouterConfig } from '@angular/router';
export const ServiceDetailRoutes: RouterConfig = [

  {
    path: 'servicedetail',
    component:ServiceDetailComponent,
    children:[
      {
        path:'',
        redirectTo:'service_child',
        pathMatch:null
      },
      {
        path:'service_child',
        component:ServiceChildResourceComponent
      },
      {
        path:'kpi',
        component:AppkpiComponent
      },
      {
        path:'logs',
        component:ApplogsComponent
      },
      {
        path:'currentalarm',
        component:AppCurrentAlarmComponent
      },
      {
        path:'event',
        component:AppEventComponent
      },
      {
        path:'serviceaddress',
        component:AppServiceAddressComponent
      },
      {
        path:'elastic',
        component:AppServcieElasticComponent
      }

    ]
  }
];

