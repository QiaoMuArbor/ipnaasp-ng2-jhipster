import {PodDetailComponent} from "./app.pod_detail";
import {PodChildResourceComponent} from "../app.child/app.podchild/app.podchild";
import {ApplogsComponent} from "../../app.logs/app.applogs";
import {AppkpiComponent} from "../../app.kpi/app.appkpi";
import {AppCurrentAlarmComponent} from "../../app.currentalarm/app.currentalarm";
import {AppEventComponent} from "../../app.event/app.event";
import {AppInstanceInfoComponent} from "../../app.instanceinfo/app.instanceinfo";
import { RouterConfig } from '@angular/router';
export const PodDetailRoutes: RouterConfig = [

  {
    path: 'poddetail',
    component:PodDetailComponent,
    children:[
      {
        path:'',
        redirectTo:'instanceinfo',
        pathMatch:null
      },
      {
        path:'kpi',
        component:AppkpiComponent
      },
      {
        path:'pod_child',
        component:PodChildResourceComponent
      },
      {
        path:'logs',
        component:ApplogsComponent
      },
      {
        path:'currentalarm',
        component:AppCurrentAlarmComponent
      },
      {
        path:'event',
        component:AppEventComponent
      },
      {
        path:'instanceinfo',
        component: AppInstanceInfoComponent,
      }

    ]
  }
];

