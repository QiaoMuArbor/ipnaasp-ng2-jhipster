
import { Injectable } from '@angular/core';

@Injectable()
export class TerminalService {
  dcLinkTerminal(hostIp:string,containerId:string) {
    if (hostIp==""||hostIp==undefined || containerId =="" ||containerId ==undefined)
    {
      return;
    }
    let localHostIP=window.location.host;
    localHostIP =localHostIP.substring(0,localHostIP.indexOf(':'));
    let url = "http://"+localHostIP+":9399/keybox/terminal.action?containerId="+containerId+"&nodeIp="+hostIp;
    window.open(url);
  }
}

