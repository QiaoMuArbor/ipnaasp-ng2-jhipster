import {MSDetailComponent} from "./app.ms_detail";
import {MsChildResourceComponent} from "../app.child/app.mschild/app.mschild";
import {ApplogsComponent} from "../../app.logs/app.applogs";
import {AppkpiComponent} from "../../app.kpi/app.appkpi";
import {AppCurrentAlarmComponent} from "../../app.currentalarm/app.currentalarm";
import {AppEventComponent} from "../../app.event/app.event";
import {AppServiceAddressComponent} from "../../app.serviceaddress/app.serviceaddress";
import {AppMsElasticComponent} from "../../app.elastic/app.ms_elastic/app.mselastic";
import { RouterConfig } from '@angular/router';
export const MSDetailRoutes: RouterConfig = [

  {
    path: 'msdetail',
    component:MSDetailComponent,
    children:[
      {
        path:'',
        redirectTo:'ms_child',
        pathMatch:null
      },
      {
        path:'ms_child',
        component:MsChildResourceComponent
      },
      {
        path:'kpi',
        component:AppkpiComponent
      },
      {
        path:'logs',
        component:ApplogsComponent
      },
      {
        path:'currentalarm',
        component:AppCurrentAlarmComponent
      },
      {
        path:'event',
        component:AppEventComponent
      },
      {
        path:'serviceaddress',
        component:AppServiceAddressComponent
      },
      {
        path:'elastic',
        component:AppMsElasticComponent
      }

    ]
  }
];

