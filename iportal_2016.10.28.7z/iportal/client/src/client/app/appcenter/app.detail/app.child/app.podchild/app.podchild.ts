import {MODAL_DIRECTIVES} from "ng2-bs3-modal/ng2-bs3-modal";
import {Component,ViewChild} from '@angular/core';
import {ISOLocalPipe} from "../../../../shared/pipes/iso-local.pipe";
import {AuthHttp} from "../../../../shared/index";
import {CommonTool} from "../../../app.commontool";
import {ActivatedRoute,Router,ROUTER_DIRECTIVES} from '@angular/router';
import {MockCfg} from "../../../../mock";
import {ActiveProjectService} from "../../../../app.service";
import {TerminalService} from "../../app.terminalservice";
@Component({
  moduleId: module.id,
  pipes:[ISOLocalPipe],
  providers:[CommonTool],
  selector: 'app-podchild',
  styleUrls:['../app.childresource.css'],
  templateUrl: 'app.podchild.html',
  directives: [MODAL_DIRECTIVES,ROUTER_DIRECTIVES],
})

export class PodChildResourceComponent {
  private pod_ins_id:string;

  private ChildResourceData:Array<any>;
  private podurl:string;
  private srv_ins_id:string;

  constructor(public terminalService:TerminalService,public http:AuthHttp,private route: ActivatedRoute,private router: Router,
              private activeProject: ActiveProjectService){
    this.podurl =MockCfg.vnpmUrl+this.activeProject.id+MockCfg.podurlsuffix+'/';
  }
  ngOnInit(){
    this.router
      .routerState
      .queryParams
      .subscribe(params => {
        this.pod_ins_id = params['id'];
        this.srv_ins_id = params['srv_ins_id'];
      });
    this.initData();
  }

  private initData() {
    this.ChildResourceData=[];
    this.http.request( this.podurl+ this.pod_ins_id)
      .subscribe(res => {
        let pod =res;
        let hostip =pod.node_ip;
        this.ChildResourceData=pod.containerStatuses;
        let commontool:CommonTool =new CommonTool();
        for (let con of this.ChildResourceData)
        {
          con.imageurl="../../../images/apps/container.png";
          if(con.ready){
            con.notclicktocondetail="no";
            con.statusmsg ="";
            con.disabled="";
            con.created_at=commontool.isoLocalTime(con.state.running.startedAt);
            con.run_status ="running";
            // con.containerID =con.containerID.substr(con.containerID.indexOf("://")+3, con.containerID.length);
          }else {
            con.disabled="disabled";
            if(!con.containerID || con.containerID=="")
            {
              con.notclicktocondetail ="yes";
              con.run_status="容器没有ID";
            }else {
              con.notclicktocondetail ="no";
              // con.containerID =con.containerID.substr(con.containerID.indexOf("://")+3, con.containerID.length);
              if (con.state.waiting!=undefined)
              {
                con.created_at=commontool.isoLocalTime(con.lastState.terminated.startedAt);
                con.statusmsg =con.state.waiting.message;
                con.run_status="waiting";
              }else {
                con.created_at=commontool.isoLocalTime(con.state.terminated.startedAt);
                con.statusmsg ="";
                con.run_status ="terminated";
              }
            }
          }
          con.ip=hostip;
        }
      });
  }
  openTerminal(item:any) {
    let hostIp = item.ip;
    let conid:string = item.containerID;
    conid = conid.substr(conid.indexOf("://")+3, item.containerID.length);
    this.terminalService.dcLinkTerminal(hostIp,conid)
  }
}
