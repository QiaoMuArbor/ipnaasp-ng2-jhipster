import {Component} from "@angular/core";
import {Router} from '@angular/router';
import {Http, Response}  from '@angular/http';
import {MockCfg} from "../../mock";
import {DateFormat} from '../../shared/pipes/function';
import {ActiveProjectService} from "../../app.service";

@Component({
  moduleId: module.id,
  selector: 'app-containesinfo',
  templateUrl: 'app.containerinfo.html',
  styleUrls: ['app.containerinfo.css'],
  providers: [DateFormat]
})

export class AppContainerInfoComponent {
  private podId:string;
  private conId:string;
  private stastus:Array<any> = [];
  private envs:Array<any> = [];
  private volumes:Array<any> = [];
  private commands:Array<any> = [];
  private args:Array<any> = [];
  private image:string;
  private simpleUUID:string;
  private netinfos:Array<any> = [];
  private ready:boolean;
  private state:any;
  private reqUrl:string;
  private restartCount:number;
  private imageID:string;
  private resources:Array<any> = [];
  private isLoading:boolean = true;
  private podIp:string;

  constructor(private router:Router, private _http:Http, private dateFormat:DateFormat, private activeProject:ActiveProjectService) {
    this.reqUrl = MockCfg.vnpmUrl + this.activeProject.id + MockCfg.podurlsuffix+'/';
  }

  ngOnInit() {
    this.ready = false;
    this.getParams();
    this.getContainerInfo();
    this.isLoading=false;
  }

  getParams() {
    let that = this;
    that.router.routerState.queryParams.subscribe(params => {
      that.podId = params['pod_ins_id'];
      that.conId = params['id'];
      that.simpleUUID = that.conId.substring(that.conId.indexOf("://") + 3, that.conId.length)
    });
  }

  getContainerInfo() {
    let that = this;
    this._http.request(this.reqUrl + this.podId)
      .subscribe((res:Response) => {
        that.podIp=res.json().node_ip;
        let containers = res.json().containers;
        let containerStatuses = res.json().containerStatuses;
        that.findContainer(containerStatuses);
        that.getInfo(containers);
      });

    this.sort();
  }

sort(){
  this.commands.sort(function (a:string, b:string) {
        return a.length > b.length ? 1 : 0;
      }
    );

    this.args.sort(function (a:string, b:string) {
        return a.length > b.length ? 1 : 0;
      }
    );

    this.envs.sort(function (a:string, b:string) {
        return a.length > b.length ? 1 : 0;
      }
    );

    this.volumes.sort(function (a:string, b:string) {
        return a.length > b.length ? 1 : 0;
      }
    );
}

  getStatus(ready:boolean, statuse:any) {
    if (ready) {
      this.stastus.push("状态：running");
      this.stastus.push("启动时间：" + this.dateFormat.IsoLocalTime(new Date(statuse.running.startedAt).getTime()));
    } else {
      if (statuse.waiting) {
        this.stastus.push("状态：waiting");
        let reason = statuse.waiting.reason.length > 70 ? statuse.waiting.reason.substring(0, 70) + "..." : statuse.waiting.reason;
        this.stastus.push("原因：" + reason);
        let message = statuse.waiting.message.length > 70 ? statuse.waiting.message.substring(0, 70) + "..." : statuse.waiting.message;
        this.stastus.push("相关信息：" + message);
      }
      else if (statuse.terminated) {
        this.stastus.push("状态：terminated");
        this.stastus.push("启动时间：" + this.dateFormat.IsoLocalTime(new Date(statuse.terminated.startedAt).getTime()));
        this.stastus.push("结束时间：" + this.dateFormat.IsoLocalTime(new Date(statuse.terminated.finishedAt).getTime()));
        let reason = statuse.terminated.reason.length > 70 ? statuse.terminated.reason.substring(0, 70) + "..." : statuse.terminated.reason;
        this.stastus.push("原因：" + reason);
        this.stastus.push("退出码：" + statuse.terminated.exitCode);
      }
    }
  }

findContainer(containerStatuses:Array<any>){
  let that=this;
   let status=_.find(containerStatuses, function(thestatus){ return thestatus.containerID == that.conId;});
            that.image = status.image;
            that.getStatus(status.ready, status.state);
            that.restartCount = status.restartCount;
            that.imageID = status.imageID;
}

getInfo(containers:Array<any>){
  let that=this;
  let info=_.find(containers, function(theinfo){ return that.image == theinfo.image;});

  if (info.command) {
      that.commands = info.command;
    }
  if (info.args) {
              that.args = info.args;
            }
  if (info.env) {
              info.env.forEach((item:any) => {
                let value = item.value.length > 40 ? item.value.substring(0, 40) + "..." : item.value;
                that.envs.push(item.name + "：" + value);
              });
            }
            if (info.volumeMounts) {
              info.volumeMounts.forEach((item:any) => {
                let mountPath = item.mountPath.length > 40 ? item.mountPath.substring(0, 40) + "..." : item.mountPath;
                let volumeMount = item.name + "：" + mountPath + (item.readOnly ? "（只读）" : "");
                that.volumes.push(volumeMount);
              });
            }
            if (info.ports) {
              info.ports.forEach((item:any) => {
                let portsInfo:Array<string>=[];
                if (item.name) {
                  portsInfo.push("名字：" + item.name);
                }
                if (item.hostPort) {
                  portsInfo.push("主机端口：" + item.hostPort);
                }
                if (item.containerPort) {
                  portsInfo.push("容器端口：" + item.containerPort);
                }
                if (item.protocol) {
                  portsInfo.push("协议：" + item.protocol);
                }
                if (item.hostIP) {
                  portsInfo.push("主机地址：" + item.hostIP);
                }
                that.netinfos.push(portsInfo);
              });
            }

            if (info.resources.limits) {
              that.resources.push("CPU：" + info.resources.limits.cpu);
              that.resources.push("内存：" + info.resources.limits.memory);
            }
        }

}
