import {Component, ViewChild} from "@angular/core";
import {NgSwitch, NgSwitchCase, NgSwitchDefault,NgStyle} from "@angular/common";
import {ROUTER_DIRECTIVES} from "@angular/router";
import {MODAL_DIRECTIVES, ModalComponent} from 'ng2-bs3-modal/ng2-bs3-modal';
import {ISOLocalPipe} from "../shared/pipes/iso-local.pipe";
import {ActiveProjectService} from "../app.service";
import {AppTopoComponent} from "./app.topo/app.topo";
import {MockCfg} from "../mock";
import {CommonTool} from "./app.commontool";
import {ToChinesePipe} from "./statusTransfertoChinese";
import {UserNameComponent} from "../user/username.component";
import {AuthHttp} from "../shared/index";
@Component({
  moduleId: module.id,
  directives: [UserNameComponent,MODAL_DIRECTIVES, ROUTER_DIRECTIVES, NgSwitch, NgSwitchCase, NgSwitchDefault, NgStyle,AppTopoComponent],
  pipes: [ISOLocalPipe, ToChinesePipe],
  properties: ["gender"],
  styleUrls: ['app.css','progressbar.css'],
  templateUrl: 'app.html'
})

export class AppCenterComponent {
  @ViewChild('delModal') delModal:ModalComponent;
  @ViewChild('delsomeModal') delsomeModal:ModalComponent;

  // 与html绑定;
  serviceTable:Array<any>;
  serviceTableTemp:Array<any>;
  delInstance:any;
  timeout:any;
  isCloseTopo:boolean;

  // 根据使用接口给不同类型的指定确定类型;
  types:Array<string> = ["service", "microService"];
  someDelete:Array<any>;
  private serviceurl:string;
  private msserviceurl:string;
  checkboxindex:Array<any>;
  private currentalarmurl:string;

  constructor(public http:AuthHttp, private activeProject:ActiveProjectService) {
    // this.serviceTable = [];
    this.serviceTable = [];
    this.someDelete = [];

    this.serviceurl = MockCfg.vnpmUrl + this.activeProject.id + MockCfg.serviceurlsuffix;
    this.msserviceurl = MockCfg.vnpmUrl + this.activeProject.id + MockCfg.msserviceurlsuffix;
    this.currentalarmurl=MockCfg.currentalarmUrl + this.activeProject.id+ "/statistics/current/";
    this.checkboxindex = [];

  }

  ngOnInit() {

    this.checkboxindex = [];
    this.freshTable();
    this.timeout = setInterval(() => {
      // 刷新信息;
      this.freshTable();
    }, 10000);
  }

  private freshTable() {
    this.recoverCheckboxStatus();
    this.serviceTableTemp = [];
    this.getServices(this.serviceurl, this.types[0]);

  }

  private getMicrServices(msserviceUrl:string, type:string) {
    this.http.get(this.msserviceurl)
      .map(res => res)
      .subscribe(
        res => {
          this.getApplicationListData(type, res);
          if (type == this.types[0]) {
            this.getServices(this.msserviceurl, this.types[1]);
          } else {
            this.diffTempWithServiceTable();
          }
        },
        err=> {
          this.diffTempWithServiceTable();
        }
      );
  }

  private getServices(serviceUrl:string, type:string) {
    this.http.get(serviceUrl)
      .map(res => res)
      .subscribe(
        res => {
          this.getApplicationListData(type, res);
          if (type == this.types[0]) {
            this.getServices(this.msserviceurl, this.types[1]);
          } else {
            this.diffTempWithServiceTable();
          }
        },
        err=> {
          this.getMicrServices(this.msserviceurl, this.types[1]);

        }
      );
  }

  private diffTempWithServiceTable() {
    if (this.serviceTableTemp == undefined || this.serviceTableTemp.length == 0) {
      this.serviceTable = [];
      return;
    }
    this.addNewServiceInfo();
    this.delOverdueService();
    // this.serviceTable = _.sortBy(this.serviceTable,"created_at");
    this.serviceTable = this.serviceTable.sort(this.acomparecreattime);
    this.recoverCheckboxStatus();
  }

  acomparecreattime(value1:any, value2:any):number {
    let time1:number = Date.parse(value1.created_at);
    let time2:number = Date.parse(value2.created_at);
    if (time1 < time2) {
      return 1;
    } else if (time1 > time2) {
      return -1;
    } else {
      return 0;
    }
  }


  private addNewServiceInfo() {
    let tableLength = this.serviceTable.length;
    let tempLength = this.serviceTableTemp.length;
    let tableUUID:Array<any> = [];
    for (let tableIndex = 0; tableIndex < tableLength; ++tableIndex) {
      if (this.serviceTable[tableIndex].type == this.types[0]) {
        tableUUID.push(this.serviceTable[tableIndex].srv_ins_id)
      } else {
        tableUUID.push(this.serviceTable[tableIndex].ms_ins_id)
      }

    }
    for (let tempIndex = 0; tempIndex < tempLength; ++tempIndex) {
      if (this.serviceTableTemp[tempIndex].type == this.types[0]) {
        if (!_.contains(tableUUID, this.serviceTableTemp[tempIndex].srv_ins_id)) {
          this.serviceTable.push(this.serviceTableTemp[tempIndex]);
        }
      } else {
        if (!_.contains(tableUUID, this.serviceTableTemp[tempIndex].ms_ins_id)) {
          this.serviceTable.push(this.serviceTableTemp[tempIndex]);
        }
      }

    }
  }

  private delOverdueService() {
    let tempLength = this.serviceTableTemp.length;
    let tableLength = this.serviceTable.length;
    let tempUUID:Array<any> = [];
    for (let tempIndex = 0; tempIndex < tempLength; ++tempIndex) {
      if (this.serviceTableTemp[tempIndex].type == this.types[0]) {
        tempUUID.push(this.serviceTableTemp[tempIndex].srv_ins_id)
      } else {
        tempUUID.push(this.serviceTableTemp[tempIndex].ms_ins_id)
      }

    }
    for (let tableIndex = 0; tableIndex < tableLength; ++tableIndex) {
      if (this.serviceTable[tableIndex].type == this.types[0]) {
        if (!_.contains(tempUUID, this.serviceTable[tableIndex].srv_ins_id)) {
          this.serviceTable.splice(tableIndex, 1);
        }
      } else {
        if (!_.contains(tempUUID, this.serviceTable[tableIndex].ms_ins_id)) {
          this.serviceTable.splice(tableIndex, 1);
        }
      }

      for (let tempIndex = 0; tempIndex < tempLength; ++tempIndex) {
        if (this.serviceTable[tableIndex].type == this.types[0]) {
          if (this.serviceTable[tableIndex].srv_ins_id == this.serviceTableTemp[tempIndex].srv_ins_id) {
            this.serviceTable[tableIndex] = this.serviceTableTemp[tempIndex];
          }
        } else {
          if (this.serviceTable[tableIndex].ms_ins_id == this.serviceTableTemp[tempIndex].ms_ins_id) {
            this.serviceTable[tableIndex] = this.serviceTableTemp[tempIndex];
          }
        }

      }
    }
  }

  private getApplicationListData(type:string, res:any) {
    let services:Array<any> = [];
    if (type == 'service') {
      services = res.srv_list;
    } else {
      services = res.ms_list;
    }

    this.addData2TreeTable(services, type);
  }

  private addData2TreeTable(services:Array<any>, type:string) {
    // let servicesJson = _.where(services, {ver_type: this.activeProject.id + '_release'});
    let servicesJson = services;
    if (servicesJson != undefined && servicesJson.length != 0) {
      for (let service of servicesJson) {
        service.type = type;
        service.ischecked = "";
        service.created_at = new CommonTool().isoLocalTime(service.created_at);
        service.alarm_num = 0;
        this.serviceTableTemp.push(service);
        this.requestAlarmNum(service);
      }
    }
  }


  private requestAlarmNum(item:any) {
    let url = '';
    if (item.type == this.types[0]) {
      url = this.currentalarmurl+"service_id/" + item.srv_ins_id;
    } else {
      url = this.currentalarmurl+"microservice_id/" + item.ms_ins_id;
    }
    this.http.request(url)
      .map(res => res)
      .subscribe(res => {
          item.alarm_num = res.total;
        },
        error => {
          item.alarm_num = 0;
        }
      );
  }


  /*private showTopo(serviceData:any) {
   if (serviceData.isShowTopo=="true") {
   serviceData.isShowTopo="false";
   return;
   }
   this.assignIsShowTopo2False();
   serviceData.isShowTopo='true';
   this.isCloseTopo = false;
   }*/

  /*private hideTopo() {
   if (this.isCloseTopo == false) {
   this.isCloseTopo = true;
   return;
   }
   this.assignIsShowTopo2False();
   }*/

  /*private assignIsShowTopo2False() {
   let that = this;
   let length = that.serviceTable.length;
   for(let i=0; i < length; i++ ){
   that.serviceTable[i].isShowTopo = false;
   }
   }*/

  private openDelModal(instance:any) {
    this.delInstance = instance;
    this.delModal.open();
  }

  private deleteInstance() {
    this.delModal.dismiss();
    if (this.delInstance.type == "service") {
      this.http.delete(this.serviceurl + '/' + this.delInstance.srv_ins_id).subscribe();
    } else {
      this.http.delete(this.msserviceurl + '/' + this.delInstance.ms_ins_id).subscribe();
    }
    this.checkboxindex = [];
    this.freshTable();
    // clearInterval(this.delInstance);
    // window.location.reload();
  }

  ngOnDestroy() {
    clearInterval(this.timeout);
  }

  changeimg(id:string) {
    let imgid = id;
    if (imgid == "refresh")
      (<HTMLInputElement> document.getElementById("refresh")).src = "../../../images/apps/refreshchange.svg";
    if (imgid == "moreimg")
      (<HTMLInputElement> document.getElementById("moreimg")).src = "../../../images/apps/tobottom1.svg";
  }

  recoverimg(id:string) {
    let imgid = id;
    if (imgid == "refresh")
      (<HTMLInputElement> document.getElementById("refresh")).src = "../../images/apps/refresh.svg";
    if (imgid == "moreimg")
      (<HTMLInputElement> document.getElementById("moreimg")).src = "../../images/apps/tobottom.svg";
  }

  addCheckAll() {

    let size = this.serviceTable.length;

    if (document.getElementById("checkboxAll").checked == true) {
      for (let i = 0; i < size; i++) {

        if (!this.checkboxindex.includes(i + '')) {
          this.checkboxindex.push(i + '');
        }
        document.getElementById("check" + i).checked = true;
        this.serviceTable[i].ischecked = "checked";
      }

    } else {
      for (let i = 0; i <= size; i++) {
        if (this.checkboxindex.includes(i + '')) {
          this.checkboxindex.splice(this.checkboxindex.indexOf(i + ''), 1);
        }
        document.getElementById("check" + i).checked = false;
        this.serviceTable[i].ischecked = "";
      }
    }
  }

  clickCheckbox(ischecked:any, index:any) {
    if (ischecked) {
      if (!this.checkboxindex.includes(index)) {
        this.checkboxindex.push(index);
      }
      this.serviceTable[index].ischecked = "checked";
    } else {
      if (this.checkboxindex.includes(index)) {
        this.checkboxindex.splice(this.checkboxindex.indexOf(index), 1);
      }
      let indexnum = parseInt(index);
      this.serviceTable[indexnum].ischecked = "";
    }
  }

  beSelectedInstance() {
    let that = this;
    that.someDelete = [];
    let length = this.serviceTable.length;
    for (let i = 0; i < length; i++) {
      if (this.serviceTable[i].ischecked == "checked") {
        that.someDelete.push(that.serviceTable[i]);
      }
    }
  }


  openSomeDelModal() {

    this.beSelectedInstance();
    if(this.someDelete.length==0)
      return;
    this.delsomeModal.open();
  }

  deleteSomeInstance() {
    this.delsomeModal.dismiss();
    let that = this;

    let length = that.someDelete.length;
    if (length > 0) {
      for (let i = 0; i < length; i++) {

        if (this.someDelete[i].type == "service") {
          this.http.delete(this.serviceurl + '/' + this.someDelete[i].srv_ins_id).subscribe();
        } else {
          this.http.delete(this.msserviceurl + '/' + this.someDelete[i].ms_ins_id).subscribe();
        }


        // clearInterval(this.someDelete[i]);
      }
    }
    this.checkboxindex = [];
    this.freshTable();
    document.getElementById("checkboxAll").checked = false;
  }

  private recoverCheckboxStatus() {
    let length = this.checkboxindex.length;
    if (length > 0) {
      for (let index of this.checkboxindex) {
        let indexnum = parseInt(index);
        this.serviceTable[indexnum].ischecked = "checked";
      }
    }
  }

  private isMirrorOrBlue(item:any) {

    if (item.type == this.types[0]) {
      if (item.orch_name.includes('common')) {
        return "service-common-blue";
      } else {
        return 'service-project-blue';
      }

    } else {
      if (item.deploy_type == 'dc') {
        if (item.orch_name.includes('common')) {
          return 'common-mirror';
        } else {
          return 'project-mirror';
        }
      } else {
        if (item.orch_name.includes('common')) {
          return "ms-common-blue";
        } else {
          return 'ms-project-blue';
        }
      }
    }
  }
  private  changeProgressPercent(percent:string)
  {
    return {"width":percent};
  }
}
