export class KpiChartOptionService {

  private static toChinese(metricType:string):string {
    switch (metricType) {
      case "cpu":
        return "CPU";
      case "memory":
        return "内存";
      case "fs":
        return "存储";
      default:
        return '';
    }
  }

  private static getStartRate(len:number) {
    if (len < 10)
      return 1;
    return 70;
  }

  static getLoadingOption() {
    return {
      text: 'loading',
      color: 'rgba(30,144,255,0.2)',
      textColor: '#000',
      maskColor: 'rgba(255, 255, 255, 0.2)',
      zlevel: 0
    };
  }

  static getOption(data:Array<string>, lengend:Array<string>, metricType:string) {
    return {
      tooltip: {
        trigger: 'axis',
        formatter: '{b}<br/>' + KpiChartOptionService.toChinese(metricType) + '利用率: {c}%'
      },
      grid: {
        left: '1%',
        right: '4%',
        bottom: '5%',
        top: '3%',
        containLabel: true
      },
      dataZoom: [
        {
          type: 'inside',
          start: KpiChartOptionService.getStartRate(lengend.length),
          end: 100
        }
      ],
      xAxis: {
        type: 'category',
        boundaryGap: false,
        data: lengend,
        splitLine: {
          show: true,
          lineStyle: {
            color: ['#F8F8FA', '#F8F8FA']
          }
        },
        axisLine: {
          lineStyle: {
            color: 'rgba(234,234,227)',
          }
        },
        nameTextStyle: {
          fontSize: '12px',
          color: '#666'
        },
        axisLabel: {
          interval: 'auto',
          margin: 10,
          textStyle: {
            color: "#A8A8A8",
            fontSize: 12
          }
        }
      },
      yAxis: {
        type: 'value',
        nameGap: 20,
        splitLine: {
          show: true,
          lineStyle: {
            color: ['#F8F8FA', '#F8F8FA']
          }
        },
        nameTextStyle: {
          fontSize: 12,
          color: '#666'
        },
        axisLine: {
          lineStyle: {
            color: 'rgba(234,234,227)',
            onZero: false
          }
        },
        axisLabel: {
          show: true,
          interval: 'auto',
          formatter: '{value} %',
          textStyle: {
            color: "#A8A8A8",
            fontSize: 12
          }
        },
        min: '0',
        max: '100',
        data: ['20', '40', '60', '80', '100'],
      },
      series: [
        {
          type: 'line',
          smooth: true,
          itemStyle: {
            normal: {
              color: 'rgba(30,144,255,0.2)',
              lineStyle: {color: 'rgba(30,144,255,0.2)'}
            }
          },
          areaStyle: {normal: {color: 'rgba(30,144,255,0.2)'}},
          data: data
        }
      ]
    };
  }

  static getOptionYAxisNotFixed(data:Array<string>, lengend:Array<string>, metricType:string) {
    let unit = '';
    switch (metricType) {
      case "cpu":
        unit = '核数';
        break;
      case "memory":
        unit = 'MB';
        break;
    }
    let option = KpiChartOptionService.getOption(data, lengend, metricType);
    option.tooltip.formatter = '{b}<br/>' + KpiChartOptionService.toChinese(metricType) + '使用: {c}' + unit;
    option.yAxis.axisLabel.formatter = null;
    option.yAxis.min = 'auto';
    option.yAxis.max = 'auto';
    option.yAxis.data = [];
    return option;
  }

  static getNetOption(netRxData:Array<any>, netTxData:Array<any>, lengend:Array<any>) {
    return {
      tooltip: {
        trigger: 'axis'
      },
      grid: {
        left: '3%',
        right: '4%',
        bottom: '6%',
        containLabel: true
      },
      dataZoom: [
        {
          type: 'inside',
          start: KpiChartOptionService.getStartRate(lengend.length),
          end: 100
        }
      ],
      legend: {
        data: ['发送方向流量(bps)', '接收方向流量(bps)']
      },
      calculable: true,
      xAxis: [
        {
          type: 'category',
          boundaryGap: false,
          data: lengend,
          splitLine: {
            show: true,
            lineStyle: {
              color: ['#F8F8FA', '#F8F8FA']
            }
          },
          axisLine: {
            lineStyle: {
              color: 'rgba(234,234,227)',
            }
          },
          nameTextStyle: {
            fontSize: '12px',
            color: '#666'
          },
          axisLabel: {
            interval: 'auto',
            margin: 10,
            textStyle: {
              color: "#A8A8A8",
              fontSize: 12
            }
          }
        }
      ],
      yAxis: [
        {
          type: 'value',
          splitLine: {
            show: true,
            lineStyle: {
              color: ['#F8F8FA', '#F8F8FA']
            }
          },
          axisLine: {
            lineStyle: {
              color: 'rgba(234,234,227)',
            }
          },
          axisLabel: {
            show: true,
            textStyle: {
              color: "#A8A8A8",
              fontSize: 12
            }
          },
        }
      ],
      series: [
        {
          name: '接收方向流量(bps)',
          type: 'line',
          smooth: true,
          itemStyle: {
            normal: {
              color: 'rgba(30,144,255,0.2)',
              lineStyle: {color: 'rgba(30,144,255,0.2)'}
            }
          },
          data: netRxData
        },
        {
          name: '发送方向流量(bps)',
          type: 'line',
          smooth: true,
          itemStyle: {
            normal: {
              color: '#22C36B',
              lineStyle: {color: '#22C36B'}
            }
          },
          data: netTxData
        }
      ]
    };
  }
}
