import {Component, Input} from "@angular/core";
import {KpiChartComponent} from "../kpi.chart.component/kpi.chart.component";
import {KpiRealTimeService} from "../kpi.realtime.service";
import {KpiHistoryService} from "../kpi.history.service";
import {MetricInfo} from "../kpi.metric.info";
import {KpiChartService} from "../kpi.chart.service";

@Component({
  moduleId: module.id,
  selector: 'memory-chart',
  directives:[KpiChartComponent],
  providers: [KpiRealTimeService, KpiHistoryService],
  styleUrls: ['../../app.appkpi.css'],
  templateUrl: 'kpi.memory.chart.html',
})

export class KpiMemoryComponent extends KpiChartService {

  @Input() uuidWithType:string;
  metricInfo:MetricInfo;
  limitValue:number;
  freshTimer:any;

  constructor(public kpiRealTimeService:KpiRealTimeService
    , public KpiHistoryService:KpiHistoryService) {
    super(kpiRealTimeService, KpiHistoryService);
  }

  ngOnInit() {
    let memoryChart = echarts.init(document.getElementById('memory'));
    this.metricInfo = new MetricInfo('memory', this.uuidWithType, memoryChart);
    this.getChartData(0);
  }

  ngOnDestroy() {
    clearInterval(this.freshTimer);
  }

}
