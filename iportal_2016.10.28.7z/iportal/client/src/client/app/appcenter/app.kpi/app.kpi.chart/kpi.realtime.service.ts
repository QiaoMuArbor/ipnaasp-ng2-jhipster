import {Injectable} from "@angular/core";
import {KpiChartOptionService} from "./kpi.option.service";
import {AuthHttp} from "../../../shared/http/index";
import {MetricInfo} from "./kpi.metric.info";

@Injectable()
export class KpiRealTimeService {

  private btnNum:number;
  private chartData:Array<string> = [];
  private chartLegend:Array<string> = [];

  constructor(public http:AuthHttp) {

  }

  freshChart(metricInfo:MetricInfo,isShowRate:boolean, func:Function) {
    let that = this;
    that.initChartLoading(metricInfo);
    if (metricInfo.getLimitValue() != undefined && metricInfo.getLimitValue() > 0) {
      that.getRealTimeData(metricInfo,isShowRate);
    } else {
      that.handleRes(metricInfo.getLimitUrl(), function initLimit(res:any) {
        let metricList = res.metric_list;
        if (metricList == undefined) return;
        let limitValue = res.metric_list[0].value;
        func(limitValue);
        metricInfo.setLimitValue(limitValue);
        that.getRealTimeData(metricInfo,isShowRate);
      });
    }
  }

  private initChartLoading(metricInfo:MetricInfo) {
    let that = this;
    let chart = metricInfo.getMetricChart();
    that.chartData = [];
    that.chartLegend = [];
    // chart.setOption(KpiChartOptionService.getOption([], [], metricInfo.getMetricType()));
    chart.showLoading('default', KpiChartOptionService.getLoadingOption());
  }

  getRealTimeData(metricInfo:MetricInfo,isShowRate:boolean) {
    let that = this;
    let chart = metricInfo.getMetricChart();
    that.handleRes(metricInfo.getRealTimeUrl(), function getCurrentData(res:any) {
      let metricList = res.metric_list;
      if (metricList == undefined) return;
      let metric = metricList[0];
      let metricTime = KpiRealTimeService.getStandardDate(metric.timestamp);
      if (KpiRealTimeService.hasNewMetricData(metricTime, that.chartLegend)) return;
      that.chartLegend.push(metricTime);
      if (KpiRealTimeService.limitIs0orUndefined(metricInfo) || !isShowRate) {
        that.handleDataWhenLimitUndefined(chart, metric, metricInfo.getMetricType());
      } else {
        //*100是因为echart显示百分比时自动除以100
        that.chartData.push((metric.value / metricInfo.getLimitValue() * 100).toFixed(2).toString());
        chart.setOption(KpiChartOptionService.getOption(that.chartData, that.chartLegend, metricInfo.getMetricType()));
      }
      chart.hideLoading();
      that.shiftChartData();
    });
  }

  private static limitIs0orUndefined(metricInfo:MetricInfo) {
    return metricInfo.getLimitValue() == 0 || metricInfo.getLimitValue() == undefined;
  }

  private handleDataWhenLimitUndefined(chart:any, metric:any, metricType:string) {
    let that = this;
    switch (metricType) {
      case "cpu":
        that.chartData.push((parseInt(metric.value) / 1000).toFixed(2).toString());
        break;
      case "memory":
        that.chartData.push((parseInt(metric.value) / 1048576).toFixed(2).toString());
        break;
      default:
        that.chartData.push(metric.value);
        break;
    }
    chart.setOption(KpiChartOptionService.getOptionYAxisNotFixed(that.chartData, that.chartLegend, metricType));
  }


  private static hasNewMetricData(metricTime:string, chartLegend:Array<string>):boolean {
    let length = chartLegend.length;
    if (length < 1) return false;
    let tempTime:string = chartLegend[chartLegend.length - 1];
    return tempTime == undefined || tempTime == metricTime;
  }

  private shiftChartData() {
    let that = this;
    if (that.chartData.length > 100) {
      that.chartData.shift();
      that.chartLegend.shift();
    }
  }

  private static getStandardDate(timestamp:string):string {
    let date = new Date(timestamp);
    let month = date.getMonth() + 1;
    return date.getFullYear() + "/" + month + "/"
      + date.getDate() + " " + date.getHours()
      + ":" + date.getMinutes() + ":"
      + date.getSeconds();
  }

  private handleRes(url:string, func:Function) {
    let urlWithRandomCode:string = url + "?timestamp=" + new Date().getTime();
    this.http.get(urlWithRandomCode)
      .subscribe(res => {
        func(res);
      });
  }

}
