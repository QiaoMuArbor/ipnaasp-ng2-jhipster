import {Component, Input} from "@angular/core";
import {KpiChartComponent} from "../kpi.chart.component/kpi.chart.component";
import {KpiChartOptionService} from "../kpi.option.service";
import {KpiRealTimeService} from "../kpi.realtime.service";
import {KpiHistoryService} from "../kpi.history.service";
import {MetricInfo} from "../kpi.metric.info";
import {KpiChartService} from "../kpi.chart.service";

@Component({
  moduleId: module.id,
  selector: 'cpu-chart',
  directives:[KpiChartComponent],
  providers: [KpiChartOptionService, KpiRealTimeService, KpiHistoryService],
  styleUrls: ['../../app.appkpi.css'],
  templateUrl: 'kpi.cpu.chart.html',
})

export class KpiCpuComponent extends KpiChartService {

  @Input() uuidWithType:string;
  metricInfo:MetricInfo;
  limitValue:number;
  freshTimer:any;

  constructor( public kpiRealTimeService:KpiRealTimeService
    , public KpiHistoryService:KpiHistoryService) {
    super(kpiRealTimeService, KpiHistoryService);
  }

  ngOnInit() {
    let cpuChart = echarts.init(document.getElementById('CPU'));
    this.metricInfo = new MetricInfo('cpu', this.uuidWithType, cpuChart);
    this.getChartData(0);
  }

  ngOnDestroy() {
    clearInterval(this.freshTimer);
  }

}
