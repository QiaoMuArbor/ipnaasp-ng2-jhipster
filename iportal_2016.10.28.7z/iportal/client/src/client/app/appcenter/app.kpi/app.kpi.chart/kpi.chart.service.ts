import {Component} from "@angular/core";
import {KpiRealTimeService} from "./kpi.realtime.service";
import {KpiHistoryService} from "./kpi.history.service";
import {MetricInfo} from "./kpi.metric.info";

@Component({
  moduleId: module.id,
  providers: [KpiRealTimeService, KpiHistoryService],
})

export class KpiChartService {

  metricInfo:MetricInfo;
  limitValue:number = 0;
  rateBtnNum:number = 0;
  freshRate:string = '1分钟';
  freshTimer:any;
  isShowRate:boolean = true;
  changeBtnInfo = "利用率";

  constructor(public kpiRealTimeService:KpiRealTimeService
    , public KpiHistoryService:KpiHistoryService) {

  }

  getChartData(btnNum:number):void {
    this.initBtnClickColor(btnNum);
    clearInterval(this.freshTimer);
    if (btnNum == 0) {
      this.freshRealTimeChart();
    } else {
      this.freshHistoryChart(btnNum);
    }
  }

  initBtnClickColor(btnNum:number):void {
    let metricType = this.metricInfo.getMetricType();
    for (let i = 0; i < 4; i++) {
      let btn = document.getElementById(metricType + "btn" + i);
      if (btnNum == i) {
        btn.style.backgroundColor = '#22C36B';
        btn.style.color = '#FFF';
      } else {
        btn.style.backgroundColor = "#F5FAFA";
        btn.style.color = "#448AFF";
      }
    }
  }

  freshRealTimeChart() {
    let that = this;
    that.rateBtnNum = 0;
    that.kpiRealTimeService.freshChart(that.metricInfo, that.isShowRate
      , function (limitValue:number) {
        that.changeBtnInfo = "利用值";
        switch (that.metricInfo.getMetricType()) {
          case "memory":
          that.limitValue = parseInt((limitValue / 1048576).toFixed(2));
          break;
          case "cpu":
          that.limitValue = (limitValue / 1000);
          break;
        }
      });
    that.freshTimer = setInterval(() => {
      that.kpiRealTimeService.getRealTimeData(that.metricInfo, that.isShowRate);
    }, 15000);
  }

  freshHistoryChart(btnNum:number) {
    let that = this;
    //获取历史数据刷新频率
    clearInterval(that.freshTimer);
    let f = parseInt(that.freshRate.substring(0, this.freshRate.length - 2)) * 60 * 1000;
    that.KpiHistoryService.freshChart(that.metricInfo, that.isShowRate,
      function () {
        that.rateBtnNum = btnNum;
        return btnNum;
      });
    that.freshTimer = setInterval(() => {
      that.KpiHistoryService.freshChart(that.metricInfo, that.isShowRate,
        function () {
          return btnNum;
        });
    }, f);
  }

  changeFreshRate() {
    if (this.rateBtnNum == 0) return;
    this.freshHistoryChart(this.rateBtnNum);
  }

  changeChartStyle() {
    let that = this;
    that.isShowRate = !that.isShowRate;
    if(that.isShowRate && that.limitValue != 0){
      that.changeBtnInfo = "利用值";
    } else {
      that.changeBtnInfo = "利用率";
    }
    that.rateBtnNum == 0 ? that.freshRealTimeChart() : that.freshHistoryChart(that.rateBtnNum);
  }

  ngOnDestroy() {
    clearInterval(this.freshTimer);
  }

}
