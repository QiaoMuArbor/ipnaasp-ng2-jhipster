import {Component} from "@angular/core";
import {Router} from "@angular/router";
import {KpiCpuComponent} from "./app.kpi.chart/kpi.cpu.chart/kpi.cpu.chart";
import {KpiMemoryComponent} from "./app.kpi.chart/kpi.memory.chart/kpi.memory.chart";
import {KpiFsComponent} from "./app.kpi.chart/kpi.fs.chart/kpi.fs.chart";
import {KpiNetComponent} from "./app.kpi.chart/kpi.net.chart/kpi.net.chart";
import {ActiveProjectService} from "../../app.service";

@Component({
  moduleId: module.id,
  selector: 'app-kpi',
  directives: [KpiCpuComponent, KpiMemoryComponent, KpiFsComponent, KpiNetComponent],
  styleUrls: ['app.appkpi.css'],
  templateUrl: 'app.appkpi.html',
})

export class AppkpiComponent {

  private uuidWithType:string;

  constructor(private router:Router,private activeProject:ActiveProjectService) {

  }

  ngOnInit() {
    this.initUuidWithType();
  }

  private initUuidWithType() {
    this.router
    .routerState
    .queryParams
    .subscribe(params => {
      let type = params['type'];
      let podName = params['pod_name'];
      if (type === "pod") {
        if (podName != undefined) {
          this.uuidWithType = this.activeProject.id +"/"+ type + '/' + podName;
        }
      } else if (type == "container"){
        let containerName = params['container_name'];
        if (containerName != undefined) {
          this.uuidWithType = this.activeProject.id + "/container/" 
          + podName + "/"+containerName
        }
      }else {
        if (params['id'] != undefined) {
          this.uuidWithType = this.activeProject.id +"/"+ type + '/' + params['id'];
        }
      }
    });
  }

}
