import {MockCfg} from "../../../mock";
export class MetricInfo {

  private metricType:string;
  private uuidWithType:string;
  private metricChart:any;
  private limitValue:number;

  constructor(metricType:string, uuidWithType:string
    , metricChart:any) {
    this.metricType = metricType;
    this.uuidWithType = uuidWithType;
    this.metricChart = metricChart;

  }

  getMetricChart():any {
    return this.metricChart;
  }

  getMetricType():string {
    return this.metricType;
  }

  getLimitValue():number {
    return this.limitValue;
  }

  setLimitValue(value:number) {
    this.limitValue = value;
  }

  getLimitUrl():string {
    return MockCfg.kpiUrl + this.uuidWithType + "/" + this.metricType + "_limit/";
  }

  getRealTimeUrl() {
    if (this.metricType == 'cpu')
      return MockCfg.kpiUrl + this.uuidWithType + "/" + this.metricType + "_usage_rate/";
    return MockCfg.kpiUrl  + this.uuidWithType + "/" + this.metricType + "_usage/";
  }

  getHistoryUrl() {
    if (this.metricType == 'cpu')
      return MockCfg.kpiUrl  + this.uuidWithType + "/" + this.metricType + "_usage_rate/1";
    return MockCfg.kpiUrl + this.uuidWithType + "/" + this.metricType + "_usage/1";
  }

}
