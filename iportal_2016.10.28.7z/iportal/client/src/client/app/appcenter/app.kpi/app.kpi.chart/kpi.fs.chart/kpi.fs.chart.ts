import {Component, Input} from "@angular/core";
import {KpiChartComponent} from "../kpi.chart.component/kpi.chart.component";
import {KpiRealTimeService} from "../kpi.realtime.service";
import {KpiHistoryService} from "../kpi.history.service";
import {MetricInfo} from "../kpi.metric.info";
import {KpiChartService} from "../kpi.chart.service";

@Component({
  moduleId: module.id,
  selector: 'fs-chart',
  directives:[KpiChartComponent],
  providers: [KpiRealTimeService, KpiHistoryService],
  styleUrls: ['../../app.appkpi.css'],
  templateUrl: 'kpi.fs.chart.html',
})

export class KpiFsComponent extends KpiChartService {

  @Input() uuidWithType:string;
  metricInfo:MetricInfo;
  limitValue:number;
  freshTimer:any;

  constructor(public kpiRealTimeService:KpiRealTimeService
    , public KpiHistoryService:KpiHistoryService) {
    super(kpiRealTimeService, KpiHistoryService);
  }

  ngOnInit() {
    // let fsChart = echarts.init(document.getElementById('fs'));
    // this.metricInfo = new MetricInfo('fs', this.uuidWithType, fsChart);
    // this.getChartData(0);
  }

  ngOnDestroy() {
    clearInterval(this.freshTimer);
  }

}
