import {Injectable} from "@angular/core";
import {KpiChartOptionService} from "./kpi.option.service";
import {AuthHttp} from "../../../shared/http/index";
import {MetricInfo} from "./kpi.metric.info";

@Injectable()
export class KpiHistoryService {

  private btnNum:number;
  private chartData:Array<string> = [];
  private chartLegend:Array<string> = [];

  constructor(public http:AuthHttp) {

  }

  freshChart(metricInfo:MetricInfo, isShowRate:boolean , func:Function) {
    let that = this;
    that.chartData = [];
    that.chartLegend = [];
    let chart = metricInfo.getMetricChart();
    let metricType = metricInfo.getMetricType();
    that.btnNum = func();//传入历史数据范围，根据btnNUM确定显示点数
    // chart.setOption(KpiChartOptionService.getOption([], [], metricType));
    chart.showLoading('default', KpiChartOptionService.getLoadingOption());
    that.handleRes(metricInfo.getHistoryUrl(), function handleHistoryData(res:any) {
      let metricParam = KpiHistoryService.getMetricParam(metricType);
      let historyData:Array<any> = res[metricParam];
      if (KpiHistoryService.limitIs0orUndefined(metricInfo) || !isShowRate) {
        that.handleDataWhenLimitUndefined(historyData, chart, metricType);
      } else {
        that.handleDataWhenLimitDefined(historyData, chart, metricInfo);
      }
      chart.hideLoading();
    })
  }

  private static limitIs0orUndefined(metricInfo:MetricInfo) {
    return metricInfo.getLimitValue() == 0 || metricInfo.getLimitValue() == undefined;
  }

  private handleDataWhenLimitUndefined(historyData:Array<any>, chart:any, metricType:string) {
    let that = this;
    for (let i = 0, len = historyData.length; i < len; i++) {
      let tempData = historyData[i];
      switch (metricType) {
        case "cpu":
          that.chartData.push((parseInt(tempData.value) / 1000).toFixed(2).toString());
          break;
        case "memory":
          that.chartData.push((parseInt(tempData.value) / 1048576).toFixed(2).toString());
          break;
        default:
          that.chartData.push(tempData.value);
          break;
      }
      that.chartLegend.push(KpiHistoryService.getStandardDate(tempData.timestamp));
    }
    chart.setOption(KpiChartOptionService.getOptionYAxisNotFixed(that.chartData, that.chartLegend, metricType));
  }

  private handleDataWhenLimitDefined(historyData:Array<any>, chart:any, metricInfo:MetricInfo) {
    let that = this;
    for (let i = 0, len = historyData.length; i < len; i++) {
      let tempData = historyData[i];
      that.chartData.push((tempData.value / metricInfo.getLimitValue() * 100).toFixed(2).toString());
      that.chartLegend.push(KpiHistoryService.getStandardDate(tempData.timestamp));
    }
    chart.setOption(KpiChartOptionService.getOption(that.chartData, that.chartLegend, metricInfo.getMetricType()));
  }

  private static getMetricParam(metricType:string):string {
    let metricParam = metricType + '_usage';
    if (metricType == 'cpu') {
      metricParam = 'cpu_usage_rate';
    }
    return metricParam;
  }

  private static getStandardDate(timestamp:string):string {
    let date = new Date(timestamp);
    let month = date.getMonth() + 1;
    return date.getFullYear() + "/" + month + "/"
      + date.getDate() + " " + date.getHours()
      + ":" + date.getMinutes() + ":"
      + date.getSeconds();
  }

  private handleRes(url:string, func:Function) {
    let urlWithRandomCode:string = url + "?timestamp=" + new Date().getTime();
    this.http.get(urlWithRandomCode)
      .subscribe(res => {
        func(res);
      });
  }
}
