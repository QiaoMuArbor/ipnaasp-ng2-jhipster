import {Component, Input} from "@angular/core";
import {AuthHttp} from "../../../../shared/http/index";
import {Observable} from 'rxjs/Observable';
import {KpiChartOptionService} from "../kpi.option.service";
import {MockCfg} from "../../../../mock";

@Component({
  moduleId: module.id,
  selector: 'net-chart',
  styleUrls: ['../../app.appkpi.css'],
  templateUrl: 'kpi.net.chart.html',
})

export class KpiNetComponent {

  @Input() uuidWithType:string;
  private netRxData:Array<any> = [];
  private netTxData:Array<any> = [];
  private netLegend:Array<any> = [];
  private netRxRateUrl:string;
  private netTxRateUrl:string;
  private netChart:any;
  private freshTimer:any;

  constructor(private http:AuthHttp) {
  }

  ngOnInit() {
    this.netChart = echarts.init(document.getElementById('net'));
    this.netRxRateUrl = MockCfg.kpiUrl + this.uuidWithType + "/network_rx_rate/";
    this.netTxRateUrl = MockCfg.kpiUrl + this.uuidWithType + "/network_tx_rate/";
    this.showNetChart();
  }

  private showNetChart() {
    //legend对应echart图标x轴的值，data对应echart的series值
    let that = this;
    that.netChart.setOption(KpiChartOptionService.getNetOption([], [], []));
    that.netChart.showLoading('default', KpiChartOptionService.getLoadingOption());
    that.freseChart();
    that.freshTimer = setInterval(() => {
      that.freseChart();
    }, 10000);
  }

  private freseChart() {
    let that = this;
    that.handleRes(that.netRxRateUrl, function updateNetRxData(res:any) {
      that.updateNetData(that.netRxData, that.netLegend, res);
      that.getNetTxRate();
    }, function () {
      that.getNetTxRate();
    });
  }

  private getNetTxRate() {
    let that = this;
    that.handleRes(that.netTxRateUrl, function updateNetTxData(res:any) {
      that.updateNetData(that.netTxData, that.netLegend, res);
      that.setChartOption();
    }, function err() {
      that.setChartOption();
    });
  }

  private setChartOption() {
    let that = this;
    that.netChart.hideLoading();
    let option = KpiChartOptionService.getNetOption(that.netRxData, that.netTxData, that.netLegend);
    that.netChart.setOption(option);
  }

  private updateNetData(netData:Array<any>, netLegend:Array<any>, res:any) {
    let metric_list = res.metric_list;
    if (metric_list == undefined) return;
    let metric = metric_list[0];
    let time = this.getStandardDate(metric.timestamp);
    if (netLegend.length > 0 && time == netLegend[netLegend.length - 1]) return;
    netLegend.push(time);
    netData.push(metric.value);
    if (netData.length >= 100) {
      netLegend.shift();
      netData.shift();
    }
  }

  private handleRes(url:string, func:Function, errFunc:Function) {
    let urlWithRandomCode:string = url + "?timestamp=" + new Date().getTime();
    this.http.get(urlWithRandomCode)
      .subscribe(
        res => {
          func(res);
        },
        () => {
          errFunc();
        }
      );
  }

  private getStandardDate(timestamp:string):string {
    let date = new Date(timestamp);
    let month = date.getMonth() + 1;
    return date.getFullYear() + "/" + month + "/"
      + date.getDate() + " " + date.getHours()
      + ":" + date.getMinutes() + ":"
      + date.getSeconds();
  }

  ngOnDestroy() {
    clearInterval(this.freshTimer);
  }

}
