import {Component} from "@angular/core";

@Component({
  selector: 'kpi-chart',
  moduleId: module.id,
  templateUrl:'kpi.chart.html',
  styleUrls: ['../../app.appkpi.css']
})

export class KpiChartComponent {

}
