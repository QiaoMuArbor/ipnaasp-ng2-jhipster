import {Component, Input} from "@angular/core";
import {ActivatedRoute, Router,ROUTER_DIRECTIVES} from "@angular/router";
import {Http} from "@angular/http";

@Component({
  moduleId: module.id,
  selector: 'app-topo',
  directives:[ROUTER_DIRECTIVES],
  styleUrls: ['app.topo.css'],
  templateUrl: 'app.topo.html'
})

export class AppTopoComponent {
  @Input() serviceDatas:any;
  topoCanvas:any;
  topoStage:any;
  scene:any;
  rootNode:any;
  imgUrls = new Map<string,string>();

  constructor(private http:Http, private route:ActivatedRoute, private router:Router) {

  }

  ngOnInit() {
    this.imgUrls.set('services', 'images/apps/service.png');
    this.imgUrls.set('microservices', 'images/apps/ms.png');
    this.imgUrls.set('pod', 'images/apps/pod.png');
    this.imgUrls.set('container', 'images/apps/container.png');
    this.initTopoScence();
    this.initRootNode();
    this.linkFromService2Container();
  }

  private initTopoScence() {
    this.topoCanvas = document.getElementById('topoCanvas');
    this.topoCanvas.width=500;
    this.topoCanvas.height=400;
    this.topoCanvas.fillStyle="#FF0000";
    this.topoStage = new JTopo.Stage(this.topoCanvas);
    this.scene = new JTopo.Scene();
    this.topoStage.mode = "drag";
    this.topoStage.add(this.scene);
  }


  private initRootNode(){
    let that = this;
    that.rootNode = new JTopo.Node(this.serviceDatas.name);
    that.rootNode.setSize(56, 56);
    that.rootNode.fontColor = "0,0,0";
    that.rootNode.textPosition = "Top_Right";
    if (that.serviceDatas.type == 'service'){
      that.rootNode.setImage(that.imgUrls.get("services"), true);
      that.createRouterLink(that.rootNode,"services");
    }else{
      that.rootNode.setImage(that.imgUrls.get("microservices"), true);
      that.createRouterLink(that.rootNode,"microservices");
    }
    that.rootNode.setLocation(230,20);
    that.rootNode.layout = {type: 'tree', width:200, height: 80}
    that.scene.add(that.rootNode);
  }

  private linkFromService2Container(){
    if (this.serviceDatas.type == 'service'){
      this.scene.add(this.rootNode);
      let ms_list = this.serviceDatas.ms_list;
      let msLength = ms_list.length;
      for(let msIndex=0; msIndex < msLength; msIndex++) {
        let node = this.getTopoNode(ms_list[msIndex].orch_name,"microservices");
        node.layout = {type: 'tree', width:100, height: 80};
        this.scene.add(new JTopo.Link(this.rootNode, node));

        let pod_list = ms_list[msIndex].pod_list;
        this.linkPodNode2ContainerNode(pod_list,node);
      }
    }else {
      let pod_list = this.serviceDatas.pod_list;
      this.linkPodNode2ContainerNode(pod_list,this.rootNode);
    }
    JTopo.layout.layoutNode(this.scene, this.rootNode, true);
  }

  private linkPodNode2ContainerNode(pod_list:any,node:any) {
    if (pod_list == undefined || pod_list.length == 0) return ;
    let podLength = pod_list.length;
    for(let podIndex=0; podIndex < podLength; podIndex++){
      // let podNode = this.getTopoNode(pod_list[podIndex].pod_name,"pod");
      let podNode = this.getTopoNode("pod"+podIndex,"pod");
      podNode.layout = {type: 'tree', width:50, height: 80};
      this.scene.add(new JTopo.Link(node, podNode));

      let container_list =  pod_list[podIndex].container_list.ms_info.containerStatuses;
      this.linkNodes(container_list,podNode);
    }
  }

  private linkNodes(list:Array<any>,node:any) {
    if (list == undefined || list.length == 0) return ;
    let containerLength = list.length;
    for (let conLength=0; conLength < containerLength; conLength++) {
      let containerNode = this.getTopoNode(list[conLength].name,"container");
      this.scene.add(new JTopo.Link(node, containerNode));
    }
  }

  private getTopoNode(name:string, type:string) {
    let that = this;
    let node = new JTopo.Node(name);
    node.setImage(that.imgUrls.get(type), true);
    // node.radius = 6;
    node.setSize(36, 36);
    node.textPosition = "Top_Right";
    node.setLocation(that.scene.width * Math.random(), that.scene.height * Math.random());
    node.fontColor = "0,0,0";
    that.createRouterLink(node,type);
    that.scene.add(node);
    return node;
  }

  private createRouterLink(node:any,type:string) {
    let that = this;
    node.mousedown(function (event) {
      if (event.button == 0) {
        switch (type) {
          case "services":
          that.router.navigate(['/dcdetail']);
          break;
          case "microservices":
          that.router.navigate(['/dcdetail']);
          break;
          case "pod":
          that.router.navigate(['/dcdetail']);
          break;
          case "container":
          that.router.navigate(['/dcdetail']);
          break;
          default:
          that.router.navigate(['/dcdetail']);
          break;
        }

      }
    });
  }

  ngOnDestroy() {
    clearInterval(this.scene);
  }

}
