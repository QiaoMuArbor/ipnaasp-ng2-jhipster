import {Component} from '@angular/core';
import {MockCfg} from '../../mock';
import {Router} from '@angular/router';
import {LocalTimePipe} from "../../shared/pipes/tolocaltime";
import {AuthHttp} from "../../shared/index";
import {ActiveProjectService} from "../../app.service";

@Component({
  moduleId: module.id,
  selector: 'event-service',
  templateUrl: 'app.event.html',
  pipes: [LocalTimePipe],
  styleUrls: [`app.event.css`]
})

export class AppEventComponent {
  eventList:Array<any> = [];
  commonid:string;
  podid:string;
  type:string;
  currentTime:number;
  status:number = 0;
  saveEventList:Array<any> = [];
   eventNum:number = 0;
   appLevel:string;
   eventUrl:string;
  private flagColor:string;

  constructor(private router:Router,private _http:AuthHttp,private activeProject:ActiveProjectService) {
    this.eventUrl = MockCfg.kpiUrl + this.activeProject.id +"/event/";
  }

  ngOnInit() {
    let that = this;
    this.router
      .routerState
      .queryParams
      .subscribe(params => {
        that.commonid = params['id'];
        that.type = params['level'];
        that.podid = params['pod_name']
      });

    if (this.type == "1") {
      this.appLevel = "service_id";
      this.addEventList();
    }
    if (this.type == "2") {
      this.appLevel = "microservice_id";
      this.addEventList();
    }
    if (this.type == "3") {
      this.appLevel = "pod_name";
      this.addEventListPod();
    }
  }

  addEventList() {
    this._http.get(this.eventUrl+this.appLevel+"/"+this.commonid)
      .subscribe( res => {
        this.eventList = res;
        this.saveEventList = this.eventList;
        this.eventNum = this.eventList.length;
        this.getFailEvent();
      });
  }

  addEventListPod() {
    this._http.get(this.eventUrl+this.appLevel+"/"+this.podid)
      .subscribe( res => {
        this.eventList = res;
        this.saveEventList = this.eventList;
        this.eventNum = this.eventList.length;
        this.getFailEvent();
      });
  }

  getFailEvent() {
    for (let list of this.eventList) {
      let reasonKey:string = list.metadata.commonData.reason.toLowerCase();
      if (reasonKey.indexOf("fail") != -1 || reasonKey.indexOf("error") != -1) {
        list.metadata.commonData.uid = "errorMessage";
      }
    }
  }


  searchEvent(searchtext:string){
    this.eventList = _.filter(this.saveEventList,function(eventList){
      return eventList.metadata.commonData.reason.indexOf(searchtext)!=-1||eventList.metadata.detailedData.message.indexOf(searchtext)!=-1;
    });
    this.eventNum = this.eventList.length;
  }


}
