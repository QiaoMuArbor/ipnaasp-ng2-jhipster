import {Component} from '@angular/core';
import {MockCfg} from '../../mock';
import {ROUTER_DIRECTIVES,Router} from '@angular/router';
import {MODAL_DIRECTIVES} from 'ng2-bs3-modal/ng2-bs3-modal';
import {ActiveProjectService} from "../../app.service";
import {AuthHttp} from "../../shared/index";
import {LocalTimePipe} from "../../shared/pipes/tolocaltime";

@Component({
  moduleId: module.id,
  styleUrls: ['app.currentalarm.css'],
  templateUrl: 'app.currentalarm.html',
  pipes:[LocalTimePipe],
  directives: [MODAL_DIRECTIVES, ROUTER_DIRECTIVES]
})

export class AppCurrentAlarmComponent {

  private commonid:string;
  private type:string;
  private appLevel:string;
  private podurl:string;
  private pod_name:string;
  private alarmlist:Array<any> = [];
  private alarmlistHistory:Array<any> = [];

  constructor(private router:Router,private _http:AuthHttp, private activeProject:ActiveProjectService) {
    this.podurl=MockCfg.vnpmUrl + this.activeProject.id+'/pod/';
  }

  ngOnInit() {
    this.router
      .routerState
      .queryParams
      .subscribe(params => {
        this.type = params['level'];
        this.commonid = params['id'];
        this.pod_name = params['pod_name'];
      });

    if (this.type == "3") {
      this.appLevel = "name";
      this.getCurrentPodAlarm();
      this.getHistroyPodAlarm();
    } else {
      if (this.type == "1") {
        this.appLevel = "service_id";

      } else {
        this.appLevel = "microservice_id";
      }
      this.addCurrentAlarmList();
      this.addHistroyAlarmList();
    }
  }

  addCurrentAlarmList() {
    this._http.get(MockCfg.currentalarmUrl+this.activeProject.id+ "/alarm/current/" + this.appLevel + "/" + this.commonid)
      .subscribe( res => {
        this.alarmlist = res;
      });
  }

  getCurrentPodAlarm() {
    this._http.get(MockCfg.currentalarmUrl+ this.activeProject.id+"/alarm/current/" + this.appLevel + "/" + this.pod_name)
      .subscribe( res => {
        this.alarmlist = res;
      });
  }

  addHistroyAlarmList() {
    this._http.get(MockCfg.currentalarmUrl+this.activeProject.id+ "/alarm/history/" + this.appLevel + "/" + this.commonid)
      .subscribe( res => {
        this.alarmlistHistory = res;
      });
  }

  getHistroyPodAlarm() {
    this._http.get(MockCfg.currentalarmUrl+ this.activeProject.id+"/alarm/history/" + this.appLevel + "/" + this.pod_name)
      .subscribe( res => {
        this.alarmlistHistory = res;
      });
  }

/*  setAlarmToHistory(){
    if (this.type == "3"){
      this.getHistroyPodAlarm();
    }
    else{
      this.addHistroyAlarmList();
    }
    (<HTMLInputElement>document.getElementById("historyId")).style.backgroundColor = "#efefef";
    (<HTMLInputElement>document.getElementById("currentId")).style.backgroundColor = "white";
  }

  setAlarmToCurrent(){
    if (this.type == "3") {
      this.getCurrentPodAlarm();
    }
    else{
      this.addCurrentAlarmList();
    }
    (<HTMLInputElement>document.getElementById("historyId")).style.backgroundColor = "white";
    (<HTMLInputElement>document.getElementById("currentId")).style.backgroundColor = "#efefef";
  }*/
}


