import {Component} from '@angular/core';
import {ActivatedRoute, Router, ROUTER_DIRECTIVES} from '@angular/router';
import {MODAL_DIRECTIVES, ModalComponent} from "ng2-bs3-modal/ng2-bs3-modal";
import {ActiveProjectService} from "../../app.service";
import {Http, Response} from "@angular/http";
import {MockCfg} from "../../mock";
import {AuthHttp} from "../../shared/index";
@Component({
  moduleId: module.id,
  selector: 'app-serviceaddress',
  templateUrl: 'app.serviceaddress.html',
  styleUrls:['app.serviceaddress.css'],
  directives: [MODAL_DIRECTIVES,ROUTER_DIRECTIVES]
})

export class AppServiceAddressComponent {
  srv_ins_id:string;
  serviceadds:Array<any>=[];
  private msserviceurl:string;
  private id:string;
  private addressurl:string;

  constructor(private router:Router, private route:ActivatedRoute, private activeProject:ActiveProjectService,
              private _http:AuthHttp) {
    this.msserviceurl=MockCfg.vnpmUrl + this.activeProject.id+MockCfg.msserviceurlsuffix+'/';

  }

  ngOnInit() {
    this.getParams();
    this.initData();
  }

  getParams() {
    this.router.routerState.queryParams.subscribe(params => {
      this.id= params['id'];
    });

  }


  private initData() {
    this.serviceadds=[];
      this.addressurl =this.msserviceurl+this.id;
      this._http.request(this.addressurl).subscribe(res => {
      let service =res;
      let hostIP=window.location.host;
      hostIP =hostIP.substring(0,hostIP.indexOf(':'));
      for (let serviceadd of service.deploy_config.route_list)
        {
          if(serviceadd.protocol=='HTTP' || serviceadd.protocol=='http' ) {
            if(serviceadd.version!=undefined && serviceadd.version!="")
            {
              serviceadd.url ="http://"+hostIP+":80/"+serviceadd.serviceName+"/"+serviceadd.version+"/";
            }else{
              serviceadd.url ="http://"+hostIP+":80/"+serviceadd.serviceName+"/";
            }

          }else{
            serviceadd.url =hostIP+":"+serviceadd.public_port;
          }

          this.serviceadds.push(serviceadd);

        }
      });
    }
}

