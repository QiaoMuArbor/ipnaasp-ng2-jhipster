/**
 * Created by zte on 16-8-4.
 */
import { Component } from '@angular/core';
import { ProjectService } from './project/project.service';
import { Router } from '@angular/router';
import { LocalStorageService, EventBroadcastService } from './shared/index';
import { Http } from '@angular/http';

@Component({
  moduleId: module.id,
  selector: 'login',
  providers: [ProjectService],
  template: `
  <div class="login">
    <img class="login-logo" src="images/login-logo.svg" alt="OpenPalette"/>
    <form class="login-form" #loginForm="ngForm" (ngSubmit)="userLogin()" *ngIf="loginType=='ldap'">
        <div class="item-line">
          <input type="text" [(ngModel)]="user.name" minlength="8" required name="name" #name="ngModel" placeholder="工号的后8位"/>
          <i class="fa fa-check-circle form-ic-success" *ngIf="name.valid"></i>
          <label *ngIf="((loginForm.submitted||name.dirty||!name.untouched)&&!name.valid)" class="form-error">
            <i class="fa fa-times-circle form-ic-error" aria-hidden="true"></i>
            <span *ngIf="name.errors.minlength">工号的后8位</span>
            <span *ngIf="name.errors.required">用户名不能为空</span>
          </label>
        </div> 
        <div class="item-line">
          <input type="password" [(ngModel)]="user.password" required name="password" #password="ngModel" placeholder="人事在线密码"/>
          <i class="fa fa-check-circle form-ic-success" *ngIf="password.valid"></i>
          <label *ngIf="((loginForm.submitted||password.dirty||!password.untouched)&&!password.valid)" class="form-error">
            <i class="fa fa-times-circle form-ic-error" aria-hidden="true"></i>
            <span *ngIf="password.errors.required">密码不能为空</span>
          </label>
        </div>
        <div class="btn-area">
          <button type="submit" class="modal-btn-confirm login-btn" *ngIf="!logining">登&nbsp;&nbsp;&nbsp;录</button>
          <button type="submit" class="modal-btn-confirm login-btn" *ngIf="logining" [disabled]="logining">登&nbsp;&nbsp;&nbsp;录&nbsp;&nbsp;&nbsp;中</button>
        </div>
    </form>
    <form class="login-form" #loginForm="ngForm" (ngSubmit)="userLogin()" *ngIf="loginType!='ldap'">
        <div class="item-line">
          <input type="text" [(ngModel)]="user.name" minlength="3" required name="name" #name="ngModel" placeholder="用户名"/>
          <i class="fa fa-check-circle form-ic-success" *ngIf="name.valid"></i>
          <label *ngIf="((loginForm.submitted||name.dirty||!name.untouched)&&!name.valid)" class="form-error">
            <i class="fa fa-times-circle form-ic-error" aria-hidden="true"></i>
            <span *ngIf="name.errors.minlength">用户名不少于三个字符</span>
            <span *ngIf="name.errors.required">用户名不能为空</span>
          </label>
        </div> 
        <div class="item-line">
          <input type="password" [(ngModel)]="user.password" required name="password" #password="ngModel" placeholder="密码"/>
          <i class="fa fa-check-circle form-ic-success" *ngIf="password.valid"></i>
          <label *ngIf="((loginForm.submitted||password.dirty||!password.untouched)&&!password.valid)" class="form-error">
            <i class="fa fa-times-circle form-ic-error" aria-hidden="true"></i>
            <span *ngIf="password.errors.required">密码不能为空</span>
          </label>
        </div>
        <div class="btn-area">
          <button type="submit" class="modal-btn-confirm login-btn" *ngIf="!logining">登&nbsp;&nbsp;&nbsp;录</button>
          <button type="submit" class="modal-btn-confirm login-btn" *ngIf="logining" [disabled]="logining">登&nbsp;&nbsp;&nbsp;录&nbsp;&nbsp;&nbsp;中</button>
        </div>
    </form>
    <div *ngIf="loginType!='ldap'" class="register">没有帐号？立即<a href="javascript:;" (click)="gotoRegist()">注册</a>成为OpenPalette用户</div>
  </div>
  `,
  styles: [`
  div.login {
      width: 600px;
      margin: 0 auto;
      text-align: center;
      margin-top: 10%;
  }
  img.login-logo{
    width: 264px;
    margin-bottom: 10px;
  }
  .login h1{
    font-size: 48px;
    color: #1898EB;
    margin-bottom: 30px;
  }
  .login-form i.form-ic-success,
  .login-form label.form-error{
    position: absolute;
    margin-left: 10px;
    margin-top: 6px;
  }
  button.login-btn{
  width: 300px;
  height: 32px;
  margin-right: 0;
  font-size: 16px;
  margin-top: 10px;
  }
  div.register{
    margin-top: 10px;
  }
  div.register a{
    font-size: 16px;
  }
`]
})

export class LoginComponent {
  private logining: boolean;
  private loginType: string;
  private user: any = { name: '', password: '' };
  constructor(private eventBroadcastService: EventBroadcastService,
              private http: Http,
              private router: Router,
              private projectservice: ProjectService,
              private localStorageService: LocalStorageService) {
          this.logining = false;
  }

  ngOnInit() {
    this.loginType = 'ldap';
    this.getLoginType();
  }

  gotoRegist = function() {
    this.router.navigate(['/register']);
  }

  getLoginType() {
    let that = this;
    that.http.get('/api/user/v1/indentify')
      .subscribe(res => {
        that.loginType = res.json().indentify;
      }, err => {
        that.loginType = 'local';
      });
  }

  userLogin() {
    let that = this;
    this.logining = true;
    this.http.post('/api/authen/v1/tokens', { 'name': this.user.name, 'password': this.user.password })
      .subscribe(res => {
        res = res.json();
        that.localStorageService.clear('Access-Token');
        that.localStorageService.set('Access-Token', res.access_token);
        that.localStorageService.set('user', res.user, true);
        if (res.user.visitPorjects&&res.user.visitPorjects.length > 0) {
          var visitProject = _.max(res.user.visitPorjects, function(visitProject) {
            return visitProject.visitAt;
          });
          that.router.navigate(['/project', visitProject.projectId]);
        }
        else {
          that.projectservice.getAllMyProjects(res.user.id).subscribe(
            projects => {
              if (projects.length > 0) {
                that.router.navigate(['/my/participated-project']);
              } else {
                that.router.navigate(['/first-login']);
              }
            },() => {
              that.router.navigate(['/first-login']);
            });
        }
      }, err => {
        that.logining = false;
        that.eventBroadcastService.broadcastError(err.json().message);
      });
  }
}
