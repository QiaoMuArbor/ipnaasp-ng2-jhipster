/**
 * Created by zte on 16-8-15.
 */
import { RouterConfig } from '@angular/router';
import { CommonServiceListComponet } from './csm-service-list.component'
import { CommonServiceComponent } from "./csm-service-detail.component";
import {CommonServiceBasicInfoComponent} from "./csm-service-detail-basic-info.component";
import {CommonServiceResourcesComponent} from "./csm-service-detail-resources.component";



export const CmsRoutes: RouterConfig = [
  {
    path: 'market',
    children: [
      {
        path: '',
        redirectTo: 'list',
        pathMatch: 'full'
      },
      {
        path: 'list',
        component: CommonServiceListComponet,
        children: [
          // {
          //   path: 'detail/:service_id',
          //   component: CommonServiceComponent
          // }
        ]
      },
      {
        path: 'detail',
        children: [
          {
            path :  ':service_id',
            component: CommonServiceComponent,
            children: [
              {
                path: '',
                redirectTo: 'basic-info',
                pathMatch: 'full'
              },
              {
                path: 'basic-info',
                component: CommonServiceBasicInfoComponent
              },
              {
                path: 'resources',
                component: CommonServiceResourcesComponent
              }
            ]
          }
        ]
      }
    ]
  }
];



