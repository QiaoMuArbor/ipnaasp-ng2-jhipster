import { Component, ViewChild } from '@angular/core';
import { CmsService, EventBroadcastService } from '../shared/index';
import { ActivatedRoute, Router,ROUTER_DIRECTIVES } from "@angular/router";



import { Observable }     from 'rxjs/Observable';

@Component({
  moduleId:module.id,
  selector: 'csm-service-list',
  providers:[CmsService],
  directives:[ROUTER_DIRECTIVES],
  templateUrl: 'csm-service-list.component.html'
})

export class CommonServiceListComponet {

  public servicelist:Array<any> = [];
  constructor(private cmsService:CmsService){}

  ngOnInit(){
    let that = this;
    that.cmsService.getCommonServiceAndResouceListUx().subscribe(res => {
      //(res,"resource_name");
      that.servicelist.push(res);
    },err => {
      that.servicelist.push(err);
    });
  }

  searchCms(){

  }


}



