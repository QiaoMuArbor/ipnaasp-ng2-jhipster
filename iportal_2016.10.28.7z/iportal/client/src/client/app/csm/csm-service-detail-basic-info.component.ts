import { Component } from '@angular/core';
import { CmsService, EventBroadcastService } from '../shared/index';
import { ActivatedRoute, Router,ROUTER_DIRECTIVES } from "@angular/router";



import { Observable }     from 'rxjs/Observable';

@Component({
  moduleId:module.id,
  selector: 'csm-service-detail-basic-info',
  providers:[CmsService],
  directives:[],
  templateUrl: 'csm-service-detail-basic-info.component.html'
})

export class CommonServiceBasicInfoComponent {

  service_id :string;
  displayname :string;
  description:string;
  provision_vars:{"name":string,"description":string}[] = [];

  constructor(private cmsService:CmsService,private route:ActivatedRoute, private router:Router){

  }

  ngOnInit(){
    let that = this;
    that.service_id  = that.router.routerState.parent(that.route).params.value.service_id;
    that.cmsService.getCommonServiceUx(that.service_id).subscribe(res => {
      that.provision_vars = _.sortBy(res.provision_vars,"name");
      that.displayname = res.displayname;
      that.description = res.description;
    })

  }




}



