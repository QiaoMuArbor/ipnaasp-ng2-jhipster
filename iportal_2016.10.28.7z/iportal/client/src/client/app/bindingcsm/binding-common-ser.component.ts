import { Component, Input, Output, EventEmitter, ViewChild } from '@angular/core';
import { EventBroadcastService, CmsService } from '../shared/index';
import { MODAL_DIRECTIVES, ModalComponent } from 'ng2-bs3-modal/ng2-bs3-modal';
import { ActiveProjectService } from '../app.service';


@Component({
  moduleId: module.id,
  selector: 'binding-common-ser',
  templateUrl: 'binding-common-ser.component.html',
  styleUrls:['binding-common-ser.component.css'],
  directives:[MODAL_DIRECTIVES],
  providers:[CmsService]
})



export class BindingCommonSerComponent {
  @Input() image_or_blueprint:string;
  @Input() binding_services:{ser_id:string,plan_id:string}[];
  @Output() binding_servicesChange = new EventEmitter<Array<any>>();
  @ViewChild('modal') modal: ModalComponent;
  private commonservices:{name:string,uuid:string}[];
  private bindservices:{name:string,uuid:string}[];
  private selectdser:string;
  private selectdspec:string;
  private serspecs:{description:string,id:string}[];
  private resdata:any;
  private url:string;
  constructor(private eventBroadcastService: EventBroadcastService,
              private cmsService:CmsService,
              private activeProjectService:ActiveProjectService) {
    
  }

  ngOnInit() {
    this.url='project/'+this.activeProjectService.id;
    this.commonservices=[];
    this.bindservices=[];
    this.serspecs=[];
    this.selectdser = '';
    this.getCommonServices();
  }

  getCommonServices() {
    this.cmsService.getCommonServices().subscribe(
      res=>{
        this.resdata=res;
        this.transFormData(res);
      },err=>{
        this.eventBroadcastService.broadcastError('获取服务列表失败');
      }
    );
  }

  transFormData(data:any) {
    this.commonservices=_.map(data.services,function(item:any) {
      return {'name':item.displayname,'uuid':item.service_id};
    });
  }

  bingService(){
    let newbindser:{name:string,uuid:string} = _.findWhere(this.commonservices,{'uuid':this.selectdser});
    this.bindservices.push(newbindser);
    this.binding_services.push({'ser_id':newbindser.uuid,'plan_id':this.selectdspec});
    this.binding_servicesChange.emit(this.binding_services);
    this.modal.close();
  }

  getSpecs(id:string){
    this.serspecs=[];
    let ser:any = _.findWhere(this.resdata.services,{'service_id':id});
    if(ser){
      for(let spec of ser.plans){
        this.serspecs.push({'description':spec.plan_description,'id':spec.plan_id});
      }
    }
  }

}
