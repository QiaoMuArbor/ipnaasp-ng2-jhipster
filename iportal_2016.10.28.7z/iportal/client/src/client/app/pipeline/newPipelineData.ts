export class pipeline {
  public tenantid:string = '';
  public pipelineuuid:string = '';
  public pipelinename:string = '';
  public createtime:string = '';
  public lastinstendtime:string = '';
  public isdraft:boolean = false;
  public status:string = '';
  public runninginstnum:string = '';
  public averageruntime:string = '';
}
export class PipelineConfig {
  public tenantid:string = '';
  public pipelinename:string = '';
  public pipelineuuid:string = '';
  public createtime:string = '';
  public isgerrit:boolean = false;
  public isdraft:boolean = false;
  public stagelist:StageInstance[]=[];
}
export class StageInstance {
  public stageuuid:string = '';
  public stagename:string = '';
  public stagetype:string = '';
  public tasklist:Task[]=[];
}
export class Task {
  public taskuuid:string = '';
  public taskname:string = '';
  public buildconfig: BuildConfig = new BuildConfig();
  public testconfig:Testconfig = new Testconfig();
  public releaseconfig:{releaselist:ReleaseInfo[],swr:{swraddr:string}[],ftpserver:{ip:string,port:string,uploaddir:string}[]}
         ={'releaselist':[],'swr':[],'ftpserver':[]};
  public deployconfig:DeployConfig = new DeployConfig();
}
export class BuildConfig{
  public buildlist:SingeCodebuild[]=[];
}
export class SingeCodebuild{
  public builduuid:string = '';
  public buildimage:{tenantid:string,name:string,version:string} = {'tenantid':'','name':'','version':''};
  public description:string='';
  public frameworkcfg:{frameworkuuid:string,tenantid:string}={'frameworkuuid':'','tenantid':''};
  public gitcfg:{giturl:string,branch:string,clonedir:string,monitorchange:boolean,triggersubdir:string}[]=[{'giturl':'','branch':'','clonedir':'','monitorchange':true,'triggersubdir':''}];
  public buildscript:string = '';
  public buildimagetype:string = '';
  public installfilesdir:string = '';
  public installscript:string = '';
  public runscript:string = '';
  public dockerfiledir:string = '';
  public imagedescfile:string ='';
  public staticcheck:{isused:boolean,script:string,resultfile:string} = {'isused':false,'script':'','resultfile':''};
  public cyclomaticcomplexity:{isused:boolean,script:string,resultfile:string} = {'isused':false,'script':'','resultfile':''};
  public unittest:{isused:boolean,script:string,coveragestaticfile:string,testcasestaticfile:string} = {'isused':false,'script':'','coveragestaticfile':'','testcasestaticfile':''};
  public istestdriver:boolean = false;
}

export class Testconfig {
  public needtest:boolean = false;
  public blueprintlist:Blueprint[] = [];
  public testdriver:{blueprintuuid:string,build:{stageuuid:string,taskuuid:string,builduuid:string}}
         ={'blueprintuuid':'','build':{'stageuuid':'','taskuuid':'','builduuid':''}};
  public testcasestatic:{isused:boolean,script:string,resultfile:string}={'isused':false,'script':'','resultfile':''};
  public coveragestatic:{isused:boolean,script:string,resultfile:string}={'isused':false,'script':'','resultfile':''};
}

export class Blueprint {
  public blueprintuuid:string = '';
  public sourcetype:string = 'blueprintcenter';
  public blueprint:{tenantid:string,name:string,version:string,tag:string}={'tenantid':'','name':'','version':'','tag':''};
  public blueprintgiturl:{giturl:string,filename:string}={'giturl':'','filename':''};
  public blueprintnewname:string = '';
  public imagessource:{image:{tenantid:string,name:string,version:string},relativebuild:{stageuuid:string,taskuuid:string,builduuid:string}}[]=[];
  public instparalist:{serviceinfo:{name:string,value:string}[],param_list:{name:string,value:string}[],eps_policy:{name:string,value:string}[]}=
         {'serviceinfo':[],'param_list':[],'eps_policy':[]};
}

export class Imagesource {
  public image:{tenantid:string,name:string,version:string}={'tenantid':'','name':'','version':''};
  public relativebuild:{stageuuid:string,taskuuid:string,builduuid:string}={'stageuuid':'','taskuuid':'','builduuid':''};
}

export class ReleaseInfo {
  public releaseuuid:string = '';
  public type:string = '';
  public stageuuid:string = '';
  public taskuuid:string = '';
  public objectuuid:string = '';
  public version:string = '';
}
export class ReleaseConfig {
  public releaselist:{'releaseuuid':string,'type':string,'stageuuid':string,'taskuuid':string,'objectuuid':string,'version':string}[]=[];
  public swr:{'swraddr':string}[]=[];
  public ftpserver:{'ip':string,'port':string,'uploaddir':string}[]=[];
}

export class InstparaList{
     public  serviceinfo:{name:string,value:string}[];
     public  param_list:{name:string,value:string}[];
     public  eps_policy:{name:string,value:string}[];
   }
export class DeployConfig {
      public blueprintlist:{ stageuuid:string,taskuuid:string,blueprintuuid:string,instparalist:InstparaList}[]

   }
  