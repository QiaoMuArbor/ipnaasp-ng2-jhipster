import { Component, Input, Output, EventEmitter, SimpleChange, ViewChild } from '@angular/core';
import { ROUTER_DIRECTIVES, Router, ActivatedRoute } from '@angular/router';
import {StageInstance, ReleaseConfig ,Task} from '../newPipelineData';
import { BluePrintService } from '../../blueprint/blueprint.service';
import { MODAL_DIRECTIVES, ModalComponent } from 'ng2-bs3-modal/ng2-bs3-modal';
import { EventBroadcastService,ModalDeleteComponent} from '../../shared/index';
import { PipelineService } from '../pipeline.service';
import { ActiveProjectService } from '../../app.service';
import { UUID } from '../../shared/index';

@Component({
  moduleId: module.id,
  selector: 'releaseconfig',
  templateUrl: 'releaseconfig.component.html',
  styleUrls:['releaseconfig.component.css'],
  directives: [ROUTER_DIRECTIVES,MODAL_DIRECTIVES,ModalDeleteComponent],
  providers:[BluePrintService]
})

export class ReleaseConfigComponent {
  @Input() stagelist:StageInstance[];
  
  @Input()  task:Task; 
  @Output() taskChange = new EventEmitter<Task>();

  // @Input() releaseconfig:ReleaseConfig;
  // @Output() releaseconfigChange = new EventEmitter<ReleaseConfig>();

  @ViewChild('modal') modal: ModalComponent;

  private codeBuildList:{stageuuid:string,stagename:string,taskuuid:string,taskname:string,codebuilduuid:string,
                     codebuildname:string,version:string,isselect:boolean}[]=[];
  private bluePrintList:{stageuuid:string,stagename:string,taskuuid:string,taskname:string,blueprintuuid:string,
                     blueprintname:string,version:string,isselect:boolean}[]=[];

  private selectCodebuildList:{id:string,version:string}[] =[];
  private selectBlueprintList:{id:string,version:string}[] =[];

  private releaseList:{name:string,stageuuid:string,taskuuid:string,objectuuid:string,
                       version:string,type:string,releaseuuid:string}[]=[];
  constructor(private bluePrintService:BluePrintService,
              private eventBroadcastService:EventBroadcastService,
              private pipelineService:PipelineService,
              private activeProjectService:ActiveProjectService) {

  }

  ngOnInit() {

    this.getBulidAndTestbludprint();
    this.initReleaseList();
  }
  
  initReleaseList(){
     let that =this;
    if(this.task.releaseconfig.releaselist.length>0){
       _.map(this.task.releaseconfig.releaselist,function(release:any){
           if(release.type=='image'){
               _.map(that.codeBuildList,function(item:any){
                  if( item.stageuuid == release.stageuuid
                      &&item.taskuuid == release.taskuuid
                      &&item.codebuilduuid == release.objectuuid){
                    that.releaseList.push({'name':item.codebuildname,'stageuuid':release.stageuuid,'taskuuid':release.taskuuid,
                  'objectuuid':release.objectuuid,'version':release.version,'type':release.type,'releaseuuid':release.releaseuuid});
                  }
               })
           }else{
             _.map(that.bluePrintList,function(item:any){
                  if( item.stageuuid == release.stageuuid
                      &&item.taskuuid == release.taskuuid
                      &&item.blueprintuuid == release.objectuuid){
                    that.releaseList.push({'name':item.blueprintname,'stageuuid':release.stageuuid,'taskuuid':release.taskuuid,
                  'objectuuid':release.objectuuid,'version':release.version,'type':release.type,'releaseuuid':release.releaseuuid});
                  }
               })
           }
       })
    }
  }
  getBulidAndTestbludprint() {
    for(let stage of this.stagelist) {
      if(stage.stagetype==='MergeCI'){

        for(let task of stage.tasklist) {

          for(let blueprint of task.testconfig.blueprintlist) {
            this.bluePrintList.push({'stageuuid':stage.stageuuid,'stagename':stage.stagename,
                                     'taskuuid':task.taskuuid, 'taskname':task.taskname,
                                     'blueprintuuid':blueprint.blueprintuuid,  'blueprintname':blueprint.blueprintnewname,
                                     'version':'1.0','isselect':false});
          }
          for(let codebuild of task.buildconfig.buildlist) {
             this.codeBuildList.push({'stageuuid':stage.stageuuid,'stagename':stage.stagename,
                                      'taskuuid':task.taskuuid,'taskname':task.taskname,
                                      'codebuilduuid':codebuild.builduuid,'codebuildname':codebuild.buildimage.name,
                                      'version':'1.0','isselect':false});
          }

        }
      }
    }
  }
  initSelect() {
    this.bluePrintList = _.map(this.bluePrintList,function(item:any){
      item.isselect =false;
      return item;
    })
    this.codeBuildList = _.map(this.codeBuildList,function(item:any){
      item.isselect =false;
      return item;
    })
  }
  selectblueprint(id:string,isselect:boolean,version:string) {

    if(isselect) {
      this.selectBlueprintList = _.filter(this.selectBlueprintList,function(item:any){
        return item.id != id;
      })
    }else{
      this.selectBlueprintList.push({'id':id,'version':version});
    }
  }

  selectcodebulid(id:string,isselect:boolean,version:string) {
    if(isselect) {
      this.selectCodebuildList = _.filter(this.selectCodebuildList,function(item:any){
        return item.id != id;
      })
    }else{
      this.selectCodebuildList.push({'id':id,'version':version});
    }
  }
  delRelease(item:any){
   
    this.releaseList = _.without(this.releaseList,item);
    this.task.releaseconfig.releaselist = _.reject(  this.task.releaseconfig.releaselist,function(release:any){
         return release.releaseuuid ==item.releaseuuid;
       })             
    //this.task.releaseconfig.releaselist = _.without(this.task.releaseconfig.releaselist,item);
    this.taskChange.emit(this.task);
  }
  submit() {
    for(let build of this.selectCodebuildList) {
      let item = _.findWhere(this.codeBuildList,{'codebuilduuid':build.id});
      let cb ={'stageuuid':item.stageuuid,'taskuuid':item.taskuuid,
                  'objectuuid':item.codebuilduuid,'version':build.version,
                  'type':'image','releaseuuid':UUID.UUID()};
      let ids:string[]=[];
      for(let re of this.task.releaseconfig.releaselist) {
        if(re.type==='image') {
          ids.push(re.objectuuid);
        }
      }
      if(_.indexOf(ids, build.id)===-1) {
        this.releaseList.push({'name':item.codebuildname,'stageuuid':item.stageuuid,'taskuuid':item.taskuuid,
                  'objectuuid':item.codebuilduuid,'version':build.version,'type':'image','releaseuuid':UUID.UUID()});
        //this.releasenames.push(item.codebuildname);
        this.task.releaseconfig.releaselist.push(cb);
      }
    }
    for(let blue of this.selectBlueprintList) {
      let item = _.findWhere(this.bluePrintList,{'blueprintuuid':blue.id});
      let bl ={'stageuuid':item.stageuuid,'taskuuid':item.taskuuid,
                  'objectuuid':item.blueprintuuid,'version':blue.version,
                  'type':'blueprint','releaseuuid':UUID.UUID()};
      let ids:string[]=[];
      for(let re of this.task.releaseconfig.releaselist) {
        if(re.type==='blueprint') {
          ids.push(re.objectuuid);
        }
      }
      if(_.indexOf(ids, blue.id)===-1) {
          this.releaseList.push({'name':item.blueprintname,'stageuuid':item.stageuuid,'taskuuid':item.taskuuid,
                  'objectuuid':item.blueprintuuid,'version':blue.version,'type':'blueprint','releaseuuid':UUID.UUID()});
       // this.releasenames.push(item.blueprintname);
        this.task.releaseconfig.releaselist.push(bl);
      }
    }
    //this.releaseconfigChange.emit(this.releaseconfig);
     this.taskChange.emit(this.task);

    this.selectCodebuildList=[];
    this.selectBlueprintList=[];
    this.modal.close();
    this.initSelect();
  }

  
}
