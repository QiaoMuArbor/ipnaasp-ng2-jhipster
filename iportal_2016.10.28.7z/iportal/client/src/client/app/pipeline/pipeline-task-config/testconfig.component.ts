import { Component, Input, Output, EventEmitter, SimpleChange, ViewChild } from '@angular/core';
import { ROUTER_DIRECTIVES, Router, ActivatedRoute } from '@angular/router';
import { Testconfig, Blueprint, StageInstance, Imagesource ,Task} from '../newPipelineData';
import { BluePrintService } from '../../blueprint/blueprint.service';
import { MODAL_DIRECTIVES, ModalComponent } from 'ng2-bs3-modal/ng2-bs3-modal';
import { EventBroadcastService ,ModalDeleteComponent} from '../../shared/index';
import { PipelineService } from '../pipeline.service';
import { ActiveProjectService } from '../../app.service';
import { UUID } from '../../shared/index';

@Component({
  moduleId: module.id,
  selector: 'testconfig',
  templateUrl: 'testconfig.component.html',
  styleUrls:['testconfig.component.css'],
  directives: [ROUTER_DIRECTIVES,MODAL_DIRECTIVES,ModalDeleteComponent],
  providers:[BluePrintService]
})

export class TestConfigComponent {


  @Input()  StageName:string;
  @Input()  StageType:string;
  @Input()  StageUuid:string;

  @Input() stagelist:StageInstance[];

  @Input()  task:Task; 
  @Output() taskChange = new EventEmitter<Task>();
  // @Input() testconfig:Testconfig;
  // @Output() testconfigChange = new EventEmitter<Testconfig>();

  @ViewChild('modal') modal: ModalComponent;
  @ViewChild('relatemodal') relatemodal: ModalComponent;


  public blueprintList:any[] =[];
  public relateCodebuild:any[] =[];

  public selectBlueprint:{reponame:string,name:string,tag:string,version:string,id:string}
            = {'reponame':'','name':'','tag':'','version':'','id':''};
  public selectBpRleateImages:{show:boolean,content:{name:string,image:string,stagename:string,taskname:string,buildname:string}[]}
           ={'show':false,'content':[]};

  public showBlueprint:boolean=false;
  public testBlueprint:Blueprint;
  public needtest:boolean =false;
  
  public selectId:string='';

  public selectBlueprintIndex:number;
  public showTestBlueprintImageSource:any[] =[];
  public allSelectRelateCodebuild:any[] =[];
  public relateImageSourceIndex:number;
  
  public selectedimage:{name:string,image:string,stagename:string,buildname:string};
  public viewBlueprintList:{name:string,reponame:string,id:string,blueprintuuid:string}[] = [];

  public relativebuild:{stageuuid:string,taskuuid:string,builduuid:string} 
          ={'stageuuid':'','taskuuid':'','builduuid':''};
  public relativeStageList:any[]=[];
  public relativeTaskList:any[];
  public relativeBuildList:any[];


  public relativeBlueprintUuid:string ='';
  public driverimagessource:any[] =[];
  public testdriver:{blueprintuuid:string,build:{stageuuid:string,taskuuid:string,builduuid:string}}
                      ={'blueprintuuid':'','build':{'stageuuid':'','taskuuid':'','builduuid':''}};

  public blueprintname:string='';

  public testDriverBlueprint:any;
  public testDriverBlueprintUuid:string;
  public testDriverBlueprintImagesource:any;
  public testBlueprintImagesourceIndex:number;


  public remberid:string ='';
  public driverid:string ='';
  public driverbuilduuid:string ='';

  public newTestBlueprintWay:string='fromSwr';

  public currentTaskBuildConfigLength:number =0;

  public temptasklist:Array<any> = [];
  constructor(private bluePrintService:BluePrintService,
              private eventBroadcastService:EventBroadcastService,
              private pipelineService:PipelineService,
              private activeProjectService:ActiveProjectService) {

  }

  ngOnInit() {

    this.getBlueprintList();
    this.getRelateCodebuild();
  }
  
  getRelateCodebuild() {
    
    let that =this;
    let findIt=false;
    let IfCurrentTaskBuildConfig:boolean = false;
    let ciStageList:any;
    
    this.temptasklist  =[];

    this.relateCodebuild =[];
    this.allSelectRelateCodebuild =[];
    if(this.StageType=='VerifyCI'){
     ciStageList = _.filter(this.stagelist,function(item:any){
         return item.stagetype == 'VerifyCI'   
       });
    }else if(this.StageType=='MergeCI'){
      ciStageList = _.filter(this.stagelist,function(item:any){
         return item.stagetype == 'MergeCI'   
       });
    }


         //save this hierarchy for further use ;
   this.relateCodebuild = _.map(ciStageList,function(stage:any){
  
     if( (stage.stageuuid == that.StageUuid) &&stage.tasklist.length==0  ){

       return {'stagename':stage.stagename, 'stagetype':stage.stagetype, 
              'stageuuid': stage.stageuuid,'tasklist':[
                   { 'taskuuid':that.task.taskuuid,'taskname':that.task.taskname,
                           'buildlist':_.map(that.task.buildconfig.buildlist,function(codebuild:any){

                     that.allSelectRelateCodebuild.push( {'stagename':stage.stagename, 'stagetype':stage.stagetype, 
                    'stageuuid': stage.stageuuid,'taskuuid':that.task.taskuuid,'taskname':that.task.taskname,
                     'builduuid':codebuild.builduuid,'imagename':codebuild.buildimage.name,
                     'select': false });

                     return {'builduuid':codebuild.builduuid,'imagename':codebuild.buildimage.name};
                    })} 

              ] 
             }

     }else if( (stage.stageuuid == that.StageUuid) && stage.tasklist.length>0 ){    

      


       that.temptasklist.push(
                   { 'taskuuid':that.task.taskuuid,'taskname':that.task.taskname,
                           'buildlist':_.map(that.task.buildconfig.buildlist,function(codebuild:any){

                     that.allSelectRelateCodebuild.push( {'stagename':stage.stagename, 'stagetype':stage.stagetype, 
                    'stageuuid': stage.stageuuid,'taskuuid':that.task.taskuuid,'taskname':that.task.taskname,
                     'builduuid':codebuild.builduuid,'imagename':codebuild.buildimage.name,
                     'select': false });

                     return {'builduuid':codebuild.builduuid,'imagename':codebuild.buildimage.name};
                    })} );

       _.map(stage.tasklist,function(task:any){
      
             that.temptasklist.push( { 'taskuuid':task.taskuuid,'taskname':task.taskname,
                           'buildlist':_.map(task.buildconfig.buildlist,function(codebuild:any){

                     that.allSelectRelateCodebuild.push( {'stagename':stage.stagename, 'stagetype':stage.stagetype, 
                    'stageuuid': stage.stageuuid,'taskuuid':task.taskuuid,'taskname':task.taskname,
                     'builduuid':codebuild.builduuid,'imagename':codebuild.buildimage.name,
                     'select': false });
                           return {'builduuid':codebuild.builduuid,'imagename':codebuild.buildimage.name};
                       })} );                      
                 })
       // console.log(that.temptasklist);

           return {'stagename':stage.stagename, 'stagetype':stage.stagetype, 
              'stageuuid': stage.stageuuid,'tasklist': that.temptasklist}
            
  
     }else{

       return {'stagename':stage.stagename, 'stagetype':stage.stagetype, 
              'stageuuid': stage.stageuuid,'tasklist': _.map(stage.tasklist,function(task:any){
      
                   return { 'taskuuid':task.taskuuid,'taskname':task.taskname,
                           'buildlist':_.map(task.buildconfig.buildlist,function(codebuild:any){
                     that.allSelectRelateCodebuild.push( {'stagename':stage.stagename, 'stagetype':stage.stagetype, 
                    'stageuuid': stage.stageuuid,'taskuuid':task.taskuuid,'taskname':task.taskname,
                     'builduuid':codebuild.builduuid,'imagename':codebuild.buildimage.name,
                     'select': false });
                           return {'builduuid':codebuild.builduuid,'imagename':codebuild.buildimage.name};
                      })}                         
      })}

   }


         
   })
 
 console.log(this.relateCodebuild);
  }

  getBlueprintList() {
    let that=this;
    this.bluePrintService.getAllList().subscribe(
      list=>{
          _.map(list,function(blueprint:any){
             if(blueprint.versions.length > 0){
              _.map(blueprint.versions,function(item:any){
                  that.blueprintList.push({'reponame':blueprint.reponame,'name':blueprint.name,'tag':blueprint.tag,
                         'version':item.version,'id':item.id});
                  return;
               })
              }
              return;
          })
        this.selectId= this.blueprintList[0].id;
      },err=>{
        this.blueprintList = [];
      }
    )
  }


  addblueprint() {
    // if(!sign) {
    //   this.eventBroadcastService.broadcastError('请输入蓝图名称');
    //   return;
    // }
    this.testBlueprint = new Blueprint();
    let that = this;

    this.testBlueprint.blueprintuuid = UUID.UUID();
    // add-buleprint

    let selectBlueprint:any  = _.filter(that.blueprintList,function(item:any){

         return  item.id == that.selectId;
     })

    this.testBlueprint.blueprint.name = selectBlueprint[0].name;
    this.testBlueprint.blueprint.tenantid = selectBlueprint[0].reponame;
    this.testBlueprint.blueprint.tag = selectBlueprint[0].tag;
    this.testBlueprint.blueprint.version = selectBlueprint[0].version;


    //get-image-throught-select-blueprint
    // this.getImagesbyId(selectBlueprint[0].reponame,selectBlueprint[0].id);

     this.bluePrintService.getImagesById(selectBlueprint[0].reponame,selectBlueprint[0].id).subscribe(
       containers=>{
         this.selectBpRleateImages.content = _.map(containers,function(item:any){
        let newimage:{name:string,image:string,stagename:string,taskname:string,buildname:string}={
          'name':item.name,'image':item.image,'stagename':'','taskname':'','buildname':''
        }
        return newimage;
      })||[];

         if(this.selectBpRleateImages.content.length > 0){
       this.testBlueprint.imagessource = _.map(that.selectBpRleateImages.content,function(item:any){
          let sourceimage:Imagesource = new Imagesource();
           sourceimage.image.name= item.image.split('/')[2].split(':')[0];;
           sourceimage.image.version= item.image.split(':')[1];;
           sourceimage.image.tenantid= item.image.split('/')[1];
          return sourceimage;
        });
      }

    },err=>{
      this.selectBpRleateImages.content=[];
    });

      
      this.task.testconfig.blueprintlist.push(this.testBlueprint);
      this.task.testconfig.needtest = this.needtest;
      this.taskChange.emit(this.task);

       // this.testconfig.blueprintlist.push(this.testBlueprint);
       // this.testconfig.needtest = this.needtest;  //signle option is confilt with add-testbuildprint
       // this.testconfigChange.emit(this.testconfig);
    this.modal.close();
  }

delTestBlueprint(item:any){

this.task.testconfig.blueprintlist = _.without(this.task.testconfig.blueprintlist,item);
 this.taskChange.emit(this.task);
    // this.testconfig.blueprintlist= _.without(this.testconfig.blueprintlist,item);
    // this.testconfigChange.emit( this.testconfig);
}

isshow(index:number) {
    
  let that= this;

  this.getRelateCodebuild();

  this.selectBlueprintIndex =index;
  this.showTestBlueprintImageSource =[];
    //add show cuurent testblueprint-relativebuild-{stageuuid -taskuuid -builduuid }
 if(this.task.testconfig.blueprintlist[index].imagessource.length > 0){
   _.map(this.task.testconfig.blueprintlist[index].imagessource,function(item){

         if(item.relativebuild.stageuuid&&item.relativebuild.taskuuid&&item.relativebuild.builduuid){

              let relatecodebuild:any =  _.filter(that.allSelectRelateCodebuild,function(codebuild:any){
                    return   item.relativebuild.stageuuid == codebuild.stageuuid &&
                             item.relativebuild.taskuuid  == codebuild.taskuuid &&
                             item.relativebuild.builduuid == codebuild.builduuid ;              
                })
          that.showTestBlueprintImageSource.push({'name':item.image.name,'stagename':relatecodebuild[0].stagename,
            'stageuuid':relatecodebuild[0].stageuuid, 'taskname':relatecodebuild[0].taskname, 
            'taskuuid':relatecodebuild[0].taskuuid, 'imagename':relatecodebuild[0].imagename,
            'builduuid':relatecodebuild[0].builduuid,'relate':true});
            
         }else{
             that.showTestBlueprintImageSource.push({'name':item.image.name,'stagename':'',
            'stageuuid':'', 'taskname':'', 'taskuuid':'', 'imagename':'','builduuid':'','relate':false});
         }
        
      })
    this.showBlueprint =true;


 }
     
}
saveTestconfigBuildprint(){

 this.taskChange.emit(this.task);
 // this.testconfigChange.emit(this.testconfig);
 this.showBlueprint= false;
}
cancleTestconfigBuildprint(){
  this.showTestBlueprintImageSource =[];
  this.showBlueprint =false;
}
/* first relate second get relatename*/

  relatemodalopen() {
    this.relatemodal.open();
    // this.getTaskIdList(this.relativebuild.stageuuid);
    // this.getBuildIdList(this.relativebuild.builduuid);
  }
  getTaskIdList(id:string){

    this.relativeTaskList=[];
    if(id){
      let relativeStage = _.findWhere(this.relateCodebuild,{'stageuuid':id});
      if(relativeStage.tasklist!==undefined){
        this.relativeTaskList = relativeStage.tasklist;
      }else{
         this.relativeTaskList =[];
      }
      
    }
    
  }
  getBuildIdList(id:string){

    this.relativeBuildList=[];

    if(id){
      let relativetask = _.findWhere(this.relativeTaskList,{'taskuuid':id});
        if(relativetask.buildlist!==undefined){
        this.relativeBuildList = relativetask.buildlist;
      }else{
         this.relativeBuildList =[];
      }
      
    }
    
  }

  //{relate:boolean,}
  chooseimage(index:number) {
    this.relateImageSourceIndex= index;
    this.relatemodal.open();
  }

  relatedimage() {

   let that=this; 
  let relatecodebuild:any =  _.filter(this.allSelectRelateCodebuild,function(item){
        return   item.stageuuid ==that.relativebuild.stageuuid &&
           item.taskuuid  ==that.relativebuild.taskuuid &&
           item.builduuid ==that.relativebuild.builduuid ;
      
    })

    /* write data into showTestBlueprintImageSource*/
    that.showTestBlueprintImageSource[that.relateImageSourceIndex].stagename
         =relatecodebuild.stagename;
    this.showTestBlueprintImageSource[that.relateImageSourceIndex].stageuuid
         =relatecodebuild.stageuuid;
    this.showTestBlueprintImageSource[that.relateImageSourceIndex].taskname
         =relatecodebuild.taskname;
    this.showTestBlueprintImageSource[that.relateImageSourceIndex].taskuuid
         =relatecodebuild.taskuuid;
    this.showTestBlueprintImageSource[that.relateImageSourceIndex].imagename
         =relatecodebuild.imagename;
    this.showTestBlueprintImageSource[that.relateImageSourceIndex].builduuid
         =relatecodebuild.builduuid;
   this.showTestBlueprintImageSource[that.relateImageSourceIndex].relate = true;
   // write selected ImageSource relativbuild 

    _.map(this.task.testconfig.blueprintlist[that.selectBlueprintIndex].imagessource,function(item){
       if(that.showTestBlueprintImageSource[that.relateImageSourceIndex].name == 
          item.image.name){
         item.relativebuild.stageuuid = that.relativebuild.stageuuid ;
         item.relativebuild.taskuuid =  that.relativebuild.taskuuid;
         item.relativebuild.builduuid = that.relativebuild.builduuid;

       }
    })

     this.taskChange.emit(this.task);

  this.relativebuild={'stageuuid':'','taskuuid':'','builduuid':''};
    // this.testconfigChange.emit(this.testconfig);
    this.relatemodal.close();
  }




  getTestBlueprintImagesSource() {
     let that=this;
     if(this.testDriverBlueprintUuid){
        // let blue = ( this.showTestBlueprintImageSource,{'blueprintuuid':id});
      this.task.testconfig.testdriver.blueprintuuid = this.testDriverBlueprintUuid;
      let  blueprint:any  =  _.filter(this.task.testconfig.blueprintlist,function(item:any){
         return item.blueprintuuid == that.testDriverBlueprintUuid;
      })
      this.testDriverBlueprintImagesource = blueprint[0].imagessource;
      // this.testconfigChange.emit(this.testconfig);
         this.taskChange.emit(this.task);
     }
    }

  settestdriverbuild() {
    console.log(this.testBlueprintImagesourceIndex);
    if(this.testBlueprintImagesourceIndex){
        this.task.testconfig.testdriver.build.stageuuid = this.testDriverBlueprintImagesource[this.testBlueprintImagesourceIndex].relativebuild.stageuuid;
        this.task.testconfig.testdriver.build.taskuuid = this.testDriverBlueprintImagesource[this.testBlueprintImagesourceIndex].relativebuild.taskuuid;
        this.task.testconfig.testdriver.build.builduuid = this.testDriverBlueprintImagesource[this.testBlueprintImagesourceIndex].relativebuild.builduuid;
       this.taskChange.emit(this.task);
       // this.testconfigChange.emit(this.testconfig);
    }
  }

selectTestBlueprintWays(type:string){
    this.newTestBlueprintWay=type;
}

}
