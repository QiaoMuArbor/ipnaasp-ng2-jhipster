import { Component, Input, Output, EventEmitter, SimpleChange, ViewChild } from '@angular/core';
import { EventBroadcastService, ISOLocalPipe ,ModalDeleteComponent} from '../../shared/index';
import { MODAL_DIRECTIVES, ModalComponent } from 'ng2-bs3-modal/ng2-bs3-modal';
import { ROUTER_DIRECTIVES,Router,ActivatedRoute } from '@angular/router';
import { ActiveProjectService } from '../../app.service';
import { Headers, Http, Response} from '@angular/http';
import { framework,FrameworkComponent } from '../../src2img/framework/index';
import { BluePrintService } from '../../blueprint/blueprint.service';
import { BuildConfig,SingeCodebuild,StageInstance,Task} from '../newPipelineData';
import { UUID } from '../../shared/index';
import { CodeBuild} from './codeBuild.component';

@Component({
  moduleId:module.id,
  selector: 'buildconfig',
  templateUrl:'buildconfig.component.html' ,
  styleUrls:['buildconfig.component.css'],
  directives:[MODAL_DIRECTIVES,
              ROUTER_DIRECTIVES,
              FrameworkComponent,
              ModalDeleteComponent,
              CodeBuild],
  pipes:[ISOLocalPipe],
  providers:[BluePrintService]
})

export class BuildConfigComponent {
  public SingeBuid:SingeCodebuild ;
  public showConfig:boolean = false;

  public newImageName:string = '';
  public buildWays:string ='create'; // createNewBuild /selectFromPipelineStage  value= create/fromStage
  
  public relateCodebuild:any[] =[];
  public showCodebuild:any[] =[];
  
   @Input()  StageName:string;
   @Input()  StageType:string;
   @Input()  StageUuid:string;
  @Input() stagelist:StageInstance[];

  @Input()  task:Task; 
  @Output() taskChange = new EventEmitter<Task>();
  // @Input() buildconfig:BuildConfig;    //this.Task.buildconfig.buildlist;
  // @Output() buildconfigChange = new EventEmitter<BuildConfig>();
 
  @ViewChild('modal') modal: ModalComponent;


  constructor(private eventBroadcastService :EventBroadcastService,
              private router:Router,
              private activeProjectService:ActiveProjectService,
              private route:ActivatedRoute,
              private _http: Http) {
  }
  ngOnInit() {
  this.getRelateCodebuild();
  }

  newCodeBuild() {
    let newcodebuild:SingeCodebuild = new SingeCodebuild();
      newcodebuild.builduuid = UUID.UUID();
      newcodebuild.buildimage.name=this.newImageName;
      newcodebuild.buildimagetype = 'auto';
    
    // this.buildconfig.buildlist.push(newcodebuild);
    //  this.buildconfigChange.emit(this.buildconfig);
    this.task.buildconfig.buildlist.push(newcodebuild);
     this.taskChange.emit(this.task);
    
    this.newImageName ='';
    this.modal.close();
  }

  delCodeBuild(item:any){

    // this.buildconfig.buildlist= _.without( this.buildconfig.buildlist,item);
    // this.buildconfigChange.emit( this.buildconfig);
    this.task.buildconfig.buildlist = _.without(this.task.buildconfig.buildlist,item);
    this.taskChange.emit(this.task);


  }



  selectCodeBuild(item:SingeCodebuild) {
    this.SingeBuid = item;
    this.showConfig =true;
  }

  selectBuildWays(type:string){
    this.buildWays =type;
  
  }

  getRelateCodebuild() {
    let that =this;
    let ciStageList:any;
    if(this.StageType=='VerifyCI'){
     ciStageList = _.filter(this.stagelist,function(item:any){
         return item.stagetype == 'VerifyCI'   
       });
    }else if(this.StageType=='MergeCI'){
      ciStageList = _.filter(this.stagelist,function(item:any){
         return item.stagetype == 'MergeCI'   
       });
    }
    
    //save this hierarchy for further use ;
    this.relateCodebuild = _.map(ciStageList,function(stage:any){
      return {'stagename':stage.stagename, 'stagetype':stage.stagetype, 
              'stageuuid': stage.stageuuid,'tasklist': _.map(stage.tasklist,function(task:any){
                 return { 'taskuuid':task.taskuuid,'taskname':task.taskname,
                           'bulidlist':_.map(task.buildconfig.buildlist,function(codebuild:any){
                             
                    that.showCodebuild.push( {'stagename':stage.stagename, 'stagetype':stage.stagetype, 
                    'stageuuid': stage.stageuuid,'taskuuid':task.taskuuid,'taskname':task.taskname,
                     'builduuid':codebuild.builduuid,'imagename':codebuild.buildimage.name,
                     'select': false });

                      return {'builduuid':codebuild.builduuid,'imagename':codebuild.buildimage.name};
                         })}
      })}
     })

    // if(this.task.buildconfig.buildlist > 0)
   
  }

  copyCodeBuild(){
    let that=this;
     _.map(this.showCodebuild,function(codebuild){

         if(codebuild.select){
              _.map(that.stagelist,function(stage:any){
                _.map(stage.tasklist,function(task:any){
                   _.map(task.buildconfig.buildlist,function(onebuild:any){
                    if(  codebuild.stageuuid == stage.stageuuid 
                          && codebuild.taskuuid  == task.taskuuid
                          && codebuild.builduuid == onebuild.builduuid ){
                                    
                                  onebuild.builduuid = UUID.UUID();                                
                                // that.buildconfig.buildlist.push(onebuild);
                                // that.buildconfigChange.emit(that.buildconfig);
                                this.task.buildconfig.buildlist.push(onebuild);
                                this.taskChange.emit(this.task);
                      }
                  })
                }) 
              })
         }
     })
       
     this.modal.close();
  }
}
