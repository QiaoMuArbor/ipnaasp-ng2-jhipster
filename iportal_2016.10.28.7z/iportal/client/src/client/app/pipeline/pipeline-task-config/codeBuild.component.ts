import { Component, Input, Output, EventEmitter, SimpleChange} from '@angular/core';
import { framework,FrameworkComponent } from '../../src2img/framework/index';
import {SingeCodebuild} from '../newPipelineData';




@Component({
  moduleId:module.id,
  selector: 'codebuild',
  templateUrl:'codeBuild.component.html' ,
  styleUrls:['codeBuild.component.css'],
  directives:[FrameworkComponent],
})

export class CodeBuild{
	@Input() SingeBuid:SingeCodebuild;
    @Output() SingeBuidChange  = new EventEmitter<SingeCodebuild>();
    @Input()  show:boolean;
    @Output() showChange  = new EventEmitter<boolean>();

  public frameworks:framework[];
  public isonebaseimage:boolean;
  public gitcfg:{giturl:string,branch:string,clonedir:string,monitorchange:boolean,triggersubdir:string}
                       ={'giturl':'','branch':'','clonedir':'','monitorchange':true,'triggersubdir':''};
  constructor(){
    console.log(this.SingeBuid);
  }
 selectframework(frame:framework) {
   this.SingeBuid.frameworkcfg.frameworkuuid = frame.uuid;
   this.isonebaseimage = frame.isonebaseimage;
  }

  addsubgit(gitcfg:{giturl:string,branch:string,clonedir:string,monitorchange:boolean,triggersubdir:string}) {
     this.SingeBuid.gitcfg.push(gitcfg); 
  }
  deletesubgit(gitcfg:{giturl:string,branch:string,clonedir:string,monitorchange:boolean,triggersubdir:string}) {
    this.SingeBuid.gitcfg = _.filter(this.SingeBuid.gitcfg, function(item){ 
      return (item.giturl != gitcfg.giturl)||(item.branch != gitcfg.branch)||(item.clonedir != gitcfg.clonedir)||(item.monitorchange != gitcfg.monitorchange)||(item.triggersubdir != gitcfg.triggersubdir)
    });
  }

    saveCodeBuild(){
    this.show =false;
    this.SingeBuidChange.emit(this.SingeBuid);
    this.showChange.emit(this.show);
  }

  cancelCodeBuild() {
    this.show =false;
    this.showChange.emit(this.show);
  }
}