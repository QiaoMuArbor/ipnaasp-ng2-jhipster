import {Component} from '@angular/core';

@Component({
  moduleId: module.id,
  selector: 'pipeline-instance-stage-legend',
  directives:[],
  template: `
    <div class="legend">
        <div>
            <div class="block initial"></div>
            <div class="title">初始化</div>
        </div>
        <div>
            <div class="block running">
              <i class="fa fa-circle-o-notch fa-spin"></i>
            </div>
            <div class="title">运行中</div>
        </div>
        <div>
            <div class="block success"></div>
            <div class="title">成功</div>
        </div>
        <div>
            <div class="block fail"></div>
            <div class="title">失败</div>
        </div>
    </div>
`,
  styles: [`
    .legend{
      position: absolute;
      bottom: 10px;
      right: 10px;
    }
    .legend .block{
      width: 14px;
      height: 14px;
      display: inline-block;
      border-radius: 50%;
      vertical-align: middle;
      margin-right: 10px;
    }
    .legend .title{
      font-size:12px;
      display: inline-block;
      color:#999;
    }
    .legend .block.initial{
      background-color:#a6d164;
    }
    .legend .block.success{
      background-color:#3ac569;
    }
    .legend .block.running{
      background-color:#74c1f3;
      position: relative;
    }
    .legend .block.running i{
      font-size: 12px;
      color: #fff;
      position: absolute;
      top: 1px;
      left: 1px;
    }
    .legend .block.fail{
      background-color:#ee7785;
    }
  `]
})
export class PipelineInstanceStageLegend {
  constructor(){
    console.log("PipelineInstanceStageLegend")
  }
}
