import { Component,Input,Output,EventEmitter } from '@angular/core';
import { ROUTER_DIRECTIVES,ActivatedRoute,Router } from '@angular/router';
import { PipelineDisplayService } from './pipeline-display.service'
import { PipelineInstance } from './pipeline-instance.component'

@Component({
  moduleId: module.id,
  selector: 'pipeline-display',
  directives: [ROUTER_DIRECTIVES,PipelineInstance],
  providers: [PipelineDisplayService],
  templateUrl: 'pipeline-display.component.html',
  styles: [`
    .summary{
      line-height:2em;
    }
    .summary a{
      float:right;
    }
    .opt-info{
      line-height: 2em;
    }
    .opt-info > a{
      cursor:pointer;
      margin-left:20px;
    }
    .running-instances-num{
      display: inline-block;
    }

  `]
})

export class PipelineDisplayComponent {

  pipelineName:string;
  gitcfg:Array<any>;
  pipelineInstances:Array<any>;
  stagelist:Array<any>;
  instancesNum:number;
  firstPipelineInstance:any;
  restPipelineInstances:Array<any>;
  isShowRestInstances:boolean;
  pipelineid :string;
  poolingTimer: any;

  constructor(private route: ActivatedRoute,private router: Router,private pipelineDisplayService:PipelineDisplayService) {
    this.pipelineid = this.route.snapshot.params['pipelineuuid'];
  }

  ngOnInit() {
     this.getPipelineinstances()
  }

  showOrHiddenRestRunningInstances(){
    this.isShowRestInstances = !this.isShowRestInstances;
  }

  getPipelineinstances() {
    let that = this;
    that.pipelineDisplayService.getPipelineInstance(this.pipelineid)
      .subscribe((res) => {
        that.pipelineName = res.pipelinename;
        that.pipelineInstances = res.instances;
        that.instancesNum = res.instancenum;
        that.gitcfg = res.gitcfg;
        that.stagelist = res.stagelist;
        that.firstPipelineInstance = _.first(that.pipelineInstances);
        that.restPipelineInstances = _.rest(that.pipelineInstances );
        that.pooling();
      });
  }

  pooling() {
    let that = this;
    that.poolingTimer = setTimeout(function() {
      that.getPipelineinstances();
    }, 3000);
  }

  ngOnDestroy() {
    clearInterval(this.poolingTimer);
  }

}
