import {Component,Input} from '@angular/core';

import { PipelineInstanceStage } from './pipeline-instance-stage.component';
import { PipelineInstanceStageLegend } from './pipeline-instance-stage-legend.component';

@Component({
  moduleId: module.id,
  selector: 'pipeline-instance',
  directives: [PipelineInstanceStage,PipelineInstanceStageLegend],
  templateUrl: 'pipeline-instance.component.html',
  styles: [`
    .pipeline-graph{
      background-color:#f5f5f5;
      padding: 20px;
      margin-bottom: 20px;
      position:relative;
      padding-left:10%;
    }
  `]
})

export class PipelineInstance {
  @Input() stagelist: Array<any>;
  constructor(){
    console.log("instance")
  }

}
