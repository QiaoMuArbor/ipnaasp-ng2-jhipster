import { Component,Input } from '@angular/core';
import { ROUTER_DIRECTIVES } from '@angular/router';
import { ActiveProjectService } from '../../app.service';
import { PipelineStatusComponent } from './pipeline-status.directive';

@Component({
  moduleId: module.id,
  selector: 'pipeline-instance-stage',
  directives:[PipelineStatusComponent,ROUTER_DIRECTIVES],
  templateUrl: 'pipeline-instance-stage.component.html',
  styles: [`
    div.flow{
     width: 150px;
     display: inline-block;
     text-align: center;
     position:relative;
     min-height: 150px;
     vertical-align: top;
    }
    div .progress-bar{
      float:none;
    }
    .flow div.icon{
      width: 30px;
      height: 30px;
      border-radius: 50%;
      background-color: #3ac569;
      margin-left: 60px;
      margin-top: 10px;
      margin-bottom: 20px;
    }
    .flow div.icon.initial{
      background-color: #a6d164;
    }
    .flow div.icon.running{
      background-color: #74c1f3;
    }
    .flow div.icon.running i{
      font-size: 20px;
      position: absolute;
      left: 65.2px;
      top: 34.5px;
      color: #fff;
    }
    .flow div.icon.fail{
      background-color:#ee7785;
    }
    .flow div.line{
      border: 1px solid #a6d164;
      position: absolute;
      top: 44px;
      width: 124px;
      left: 90px;
    }
    .flow-stage{
      width: 140px;
      margin: 0 auto;
      border-radius: 3px;
      line-height:24px;
      color:#fff;
      height:24px;
      margin-bottom: 10px;
    }
    .flow-stage a{
      color:white;
    }
    .flow div.line.initial{
      border-color:#a6d164;
    }
    .flow div.line.success{
      border-color:#3ac569;
    }
    .flow div.line.running{
      border-color:#74c1f3;
    }
    .flow div.line.fail{
      border-color:#ee7785;
    }
    .flow-stage.initial{
      background-color:#a6d164;
    }
    .flow-stage.success{
      background-color:#3ac569;
    }
    .flow-stage.running{
      background-color:#74c1f3;
    }
    .flow-stage.fail{
      background-color:#ee7785;
    }
  `]
})

export class PipelineInstanceStage {
  @Input()stage:Array<any>;

  @Input()isUnShowLine:boolean;
  // @Input()commitid:string;

  constructor(private activeProject:ActiveProjectService){
    console.log("instance stage")
  }


}
