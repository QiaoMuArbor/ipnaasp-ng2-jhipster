import {Input,Directive,Renderer,ElementRef} from '@angular/core';

import * as _ from "underscore";

@Directive({
  selector: '[pipeline-status]'
})
export class PipelineStatusComponent {
  @Input('pipeline-status')
  set status(status:string){
    let isLine = (-1!=_.indexOf(this.el.nativeElement.classList,'line'))?true:false;

    if(!status) {
      status = 'initial';
    }
    this.renderer.setElementClass(this.el.nativeElement,status,true);

    // if(status=='running' && !isLine) {
    //   this.renderer.setElementClass(this.el.nativeElement,'progress-bar',true);
    //   this.renderer.setElementClass(this.el.nativeElement,'progress-bar-striped',true);
    // }
  }
  constructor(private renderer:Renderer,private el:ElementRef){

  }
}
