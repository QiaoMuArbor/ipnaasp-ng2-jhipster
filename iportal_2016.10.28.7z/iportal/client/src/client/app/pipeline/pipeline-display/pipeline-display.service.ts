// Observable Version
import { Injectable }     from '@angular/core';
import { Http, Response } from '@angular/http';
import { Headers, RequestOptions } from '@angular/http';
import { Observable }     from 'rxjs/Observable';
import { AuthHttp} from '../../shared/index';
import {ActiveProjectService} from '../../app.service';



@Injectable()
export class PipelineDisplayService {
  //{tenantid}/pipeline/{pipelineuuid}/currentinstances
  private pipelineUrl = '/api/dev/v1/tenants/';
  constructor(private _http: AuthHttp, private activeProject: ActiveProjectService) {

  }

  getPipelineInstance(pipelineuuid:string) {

    return this._http.get(this.pipelineUrl + this.activeProject.id + '/pipelines/' + pipelineuuid + '/currentinstances')
      .map(respipeinstance => {
          return respipeinstance
        }
      )
  }
}
