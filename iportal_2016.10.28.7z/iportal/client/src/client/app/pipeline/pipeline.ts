export class pipeline {
  public tenantid:string = '';
  public pipelineuuid:string = '';
  public pipelinename:string = '';
  public createtime:string = '';
  public lastinstendtime:string = '';
  public isdraft:boolean = false;
  public status:string = '';
  public runninginstnum:string = '';
  public averageruntime:string = '';
}

export class pipelineinfo {
  public tenantid:string = '';
  public pipelinename:string = '';
  public pipelineuuid:string = '';
  public createtime:string = '';
  public isgerrit:boolean = false;
  public isdraft:boolean = false;
  public stagelist:stageinstance[]=[];
}

export class stageinstances extends Array{
  public stageuuid:string = '';
  public stagename:string = '';
  public stagetype:string = '';
  public tasklist:taskinfo[]=[];
}

export class stageinstance {
  public stageuuid:string = '';
  public stagename:string = '';
  public stagetype:string = '';
  public tasklist:taskinfo[]=[];
}
export class taskinfo {
  public taskuuid:string = '';
  public taskname:string = '';
  public buildconfig:{buildlist:buildlist[]}={'buildlist':[new buildlist()]};
  public testconfig:testconfig = new testconfig();
  public releaseconfig:{releaselist:releaseinfo[],swr:{swraddr:string}[],ftpserver:{ip:string,port:string,uploaddir:string}[]}
         ={'releaselist':[],'swr':[],'ftpserver':[]};
}
export class releaseinfo {
  public releaseuuid:string = '';
  public type:string = '';
  public stageuuid:string = '';
  public taskuuid:string = '';
  public objectuuid:string = '';
  public version:string = '';
}


export class blueprint {
  public blueprintuuid:string = '';
  public sourcetype:string = 'blueprintcenter';
  public blueprint:{tenantid:string,name:string,version:string,tag:string}={'tenantid':'','name':'','version':'','tag':''};
  public blueprintgiturl:{giturl:string,filename:string}={'giturl':'','filename':''};
  public blueprintnewname:string = '';
  public imagessource:{image:{tenantid:string,name:string,version:string},relativebuild:{stageuuid:string,taskuuid:string,builduuid:string}}[]=[];
  public instparalist:{serviceinfo:{name:string,value:string}[],param_list:{name:string,value:string}[],eps_policy:{name:string,value:string}[]}=
         {'serviceinfo':[],'param_list':[],'eps_policy':[]};
}

export class imagesource {
  public image:{tenantid:string,name:string,version:string}={'tenantid':'','name':'','version':''};
  public relativebuild:{stageuuid:string,taskuuid:string,builduuid:string}={'stageuuid':'','taskuuid':'','builduuid':''};
}


export class testconfig {
  public needtest:boolean = false;
  public blueprintlist:blueprint[] = [];
  public testdriver:{blueprintuuid:string,build:{stageuuid:string,taskuuid:string,builduuid:string}}
         ={'blueprintuuid':'','build':{'stageuuid':'','taskuuid':'','builduuid':''}};
  public testcasestatic:{isused:boolean,script:string,resultfile:string}={'isused':false,'script':'','resultfile':''};
  public coveragestatic:{isused:boolean,script:string,resultfile:string}={'isused':false,'script':'','resultfile':''};
}

export class releaseconfig {
  public releaselist:{'releaseuuid':string,'type':string,'stageuuid':string,'taskuuid':string,'objectuuid':string,'version':string}[]=[];
  public swr:{'swraddr':string}[]=[];
  public ftpserver:{'ip':string,'port':string,'uploaddir':string}[]=[];
}






export class buildlist {
  public builduuid:string = '';
  public buildimage:{tenantid:string,name:string,version:string}={'tenantid':'','name':'','version':''};
  public description:string = '';
  public frameworkuuid:string ='';
  public gitcfg:{giturl:string,branch:string,clonedir:string,monitorchange:boolean,triggersubdir:string}[] = [];
  public buildscript:string = '';
  public buildimagetype:string = '';
  public installfilesdir:string = '';
  public installscript:string = '';
  public runscript:string = '';
  public dockerfiledir:string = '';
  public imagedescfile:string = '';
  public staticcheck:{isused:boolean,script:string,resultfile:string}={'isused':false,'script':'','resultfile':''};
  public cyclomaticcomplexity:{isused:boolean,script:string,resultfile:string}={'isused':false,'script':'','resultfile':''};
  public unittest:{isused:boolean,script:string,coveragestaticfile:string,testcasestaticfile:string}={'isused':false,'script':'','coveragestaticfile':'','testcasestaticfile':''};
}
export class codebuildview {
  public builduuid:string = '';
  public buildimage:{tenantid:string,name:string,version:string} = {'tenantid':'','name':'','version':''};
  public description:string='';
  public frameworkcfg:{frameworkuuid:string,tenantid:string}={'frameworkuuid':'','tenantid':''};
  public gitcfg:{giturl:string,branch:string,clonedir:string,monitorchange:boolean,triggersubdir:string}[]=[{'giturl':'','branch':'','clonedir':'','monitorchange':true,'triggersubdir':''}];
  public buildscript:string = '';
  public buildimagetype:string = '';
  public installfilesdir:string = '';
  public installscript:string = '';
  public runscript:string = '';
  public dockerfiledir:string = '';
  public imagedescfile:string ='';
  public staticcheck:{isused:boolean,script:string,resultfile:string} = {'isused':false,'script':'','resultfile':''};
  public cyclomaticcomplexity:{isused:boolean,script:string,resultfile:string} = {'isused':false,'script':'','resultfile':''};
  public unittest:{isused:boolean,script:string,coveragestaticfile:string,testcasestaticfile:string} = {'isused':false,'script':'','coveragestaticfile':'','testcasestaticfile':''};
  public istestdriver:boolean = false;
  public isshow:boolean = false;
}

export class codebuild {
  public builduuid:string = '';
  public buildimage:{tenantid:string,name:string,version:string} = {'tenantid':'','name':'','version':''};
  public description:string='';
  public frameworkcfg:{frameworkuuid:string,tenantid:string}={'frameworkuuid':'','tenantid':''};
  public gitcfg:{giturl:string,branch:string,clonedir:string,monitorchange:boolean,triggersubdir:string}[]=[{'giturl':'','branch':'','clonedir':'','monitorchange':true,'triggersubdir':''}];
  public buildscript:string = '';
  public buildimagetype:string = '';
  public installfilesdir:string = '';
  public installscript:string = '';
  public runscript:string = '';
  public dockerfiledir:string = '';
  public imagedescfile:string ='';
  public staticcheck:{isused:boolean,script:string,resultfile:string} = {'isused':false,'script':'','resultfile':''};
  public cyclomaticcomplexity:{isused:boolean,script:string,resultfile:string} = {'isused':false,'script':'','resultfile':''};
  public unittest:{isused:boolean,script:string,coveragestaticfile:string,testcasestaticfile:string} = {'isused':false,'script':'','coveragestaticfile':'','testcasestaticfile':''};
  public istestdriver:boolean = false;
}