/**
 * Created by zte on 16-8-15.
 */
import { RouterConfig } from '@angular/router';
import { PipelineComponent } from './pipeline.component';
import { PipelineDisplayComponent } from './pipeline-display/pipeline-display.component';
import {PipelineActionComponent} from './pipeline-action/pipeline-action.component';
import {ProjectConfigComponent,FrameworkConfigComponent,
        FrameworkAddComponent,FrameworkEditComponent} from './projectconfig/index';

export const PipelineRoutes: RouterConfig = [

  {
    path: 'pipelines',
    component:PipelineComponent
  },
  {
    path: 'pipeline',
    children:[
      {
        path: '',
        redirectTo: 'newPipeline',
        pathMatch:'full'
      },
      {
               path: 'editPipeline/:pipelineId',
               component: PipelineActionComponent,
               data:{type:'edit'}
      },
      {
               path: 'newPipeline',
               component: PipelineActionComponent,
               data:{type:'new'}
      },
      {
        path: 'instance/:pipelineuuid',
        component: PipelineDisplayComponent
      }
    ]
  },
  {
    path:'projectcfg',
    component:ProjectConfigComponent,
    children:[
       {
          path:'',
          redirectTo:'frameworks',
          pathMatch:'full'
       },
       {
        path:'frameworks',
        children:[
          {
            path:'',
            redirectTo:'list',
            pathMatch:'full'
          },
          {
            path:'list',
            component:FrameworkConfigComponent
          }
        ]
      },

    ]
  },
  {
    path:'frameworks',
    children:[
      {
        path:'',
        redirectTo:'create',
        pathMatch:'full'
      },
      {
        path:'create',
        component:FrameworkAddComponent,
      },
      {
        path:'edit/:uuid',
        component: FrameworkEditComponent,
      }
    ]
  }
];