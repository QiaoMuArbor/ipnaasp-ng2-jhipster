import { Component, ViewChild } from '@angular/core';
import { PipelineService } from './pipeline.service';
import { EventBroadcastService, ISOLocalPipe, ModalDeleteComponent } from '../shared/index';
import { ActiveProjectService } from '../app.service';
import { MODAL_DIRECTIVES, ModalComponent } from 'ng2-bs3-modal/ng2-bs3-modal';
import { pipeline } from './pipeline';
import { ROUTER_DIRECTIVES,Router, ActivatedRoute } from '@angular/router';

@Component({
  moduleId:module.id,
  selector: 'pipelines',
  providers:[PipelineService],
  directives:[ROUTER_DIRECTIVES,MODAL_DIRECTIVES, ModalDeleteComponent],
  templateUrl:'pipeline.component.html',
  styleUrls:['pipeline.component.css'],
  pipes:[ISOLocalPipe]
})

export class PipelineComponent {
  @ViewChild('modal') modal: ModalComponent;
  public pipelinelist:pipeline[];
  public time:any;
  public savepipelinelist:pipeline[];
  public optype:string;
  constructor(private pipelineService:PipelineService,
              private eventBroadcastService:EventBroadcastService) {

  }
  
  ngOnInit() {
    this.pipelinelist = [];
    this.getPipeLinelist();
    this.freshPipeline();
  }

  getPipeLinelist() {
    this.pipelineService.getPipelines().subscribe(
      (res:{pipelinelist:pipeline[]})=>{
        this.savepipelinelist = res.pipelinelist ||[];
        this.pipelinelist = res.pipelinelist;
      }
    );
  }

  delPipeline(id:string) {
    this.pipelineService.delete(id).subscribe(
      (res:any)=>{
        this.eventBroadcastService.broadcastSuccess("删除成功");
        this.getPipeLinelist();
        this.modal.close();
      },(err:any)=>{
        this.modal.close();
        this.eventBroadcastService.broadcastError('删除失败');
      }
    )
  }
  disablePipeline(id:string,status:string) {
    let optype:string='';
    if(status==='enable'){
      optype = 'disable';
    }
     if(status==='disable'){
      optype = 'enable';
    }
    let putbody:{pipelineuuid:string,optype:string} = {'pipelineuuid':id,'optype':optype};
    this.pipelineService.operationPipeline(putbody).subscribe(
      res=>{
        if(optype==='disable') {
          this.eventBroadcastService.broadcastSuccess('禁用成功');
        }
        if(optype==='enable') {
          this.eventBroadcastService.broadcastSuccess('启用成功');
        }
      },err=>{
        if(optype==='disable') {
          this.eventBroadcastService.broadcastError('禁用失败');
        }
        if(optype==='enable') {
          this.eventBroadcastService.broadcastError('启用失败');
        }
      }
    )
  }
  freshPipeline() {
    this.time=setInterval(()=>{this.getPipeLinelist()},10000);
  }

  trackByPipelines(index:number,pipeline:any) {
    return pipeline.pipelineuuid;
  }

  pipelinesearch(text:string) {
    this.pipelinelist = _.filter(this.savepipelinelist,function(pipeline){
      return pipeline.pipelinename.indexOf(text)!=-1;
    });
  }

  ngOnDestroy() {
    clearInterval(this.time);
  }
}
