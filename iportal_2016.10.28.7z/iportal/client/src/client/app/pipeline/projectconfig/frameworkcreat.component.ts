import { Component, ViewChild,Input,AfterContentInit,ElementRef,Renderer } from '@angular/core';
import {CORE_DIRECTIVES,NgClass, NgStyle} from '@angular/common';
import { EventBroadcastService, ISOLocalPipe,LocalStorageService} from '../../shared/index';
import { FileSelectDirective, FileDropDirective, FileUploader,FILE_UPLOAD_DIRECTIVES} from 'ng2-file-upload/ng2-file-upload';
import { MODAL_DIRECTIVES, ModalComponent } from 'ng2-bs3-modal/ng2-bs3-modal';
import { ROUTER_DIRECTIVES,Router,ActivatedRoute } from '@angular/router';
import { UUID } from 'angular2-uuid';
import { ActiveProjectService } from '../../app.service';
import { Headers, Http, Response} from '@angular/http';
import { framework,FrameworkComponent,FrameworkService } from '../../src2img/framework/index';



@Component({
  moduleId:module.id,
  selector: 'frameworkadd',
  templateUrl: 'frameworkcreat.component.html',
  styleUrls:['frameworkcreat.component.css'],
  directives:[ROUTER_DIRECTIVES,FileSelectDirective,FileDropDirective,CORE_DIRECTIVES, FILE_UPLOAD_DIRECTIVES,NgClass, NgStyle],
  providers:[FrameworkService,LocalStorageService],
})


export class FrameworkAddComponent {
  private frameworks:framework[];
  private framework:framework;
  private makeisupload:string;
  private runisupload:string;
  private baseindex:number;
  private runindex:number;
  private version:string[];
  private saveversion:string[];
  private saveframeworks:framework[];
  private baseframeworks:framework[];
  private runframeworks:framework[];
  public baseimageUrl:any;
  public runbaseimageUrl:any;
  public baseimageUploader:FileUploader;
  public runbaseimageUploader:FileUploader;
  public hasBaseDropZoneOver:boolean = false;
  public hasAnotherDropZoneOver:boolean = false;
  private lanuagecfg:{name:string,icon:string}[]=[{name:'CPP',icon:'src2img-c++.svg'},{name:'Ruby',icon:'src2img-ruby.svg'},{name:'Python',icon:'src2img-python.svg'},{name:'Java',icon:'src2img-java.svg'},{name:'Nodejs',icon:'src2img-social-nodejs.svg'},{name:'JavaScript',icon:'src2img-javascript.svg'},{name:'go',icon:'src2img-go.svg'},{name:'TypeScript',icon:'src2img-typescript.svg'}];
  constructor(private frameworkService:FrameworkService,
              private eventBroadcastService :EventBroadcastService,
              private router:Router,
              private route:ActivatedRoute,
              private localStorageService:LocalStorageService,
              private activeProjectService:ActiveProjectService){
  }

  ngOnInit() {
    this.frameworks = [];
    this.framework = new framework();
    this.framework.baseimage.tenantid = this.activeProjectService.id;
    this.framework.runbaseimage.tenantid = this.framework.baseimage.tenantid;
    this.framework.creator = this.localStorageService.get('user',true).name;
    this.baseframeworks=[];
    this.runframeworks=[];
    this.baseimageUploader = new FileUploader({});
    this.runbaseimageUploader = new FileUploader({});
    this.framework.type="public";
    this.framework.isonebaseimage=true;
    this.framework.icon="program.svg";
    this.getframes();
    this.makeisupload="select";
    this.runisupload="select";
  }

  getframes() {
    let that = this;
    this.frameworkService.getFramewokrs().subscribe(res=>{
      that.frameworks = res.frameworks;
      that.saveframeworks = res.frameworks;
    },err=>{
      that.eventBroadcastService.broadcastError('获取开发框架失败');
    });
  }
  frameworkAdd(){
    let that =this;
    let postBody = _.clone(that.framework);
      postBody.uuid = UUID.UUID();
      this.frameworkService.addFramework(postBody).subscribe(res=>{
      this.eventBroadcastService.broadcastSuccess('导入开发框架成功');
    },err=>{
      this.eventBroadcastService.broadcastError('导入开发框架失败,请重试');
    });
  }
   updateupload(flag:string) {
    let Url = '';
    if(flag=="baseimage"){
      Url = '/api/swr/v1/tenants/'+this.activeProjectService.id+'/images/upload?name='+this.framework.baseimage.name+'&version='+this.framework.baseimage.version;
      let Uploader:FileUploader = new FileUploader({url:Url});
      return this.baseimageUploader = Uploader;
    }else{
      Url = '/api/swr/v1/tenants/'+this.activeProjectService.id+'/images/upload?name='+this.framework.runbaseimage.name+'&version='+this.framework.runbaseimage.version;
      let Uploader:FileUploader = new FileUploader({url:Url});
      return this.runbaseimageUploader = Uploader;
    }
  }

  frameworkUpdateHttp(){
    let postBody = _.clone(this.framework);
    this.frameworkService.updateFramework(postBody).subscribe(res=>{
      this.eventBroadcastService.broadcastSuccess('更新成功');
    },err=>{
      this.eventBroadcastService.broadcastError('更新失败,请重试');
    });
  }
  frameworkUpdate(){
    this.frameworkUpdateHttp();
  }
  createFramework(sign:boolean) {
    
  
    if(this.framework.uuid==""){
      /*
      if(!this.baseimagesign) {
        this.eventBroadcastService.broadcastError('请上传基础镜像包！');
        return;
      }
      if(this.framework.isonebaseimage=='false'&&!this.runimagesign) {
        this.eventBroadcastService.broadcastError('请上传运行时基础镜像包！');
        return;
      }*/
      this.frameworkAdd();
    }else{
      /*if(this.imageUploader.queue.length>0){
        if(!this.baseimagesign) {
          this.eventBroadcastService.broadcastError('请等待基础镜像包上传完成！');
          return;
        }
      }
      if(this.framework.isonebaseimage=='false'&&this.imageUploader2.queue.length>0){
        if(!this.runimagesign){
          this.eventBroadcastService.broadcastError('请等待运行时镜像包上传完成！');
          return;
        }
      }*/
      this.frameworkUpdate();
    }
  }
/*
  createSlBpss(framework:any,ifbase:boolean) {
    this.servicelet.description = 'frameworkimage';
    this.servicelet.vertype = 'common_release';
    if(ifbase){
      this.servicelet.name = framework.baseimage.name;
      this.servicelet.version = framework.baseimage.version;
      this.servicelet.imageUploader = this.baseimageUploader;
      this.createSlBp(ifbase);
    }else{
      this.servicelet.name = framework.runbaseimage.name;
      this.servicelet.version = framework.runbaseimage.version;
      this.servicelet.imageUploader = this.runbaseimageUploader;
      this.createSlBp(ifbase);
    }
  }

  createSlBp(ifbase:boolean){
    this.serviceletService
      .createbyfrmae(this.servicelet)
      .subscribe(rsp => {
        this.eventBroadcastService.broadcastSuccess('生成镜像成功');
        if(ifbase){
          this.baseimagesign = true;
        }
        if(!ifbase){
          this.runimagesign = true;
        }
      },
      error => {
        this.eventBroadcastService.broadcastError('生成镜像失败,' + error.message);
        console.log(error)
      });
  }*/
  onSubmit() {
    this.frameworkAdd();
    this.backtocblist();
  }
  getbaseframework(searchtext:string){
    this.baseframeworks = _.filter(this.saveframeworks,function(framework){
       return framework.baseimage.name.indexOf(searchtext)!=-1 || framework.runbaseimage.name.indexOf(searchtext)!=-1;
    });
  }
  getrunframeworks(searchtext:string){
    this.runframeworks = _.filter(this.saveframeworks,function(framework){
       return framework.runbaseimage.name.indexOf(searchtext)!=-1;
    });
  }
  backtocblist(){
    this.router.navigate(['../../projectcfg/frameworks/list'],{relativeTo:this.route});
  }
  public fileOverBase(e:any):void {
    this.hasBaseDropZoneOver = e;
  }

  public fileOverAnother(e:any):void {
    this.hasAnotherDropZoneOver = e;
  }
  findicon(name:string){
    this.framework.icon =_.findWhere(this.lanuagecfg,{name:name}).icon;
  }
}