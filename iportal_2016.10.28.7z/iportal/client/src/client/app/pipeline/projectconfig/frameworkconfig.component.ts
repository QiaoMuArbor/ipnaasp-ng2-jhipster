import { Component, ViewChild } from '@angular/core';
import { EventBroadcastService, ISOLocalPipe } from '../../shared/index';
import { MODAL_DIRECTIVES, ModalComponent } from 'ng2-bs3-modal/ng2-bs3-modal';
import { ROUTER_DIRECTIVES,Router,ActivatedRoute } from '@angular/router';
import { ActiveProjectService } from '../../app.service';
import { Headers, Http, Response} from '@angular/http';
import { framework,FrameworkComponent,FrameworkService } from '../../src2img/framework/index';




@Component({
  moduleId:module.id,
  selector: 'frameworkconfig',
  templateUrl: 'frameworkconfig.component.html',
  styleUrls:['frameworkconfig.component.css'],
  directives:[MODAL_DIRECTIVES,ROUTER_DIRECTIVES],
  providers:[FrameworkService],
})


export class FrameworkConfigComponent {
  private frameworks:framework[];
  private saveframeworks:framework[];
  @ViewChild('modal') modal: ModalComponent;
  constructor(private frameworkService:FrameworkService,
              private eventBroadcastService :EventBroadcastService){
  }

  ngOnInit() {
    this.frameworks = [];
    this.getframes();
  }

  getframes() {
    let that = this;
    this.frameworkService.getFramewokrs().subscribe(res=>{
      that.frameworks = res.frameworks;
      that.saveframeworks = res.frameworks;
    },err=>{
      that.eventBroadcastService.broadcastError('获取开发框架失败');
    });
  }
  delframework(id:string) {
    let that = this;
    this.frameworkService.deleteFramework(id).subscribe((res:any)=>{
      that.modal.close();
      that.eventBroadcastService.broadcastSuccess('删除成功');
      that.getframes();
    },(error:any)=>{
      that.modal.close();
      that.eventBroadcastService.broadcastError('删除失败');
    })
  }
  frameworksearch(searchtext:string){
    this.frameworks = _.filter(this.saveframeworks,function(framework){
      return framework.name.indexOf(searchtext)!=-1;
    });
  }
}