import { Component, ViewChild,Input,AfterContentInit,ElementRef,Renderer } from '@angular/core';
import {CORE_DIRECTIVES,NgClass, NgStyle} from '@angular/common';
import { EventBroadcastService, ISOLocalPipe,LocalStorageService} from '../../shared/index';
import { FileSelectDirective, FileDropDirective, FileUploader,FILE_UPLOAD_DIRECTIVES} from 'ng2-file-upload/ng2-file-upload';
import { MODAL_DIRECTIVES, ModalComponent } from 'ng2-bs3-modal/ng2-bs3-modal';
import { ROUTER_DIRECTIVES,Router,ActivatedRoute } from '@angular/router';
import { UUID } from 'angular2-uuid';
import { ActiveProjectService } from '../../app.service';
import { Headers, Http, Response} from '@angular/http';
import { framework,FrameworkComponent,FrameworkService } from '../../src2img/framework/index';



@Component({
  moduleId:module.id,
  selector: 'frameworkedit',
  templateUrl: 'frameworkedit.component.html',
  styleUrls:['frameworkcreat.component.css'],
  directives:[ROUTER_DIRECTIVES,FileSelectDirective,FileDropDirective,CORE_DIRECTIVES, FILE_UPLOAD_DIRECTIVES,NgClass, NgStyle],
  providers:[FrameworkService,LocalStorageService],
})


export class FrameworkEditComponent {
  private frameworks:framework[];
  private framework:framework;
  private makeisupload:string;
  private runisupload:string;
  private baseindex:number;
  private runindex:number;
  private version:string[];
  private saveversion:string[];
  private saveframeworks:framework[];
  private baseframeworks:framework[];
  private runframeworks:framework[];
  private id:string;
  private baseimageUrl:any;
  private runbaseimageUrl:any;
  private baseimageUploader:FileUploader;
  private runbaseimageUploader:FileUploader;
  private hasBaseDropZoneOver:boolean = false;
  private hasAnotherDropZoneOver:boolean = false;
  private isEditbase:boolean=false;
  private isEditrun:boolean=false;
  private lanuagecfg:{name:string,icon:string}[]=[{name:'CPP',icon:'src2img-c++.svg'},{name:'Ruby',icon:'src2img-ruby.svg'},{name:'Python',icon:'src2img-python.svg'},{name:'Java',icon:'src2img-java.svg'},{name:'Nodejs',icon:'src2img-social-nodejs.svg'},{name:'JavaScript',icon:'src2img-javascript.svg'},{name:'go',icon:'src2img-go.svg'},{name:'TypeScript',icon:'src2img-typescript.svg'}];
  constructor(private frameworkService:FrameworkService,
              private eventBroadcastService :EventBroadcastService,
              private router:Router,
              private route:ActivatedRoute,
              private localStorageService:LocalStorageService,
              private activeProjectService:ActiveProjectService){
  }

  ngOnInit() {
    this.framework = new framework();
    this.id = this.route.snapshot.params['uuid'];
    this.getframe(this.id);
    this.baseframeworks=[];
    this.runframeworks=[];
    this.getframes();
    this.makeisupload="select";
    this.runisupload="select";
    this.baseimageUploader = new FileUploader({});
    this.runbaseimageUploader = new FileUploader({});
  }

  getframes() {
    let that = this;
    that.frameworkService.getFramewokrs().subscribe(res=>{
      that.frameworks = res.frameworks;
      that.saveframeworks = res.frameworks;
    },err=>{
      that.eventBroadcastService.broadcastError('获取开发框架失败');
    });
  }
  getframe(id:string) {
    let that = this;
    this.frameworkService.getFramewokr(id).subscribe(res=>{
      that.framework = res;
    },err=>{
      that.eventBroadcastService.broadcastError('获取开发框架失败');
    });
  }
  updateframework() {
    this.frameworkService.updateFramework(this.framework).subscribe(res=>{
      this.eventBroadcastService.broadcastSuccess('更新成功');
    },err=>{
      this.eventBroadcastService.broadcastError('更新失败,请重试');
    });
  }
  updateupload(flag:string) {
    let Url = '';
    if(flag=="baseimage"){
      Url = '/api/swr/v1/tenants/'+this.activeProjectService.id+'/images/upload?name='+this.framework.baseimage.name+'&version='+this.framework.baseimage.version;
      let Uploader:FileUploader = new FileUploader({url:Url});
      return this.baseimageUploader = Uploader;
    }else{
      Url = '/api/swr/v1/tenants/'+this.activeProjectService.id+'/images/upload?name='+this.framework.runbaseimage.name+'&version='+this.framework.runbaseimage.version;
      let Uploader:FileUploader = new FileUploader({url:Url});
      return this.runbaseimageUploader = Uploader;
    }
  }
  onSubmit() {
    this.updateframework();
    this.backtocblist();
  }
  getbaseframework(searchtext:string){
    this.baseframeworks = _.filter(this.saveframeworks,function(framework){
       return framework.baseimage.name.indexOf(searchtext)!=-1;
    });
  }
  getrunframeworks(searchtext:string){
    this.runframeworks = _.filter(this.saveframeworks,function(framework){
       return framework.runbaseimage.name.indexOf(searchtext)!=-1;
    });
  }
  backtocblist(){
    this.router.navigate(['../../../projectcfg/frameworks/list'],{relativeTo:this.route});
  }
  public fileOverBase(e:any):void {
    this.hasBaseDropZoneOver = e;
  }

  public fileOverAnother(e:any):void {
    this.hasAnotherDropZoneOver = e;
  }
  findicon(name:string){
    this.framework.icon =_.findWhere(this.lanuagecfg,{name:name}).icon;
  }
}