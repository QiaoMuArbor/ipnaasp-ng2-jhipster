import { Injectable }     from '@angular/core';
import { Http, Response,Headers, RequestOptions} from '@angular/http';
import { Observable }     from 'rxjs/Observable';
import { AuthHttp} from '../shared/index';
import { pipeline,pipelineinfo,stageinstance} from './pipeline';
import {PipelineConfig} from './newPipelineData';
import { ActiveProjectService } from '../app.service';


@Injectable()
export class PipelineService {
  private pipelineUrl = '/api/dev/v1/tenants/';
  constructor(private _http: AuthHttp,private activeProjectService:ActiveProjectService) {
  
    this.pipelineUrl+=this.activeProjectService.id+'/';
  }

  getPipelines (): Observable<any> {
    return this._http.get(this.pipelineUrl+'pipelines');
  }

  getPipeline (id:string):Observable<any>{
   return this._http.get(this.pipelineUrl+'pipelines/'+id);
  }

  getPipelineBuild (id:string): any {
    return this._http.get(this.pipelineUrl+'pipelines/'+'id').map(res=>{
      let stagelist:stageinstance[]=res.stagelist||[];
      return _.map(stagelist,function(item){
        return {'stageuuid':item.stageuuid,'stagename':item.stagename,'tasklist':_.map(item.tasklist,function(task){
          return {'taskuuid':task.taskuuid,'taskname':task.taskname,'buildlist':_.map(task.buildconfig.buildlist,function(build){
            return {'buildname':build.buildimage.name,'builduuid':build.builduuid};
          })};
        })}
      })
    }); 
  }

  delete(id: string) {
    return this._http.delete(this.pipelineUrl+'pipelines/'+id);
  }

  addPipeline (pipeline:pipelineinfo) {
    let that =this;
    return this._http.post(this.pipelineUrl+'pipelines',pipeline)
      .map(res=> {
        return res;
      });
 
  }
 putPipeline (pipeline:pipelineinfo) {
    let that =this;
    return this._http.put(this.pipelineUrl+'pipelines',pipeline)
      .map(res=> {
        return res;
      });
 
  }
  operationPipeline(mes:{pipelineuuid:string,optype:string}) {
    return this._http.put(this.pipelineUrl+'pipelines/'+'id',mes);
  }
  // getCodeBuild (id: string): Observable<codebuildinfo> {
  //   return super.get(this.src2imgUrl+'codebuild/'+id);
  // }

  // getIntances(id:string) {
  //   let url:string = this.src2imgUrl +'codebuild/'+id+'/instances';
  //   return super.get(url);
  // }

  
  // oneBuild(id:string,build:onebuild) {
  //   return super.put(this.src2imgUrl+'codebuild/'+id+'/onebuild',build);
  // }
  // putCodeBuild(cbinfo:codebuildinfo): Observable<codebuildinfo>{
  //   return super.put(this.src2imgUrl+'codebuild/'+cbinfo.uuid,cbinfo);
  // }

 newPipeline (pipeline:PipelineConfig) {
    let that =this;
    return this._http.post(this.pipelineUrl+'pipelines',pipeline)
      .map(res=> {
        return res;
      });
 
  }
 editPipeline (pipeline:PipelineConfig) {
    let that =this;
    return this._http.put(this.pipelineUrl+'pipelines',pipeline)
      .map(res=> {
        return res;
      });
 
  }
}