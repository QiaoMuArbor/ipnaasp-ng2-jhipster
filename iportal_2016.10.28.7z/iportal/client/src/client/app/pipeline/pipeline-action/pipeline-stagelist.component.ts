import {Component,ViewChild, Input, Output, EventEmitter, SimpleChange} from '@angular/core';
import { MODAL_DIRECTIVES, ModalComponent } from 'ng2-bs3-modal/ng2-bs3-modal';
import { EventBroadcastService,ModalDeleteComponent, UUID } from '../../shared/index';
import {StageInstance} from '../newPipelineData';
import { PipeLineTaskComponent} from './pipeline-tasklist.component';

@Component({
  moduleId:module.id,
  selector: 'stagelist',
  templateUrl:'pipeline-stagelist.component.html',
  styleUrls:['pipeline-stagelist.component.css'],
  directives:[ModalDeleteComponent,
              MODAL_DIRECTIVES,
              PipeLineTaskComponent],
})

export class PipeLineStageComponent{
 @ViewChild('modal') modal: ModalComponent;
 @Input()  stagelist:StageInstance[];
 @Output() valueChange = new EventEmitter<StageInstance[]>();
  public stagetypes:Array<string> = ['VerifyCI','Code Review','MergeCI','Release'];
  public stagenames:Array<string> = ['Unit Test','Function Test','System Test','Code Review','MergeCI','Release'];
  public stagename:string ='';
  public stagetype:string ='';

  public showStage:boolean =true;

 constructor(){

	}
 ngOnInit(){

	 }
 delStage(id:string){
    let ciStageList:any;
    let that=this;
    let index:number = _.findLastIndex(this.stagelist,{'stageuuid':id});
    //del testconfig-blueprint-relativeid 
    
    if(this.stagelist[index].stagetype=='VerifyCI'){
     ciStageList = _.filter(this.stagelist,function(item:any){
         return item.stagetype == 'VerifyCI'   
       });
    }else if(this.stagelist[index].stagetype=='MergeCI'){
      ciStageList = _.filter(this.stagelist,function(item:any){
         return item.stagetype == 'MergeCI'   
       });
    }

     _.map(ciStageList,function(stage:any){
        _.map(stage.tasklist,function(task:any){
            _.map(task.testconfig.imagessource,function(item:any){
              if(item.relativebuild.stageuuid == that.stagelist[index].stageuuid){
                 item.relativebuild.stageuuid ='';
                 item.relativebuild.taskuuid  ='';
                 item.relativebuild.builduuid ='';
              }
            })
        })
     })
    

    this.stagelist.splice(index,1);
    this.valueChange.emit(this.stagelist);
  }
addStage(){
    let newstage:StageInstance = new StageInstance();
    newstage.stagename = this.stagename;
    newstage.stagetype = this.stagetype;
    newstage.stageuuid = UUID.UUID();
    
  let index:number = _.findLastIndex(this.stagelist,{'stagetype':newstage.stagetype});
     switch (newstage.stagetype ) {
       case "VerifyCI":
          {
            if(index==-1){
              this.stagelist.splice(0,0,newstage);
            }else{
              this.stagelist.splice(index+1,0,newstage);
            }
          }
         break;
       case "Code Review":
         {

           let verifyCiIndex:number = _.findLastIndex(this.stagelist,{'stagetype':'VerifyCI'});
            if(index==-1 && verifyCiIndex ==-1 ){
              this.stagelist.splice(0,0,newstage);
            }else if(index==-1 && verifyCiIndex>=0 ){
              this.stagelist.splice(verifyCiIndex+1,0,newstage);
            }else{
               // only one code review
              // this.stagelist.splice(index+1,0,newstage);
            }
         }
         break;
       case "MergeCI":
         {
            let verifyCiIndex:number = _.findLastIndex(this.stagelist,{'stagetype':'VerifyCI'});
            let codeReviewIndex:number = _.findLastIndex(this.stagelist,{'stagetype':'Code Review'});
            if(index==-1 && verifyCiIndex ==-1 && codeReviewIndex==-1){
              this.stagelist.splice(0,0,newstage);

            }else if( index==-1 && verifyCiIndex>=0 && codeReviewIndex ==-1){
              this.stagelist.splice(verifyCiIndex+1,0,newstage);

            }else if( index==-1 && codeReviewIndex>=0){

              this.stagelist.splice(codeReviewIndex+1,0,newstage);
            }else{
              this.stagelist.splice(index+1,0,newstage);
            }
         }
         break;
       case "Release":
         {
            let verifyCiIndex:number = _.findLastIndex(this.stagelist,{'stagetype':'VerifyCI'});
            let codeReviewIndex:number = _.findLastIndex(this.stagelist,{'stagetype':'Code Review'});
            let mergeCiIndex:number = _.findLastIndex(this.stagelist,{'stagetype':'MergeCI'});
            if(index==-1 && verifyCiIndex ==-1 && codeReviewIndex==-1  && mergeCiIndex ==-1 ){
              this.stagelist.splice(0,0,newstage);
            }else if(index==-1 && verifyCiIndex >=0 && codeReviewIndex ==-1 && mergeCiIndex ==-1 ){
              this.stagelist.splice(verifyCiIndex+1,0,newstage);
            }else if(index==-1 && codeReviewIndex>=0 && mergeCiIndex==-1 ){
              this.stagelist.splice(codeReviewIndex+1,0,newstage);
            }else if(index ==-1 && mergeCiIndex>=0){
               this.stagelist.splice(mergeCiIndex+1,0,newstage);
            }else{
               this.stagelist.splice(index+1,0,newstage);
            }
         }
         break;
     }

    this.modal.close();
    this.valueChange.emit(this.stagelist);
}

}

