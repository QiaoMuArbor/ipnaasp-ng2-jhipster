import { Component, ViewChild } from '@angular/core';
import { PipelineService } from '../pipeline.service';
import { EventBroadcastService, ISOLocalPipe, ModalDeleteComponent,UUID} from '../../shared/index';
import { ActiveProjectService } from '../../app.service';
import { PipelineConfig,StageInstance} from '../newPipelineData';
import { ROUTER_DIRECTIVES,Router, ActivatedRoute } from '@angular/router';
import {PipeLineStageComponent} from './pipeline-stagelist.component';

@Component({
  moduleId:module.id,
  selector: 'pipeline-action',
  providers:[PipelineService],
  directives:[ROUTER_DIRECTIVES,
              PipeLineStageComponent],
  templateUrl:'pipeline-action.component.html',
  styleUrls:['pipeline-action.component.css'],
  pipes:[ISOLocalPipe]
})

export class PipelineActionComponent {
  public activePipeline:PipelineConfig;
  public isgerrit:boolean ;  
  public pipelinename:string ;
  public Stagelist:StageInstance[];
  
  public showTaskConfig:boolean =false;
  private actionType:string;
  private pipelineId:string;



  constructor(private pipelineService:PipelineService,
              private activeProjectService:ActiveProjectService,
              private eventBroadcastService:EventBroadcastService,
              private router:Router,
              private activatedRoute:ActivatedRoute) {
     let that=this;
     this.activatedRoute.data.subscribe(data=>{
         that.actionType = data.type;
     });
 

  }
  ngOnInit() {

    if(this.actionType =='edit'){ //edit
       this.pipelineId =this.activatedRoute.snapshot.params['pipelineId']; 
       this.getPipeline();
      }else{  //create
          this.isgerrit =true;
          this.activePipeline = new PipelineConfig();
          this.Stagelist =this.activePipeline.stagelist || [];
          this.initStagegroup();
      }
      // console.log(this.activePipeline);
    //this.stagenames = ['Unit Test','Functional Test','System Test','VerifyCI','Code Review','MergeCI','Release','Deploy'];
   // this.stagetypes = ['VerifyCI','Code Review','MergeCI','Release'];
    /*this.stagetypes = ['VerifyCI','Code Review','MergeCI','Release','Deploy'];*/
  
  }
  deepClone(data:any){
     return JSON.parse(JSON.stringify(data));
  }
  getPipeline(){
      let pipeline:any;
     this.pipelineService.getPipeline(this.pipelineId)
          .subscribe(res=>{

            this.activePipeline =this.deepClone(res);

            this.isgerrit = res.isgerrit || false;
            this.pipelinename =res.pipelinename || "";
            this.Stagelist=  this.activePipeline.stagelist|| [];
               },err=>{});
  }

  initStagegroup() {
    let Unit:StageInstance = new StageInstance();
    Unit.stagename='Unit Test';
    Unit.stagetype='VerifyCI';
    Unit.stageuuid=UUID.UUID();
    this.Stagelist.push(Unit);
    if(this.isgerrit){
      let Code:StageInstance = new StageInstance();
      Code.stagename='Code Review';
      Code.stagetype='Code Review';
      Code.stageuuid=UUID.UUID();
      this.Stagelist.push(Code);
      let MergeCI:StageInstance = new StageInstance();
      MergeCI.stagename='MergeCI';
      MergeCI.stagetype='MergeCI';
      MergeCI.stageuuid=UUID.UUID();
      this.Stagelist.push(MergeCI);
    }
    let Release:StageInstance = new StageInstance();
    Release.stagename='Release';
    Release.stagetype='Release';
    Release.stageuuid=UUID.UUID();
    this.Stagelist.push(Release);
  }
  // when edit how to known if
  ifgerrit() {
    if(this.isgerrit){
      this.Stagelist = _.filter(this.Stagelist,function(item:any){
        return item.stagetype!='Code Review'&&item.stagetype!='MergeCI';
      })
    }else{    

 
     let Code:StageInstance = new StageInstance();
      Code.stagename='Code Review';
      Code.stagetype='Code Review';
      Code.stageuuid=UUID.UUID();

    let verifyCiIndex:number = _.findLastIndex(this.Stagelist,{'stagetype':'VerifyCI'});
    this.Stagelist.splice(verifyCiIndex+1,0,Code);


    let MergeCI:StageInstance = new StageInstance();
      MergeCI.stagename='MergeCI';
      MergeCI.stagetype='MergeCI';
      MergeCI.stageuuid=UUID.UUID();
      // if user donot add release Stage
      let codeReviewIndex:number=_.findIndex(this.Stagelist,{'stagetype':'Code Review'});
      this.Stagelist.splice(codeReviewIndex+1,0,MergeCI);
      // if(codeReviewIndex == -1){
      //   this.Stagelist.splice(0,0,Code,MergeCI);
      // }else{
        
      // }
    }
  }

  submit() {
   
 
   if(this.actionType =='edit'){

    this.activePipeline.isgerrit = this.isgerrit;
    this.activePipeline.pipelinename = this.pipelinename;

         this.pipelineService.editPipeline(this.activePipeline).subscribe(
      res=>{
        this.eventBroadcastService.broadcastSuccess('流水线创建成功');
        this.router.navigate(['../../pipelines'],{relativeTo:this.activatedRoute});
      },err=>{
        this.eventBroadcastService.broadcastError('流水线创建失败');
      }
    );
   }else{

    this.activePipeline.tenantid = this.activeProjectService.id;
    this.activePipeline.isgerrit = this.isgerrit;
    this.activePipeline.pipelinename = this.pipelinename;
    this.activePipeline.pipelineuuid = UUID.UUID();

       this.pipelineService.newPipeline(this.activePipeline).subscribe(
      res=>{
        this.eventBroadcastService.broadcastSuccess('流水线创建成功');
        this.router.navigate(['../../pipelines'],{relativeTo:this.activatedRoute});
      },err=>{
        this.eventBroadcastService.broadcastError('流水线创建失败');
      }
    );
   }
  
  }

  backtolist() {
    if(this.actionType =='edit'){
       this.router.navigate(['../../../pipelines'],{relativeTo:this.activatedRoute});
    }else{
       this.router.navigate(['../../pipelines'],{relativeTo:this.activatedRoute});
    }
   
  }
}
