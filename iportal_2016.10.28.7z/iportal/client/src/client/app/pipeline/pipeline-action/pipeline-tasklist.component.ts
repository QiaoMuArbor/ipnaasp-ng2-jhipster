import {Component,ViewChild,Input, Output, EventEmitter, SimpleChange} from '@angular/core';
import { MODAL_DIRECTIVES, ModalComponent } from 'ng2-bs3-modal/ng2-bs3-modal';
import { EventBroadcastService,ModalDeleteComponent, UUID } from '../../shared/index';
import { ROUTER_DIRECTIVES,Router, ActivatedRoute } from '@angular/router';
import { StageInstance,Task} from '../newPipelineData';
import { TestConfigComponent } from '../pipeline-task-config/testconfig.component';
import { ReleaseConfigComponent } from '../pipeline-task-config/releaseconfig.component';
import { BuildConfigComponent } from '../pipeline-task-config/buildconfig.component';
   

@Component({
  moduleId:module.id,
  selector: 'tasklist',
  templateUrl:'pipeline-tasklist.component.html',
  styleUrls:['pipeline-tasklist.component.css'],
  directives:[ModalDeleteComponent,
              ROUTER_DIRECTIVES,
              MODAL_DIRECTIVES,
              TestConfigComponent,
              ReleaseConfigComponent,
              BuildConfigComponent ],
})

export class PipeLineTaskComponent{
 @Input()  tasklist:Task[];
 @Input()  StageName:string;
 @Input()  StageType:string;
 @Input()  StageUuid:string;

 @Input()  stagelist:StageInstance[];

 @Output() valueChange = new EventEmitter<Task[]>();

 @ViewChild('modal') modal: ModalComponent;
 public task:Task;

 public editId:number = null;
 public ifEdit:boolean =false;
 public newTaskName:string='';
 
 public taskConfig:boolean = false;
 public ConfigShow:string = '';
 

 constructor(){

  }
 ngOnInit(){

   }
 delTask(id:string){
    let ciStageList:any;
    let that=this;

   let index: number = _.findLastIndex(this.tasklist,{'taskuuid':id});



  if(this.StageType=='VerifyCI'){
     ciStageList = _.filter(this.stagelist,function(item:any){
         return item.stagetype == 'VerifyCI'   
       });
    }else if(this.StageType=='MergeCI'){
      ciStageList = _.filter(this.stagelist,function(item:any){
         return item.stagetype == 'MergeCI'   
       });
    }

     _.map(ciStageList,function(stage:any){
        _.map(stage.tasklist,function(task:any){
            _.map(task.testconfig.imagessource,function(item:any){
              if(item.relativebuild.taskuuid == that.tasklist[index].taskuuid){
                 item.relativebuild.stageuuid ='';
                 item.relativebuild.taskuuid  ='';
                 item.relativebuild.builduuid ='';
              }
            })
        })
     })

   this.tasklist.splice(index,1);

   this.valueChange.emit(this.tasklist);
 }
 addTaskOpen(){
   this.task = new Task();

   this.ConfigShow ='yes';
   this.task.taskuuid = UUID.UUID();
   this.taskConfig = true;
  

 }
 addTask(){
   
         let index:number = _.findLastIndex(this.tasklist,{'taskuuid':this.task.taskuuid});
         this.tasklist.splice(index+1,0,this.task);
          this.valueChange.emit(this.tasklist);
         this.taskConfig = false;
         this.ConfigShow ='';
 }

 editTask(i:number){
  
  this.editId =i;
  this.ifEdit =true;
  this.ConfigShow ='no';

  this.newTaskName = this.tasklist[i].taskname;
  this.task        = this.tasklist[this.editId];
     this.valueChange.emit(this.tasklist);



  this.taskConfig = true;
 }

 SaveTask(){
     this.ifEdit =false;
     this.editId =null;
     this.ConfigShow ='';
     //this.Stage.tasklist[this.editId] = JSON.parse(JSON.stringify(this.Task));
      this.valueChange.emit(this.tasklist);


    this.taskConfig = false;  
 }
cancleTaskConfig(){
  this.task = null;
     this.taskConfig = false;
}
}

