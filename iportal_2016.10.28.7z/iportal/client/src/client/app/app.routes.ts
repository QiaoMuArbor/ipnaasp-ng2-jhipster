/**
 * Created by zte on 16-7-7.
 */
import { provideRouter, RouterConfig } from '@angular/router';
import {ActiveProjectService} from './app.service';
import { LocalStorageService } from './shared/localstorage.service';
import { DashboardComponent } from './dashboard/dashboard';
import { ActiveProjectComponent} from './active-project/activeproject.component';
import { ActiveProjectGuard} from './active-project/activeproject.guard';
import { ProjectAddComponent } from './project/project.add';
import { AboutComponent } from './about.component';
import { BlueprintRoutes } from './blueprint/blueprint.routes';
import { Src2imgRoutes } from './src2img/src2img.routes';
import { PipelineRoutes } from './pipeline/pipeline.routes';
import { SwrRoutes } from './swr/swr.routes';
import { CmsRoutes } from './csm/csm.routes';
import { VolumeRoutes } from './volume/volume.routes';
import { NetworkRoutes } from './network/network.routes';
import { MarketRoutes } from './market/market.routes';
import { MemberRoutes } from './member/member.routes';
import { UserRoutes } from './my/user.routes';
import { LoginComponent } from './login.component';
import { AppCenterRoutes } from "./appcenter/appcenter.routes";
import { registerComponent } from './register.component';
import { UserService } from './user/user.service';
import { ProjectService } from './project/project.service';
const routes: RouterConfig = [
  {
    path: '',
    redirectTo: '/login',
    pathMatch:'full'
  },
  {
    path: 'login',
    component: LoginComponent
  },
  {
    path: 'register',
    component: registerComponent
  },
  {
    path: 'projects/create',
    component: ProjectAddComponent
  },
  ...UserRoutes,
  {
    path: 'project/:id',
    component: ActiveProjectComponent,
    canActivate: [ActiveProjectGuard],
    children: [
      {
        path: '',
        redirectTo: 'dashboard',
        pathMatch:'full'
      },
      {
        path: 'dashboard',
        component: DashboardComponent
      },
      ...AppCenterRoutes,
      ...BlueprintRoutes,
      ...Src2imgRoutes,
      ...PipelineRoutes,
      ...SwrRoutes,
      ...CmsRoutes,
      ...VolumeRoutes,
      ...NetworkRoutes,
      ...MarketRoutes,
      ...MemberRoutes
    ]
  },
  {
    path:"about",
    component: AboutComponent
  },
  {
    path: "**",
    redirectTo: "/login"
  }
];

export const APP_ROUTER_PROVIDERS = [
  ProjectService,
  UserService,
  ActiveProjectGuard,
  ActiveProjectService,
  LocalStorageService,
  provideRouter(routes)
];
