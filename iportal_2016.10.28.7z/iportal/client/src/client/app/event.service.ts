    import { Injectable } from '@angular/core';
    import { Subject }    from 'rxjs/Subject';
    @Injectable()
    export class EventBusService {
      // Observable string sources
      // private missionAnnouncedSource = new Subject<string>();
      private eventBusSource = new Subject<any>();
      // Observable string streams
      // missionAnnounced$ = this.missionAnnouncedSource.asObservable();
      eventBusObservable = this.eventBusSource.asObservable();
      // Service message commands
      // announceMission(mission: string) {
      //   this.missionAnnouncedSource.next(mission);
      // }
      sendEvent(eventName:string, data: any) {
        this.eventBusSource.next({'eventName':eventName,'data':data});
      }
    }