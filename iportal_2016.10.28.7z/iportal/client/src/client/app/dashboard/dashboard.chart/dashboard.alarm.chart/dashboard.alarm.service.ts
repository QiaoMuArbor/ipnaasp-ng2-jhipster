import {Injectable}     from '@angular/core';
import {MockCfg} from "../../../mock";
import {AuthHttp} from "../../../shared/index";
import {Observable} from 'rxjs/Observable';
import {ActiveProjectService} from "../../../app.service";

@Injectable()
export class AlarmService {

  private alarmUrl:string;

  constructor(private http:AuthHttp, private activeProject:ActiveProjectService) {
    this.alarmUrl = MockCfg.currentalarmUrl + this.activeProject.id + "/statistics/current/namespace/" + this.activeProject.id;
  }

  freshAlarmNum(func:Function) {
    let that = this;
    that.http.get(that.alarmUrl).subscribe(
      res => {
        func(res);
      }
    )
  }
}
