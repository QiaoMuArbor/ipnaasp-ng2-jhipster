import {Component} from "@angular/core";
import {PanelComponent} from "../dashboard.panel.component";
import {DashboardChartOptionService} from "../chart.option.service";
import  {DashboardLogService} from './dashboard.log.service';

@Component({
  selector: 'log-chart',
  moduleId: module.id,
  directives: [PanelComponent],
  providers: [DashboardLogService],
  template: `
  <panel>
    <panel-title>日志配额</panel-title>
    <panel-body>
      <div class="echart" id="logChart"></div>
    </panel-body>
  </panel>`,
  styleUrls: ['../dashboard.chart.css']
})

export class LogChartComponent {
  private logChart:any;
  private freshTimer:any;
  private chartOption:any;
  private isHigh:boolean=false;
  constructor(private dashboardLogService:DashboardLogService) {
  }

  ngOnInit() {

    //初始化echarts表
    this.initEcharts();
  }

  initEcharts() {
    let that = this;
    that.logChart = echarts.init(document.getElementById('logChart'));
    that.chartOption=DashboardChartOptionService.getPieChartOption();
    that.logChart.setOption(that.chartOption); 
    that.freshTimer = setInterval(() => {
      that.freshLogValue();
    }, 1000);
  }

  freshLogValue() {
    let that=this;
    this.dashboardLogService.getLogQuotaData().subscribe(
      res=>{
        let used_capacity:number=0;
        if(res.tenant_id){
          if(res.used_capacity>=res.threshold){
             that.chartOption.series[0].data[0].value=res.threshold;
             that.chartOption.series[0].data[1].value=0;
             that.chartOption.series[0].data[1].name='';
          }else {
             that.chartOption.series[0].data[0].value=res.used_capacity;
             that.chartOption.series[0].data[1].value=res.threshold-res.used_capacity;
             this.chartOption.series[0].data[0].name=res.used_capacity>0 ?'已使用':'';
          }
          that.logChart.setOption(that.chartOption); 
        }
      });
  }

  ngOnDestroy() {
    if (this.freshTimer) {
      clearInterval(this.freshTimer);
    }
  }
}
