import {Component} from "@angular/core";
import {DashboardPmService} from "./dashboard.pm.service";

@Component({
  providers: [DashboardPmService],
})

export class DashboardChartService {

  freshTimer:any;

  constructor(public dashboardPmService:DashboardPmService) {
  }

  initChart(chart:any, metricType:string) {
    let that = this;
    that.dashboardPmService.initEchart(chart, metricType);
    that.freshPmValue(chart, metricType);
    that.freshTimer = setInterval(() => {
      that.freshPmValue(chart, metricType);
    }, 10000);
  }

  private freshPmValue(chart:any, metricType:string) {
    let that = this;
    that.dashboardPmService.freshDashboardPmInfo(chart, metricType);
  }

  ngOnDestroy() {
    clearInterval(this.freshTimer);
  }

}
