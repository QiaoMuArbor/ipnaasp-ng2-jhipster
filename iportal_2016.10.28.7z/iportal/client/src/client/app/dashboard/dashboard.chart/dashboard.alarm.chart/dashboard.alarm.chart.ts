import {Component} from "@angular/core";
import {Http} from "@angular/http";
import {AlarmService} from "./dashboard.alarm.service";

@Component({
  selector: 'alarm-chart',
  moduleId: module.id,
  providers: [AlarmService],
  templateUrl: 'dashboard.alarm.chart.html',
  styleUrls: ['dashboard.alarm.chart.css']
})

export class AlarmChartComponent {

  private alarmNum:number = 0;
  private freshTimer:any;
  private alarmInfos:Array<AlarmInfo>;

  constructor(public http:Http, private alarmService:AlarmService) {

  }

  ngOnInit() {
    let that = this;
    that.freshAlarmNum();
    this.freshTimer = setInterval(() => {
      that.freshAlarmNum();
    }, 10000);
  }

  private freshAlarmNum() {
    let that = this;
    that.alarmService.freshAlarmNum((res:any) =>{
      that.alarmNum = res.total;
      if (res.alarmType2Count == undefined) return;
      that.alarmInfos = res.alarmType2Count;
    });
  }

  ngOnDestroy() {
    clearInterval(this.freshTimer);
  }

}

class AlarmInfo {
  alarmType:string;
  count:number;

  constructor(alarmType:string, count:number) {
    this.alarmType = alarmType;
    this.count = count;
  }
}
