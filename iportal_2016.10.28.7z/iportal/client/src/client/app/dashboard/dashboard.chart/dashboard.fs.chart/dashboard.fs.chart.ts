import {Component} from "@angular/core";
import {PanelComponent} from "../dashboard.panel.component";
import {DashboardPmService} from "../dashboard.pm.service";
import {DashboardChartService} from "../dashboard.chart.service";

@Component({
  selector: 'fs-chart',
  moduleId: module.id,
  directives: [PanelComponent],
  providers: [DashboardPmService],
  template: `
  <panel>
    <panel-title>存储</panel-title>
    <panel-body><div class="echart" id="fsChart"></div></panel-body>
  </panel>`,
  styleUrls: ['../dashboard.chart.css']
})

export class FsChartComponent extends DashboardChartService {

  freshTimer:any;
  limitValue:number;

  constructor(public dashboardPmService:DashboardPmService) {
    super(dashboardPmService);
  }

  ngOnInit() {
    // let that = this;
    // let fsChart = echarts.init(document.getElementById('fsChart'));
    // that.initChart(fsChart, "fs");
  }

  ngOnDestroy() {
    clearInterval(this.freshTimer);
  }

}
