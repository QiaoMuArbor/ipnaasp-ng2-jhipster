import {Component} from "@angular/core";
import {PanelComponent} from "../dashboard.panel.component";
import {DashboardPmService} from "../dashboard.pm.service";
import {DashboardChartService} from "../dashboard.chart.service";

@Component({
  selector: 'cpu-chart',
  moduleId: module.id,
  directives: [PanelComponent],
  providers: [DashboardPmService],
  template: `
  <panel>
    <panel-title>CPU使用情况</panel-title>
    <panel-body><div class="echart" id="cpuChart"></div></panel-body>
  </panel>`,
  styleUrls: ['../dashboard.chart.css']
})

export class CpuChartComponent extends DashboardChartService {

  freshTimer:any;

  constructor(public dashboardPmService:DashboardPmService) {
    super(dashboardPmService);
  }

  ngOnInit() {
    let that = this;
    let cpuChart = echarts.init(document.getElementById('cpuChart'));
    that.initChart(cpuChart, "cpu");
  }

  ngOnDestroy() {
    clearInterval(this.freshTimer);
  }

}
