import {Component} from "@angular/core";

@Component({
  selector: 'panel',
  moduleId: module.id,
  template: `
  <div class="panel panel-success">
  <div class=" panel-heading">
    <h4 class="panel-title">
     <ng-content select='panel-title'></ng-content>
    </h4>
  </div>
  <div class="panel-body">
     <ng-content select='panel-body'></ng-content>
  </div>
  </div>`,
  styleUrls: ['dashboard.chart.css']
})

export class PanelComponent {

}
