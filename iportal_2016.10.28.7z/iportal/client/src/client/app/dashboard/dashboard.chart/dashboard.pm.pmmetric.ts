export class PmMetric {
	timestamp:string;
	value:string;
	constructor() {}
}