export class DashboardChartOptionService {

  private static toChinese(metricType:string):string {
    switch (metricType) {
      case "cpu":
        return "CPU";
      case "memory":
        return "内存";
      case "fs":
        return "存储";
      default:
        return '';
    }
  }

  private static getMetricUnit(metricType:string) {
    switch (metricType) {
      case "cpu":
        return "核数";
      case "memory":
        return "MB";
      case "fs":
        return "MB";
      default:
        return '';
    }
  }

  private static getStartRate(len:number) {
    if (len < 10)
      return 1;
    return 85;
  }

  private static getYAxisMaxValue(data:Array<string>) {
    let maxData:number = 0;
    data.forEach((d) => {
      if (maxData < parseInt(d))
        maxData = parseInt(d);
    });
    let temp = parseInt((maxData * 6 / 5).toFixed(1));
    return temp < 1 ? maxData : temp;
  }

  static getLoadingOption() {
    return {
      text: 'loading',
      color: 'rgba(30,144,255,0.2)',
      textColor: '#000',
      maskColor: 'rgba(255, 255, 255, 0.2)',
      zlevel: 0
    };
  }

  static getOption(data:Array<string>, lengend:Array<string>, metricType:string) {
    return {
      tooltip: {
        trigger: 'axis',
        formatter: '{b}<br/>' + DashboardChartOptionService.toChinese(metricType) + '使用: {c}' + DashboardChartOptionService.getMetricUnit(metricType)
      },
      grid: {
        left: '1%',
        right: '4%',
        bottom: '5%',
        top: '3%',
        containLabel: true
      },
      dataZoom: [
        {
          type: 'inside',
          start: DashboardChartOptionService.getStartRate(lengend.length),
          end: 100
        }
      ],
      xAxis: {
        type: 'category',
        boundaryGap: false,
        data: lengend,
        splitLine: {
          show: true,
          lineStyle: {
            color: ['#F8F8FA', '#F8F8FA']
          }
        },
        axisLine: {
          lineStyle: {
            color: 'rgba(234,234,227)',
          }
        },
        nameTextStyle: {
          fontSize: '12px',
          color: '#666'
        },
        axisTick: {
          interval: 'auto',
        },
        axisLabel: {
          interval: 'auto',
          margin: 10,
          textStyle: {
            color: "#A8A8A8",
            fontSize: 12
          }
        }
      },
      yAxis: {
        type: 'value',
        nameGap: 20,
        boundaryGap: false,
        splitLine: {
          show: true,
          lineStyle: {
            color: ['#F8F8FA', '#F8F8FA']
          }
        },
        nameTextStyle: {
          fontSize: 12,
          color: '#666'
        },
        axisLine: {
          lineStyle: {
            color: 'rgba(234,234,227)',
            onZero: false
          }
        },
        axisLabel: {
          show: true,
          interval: 0,
          formatter: '{value}' + DashboardChartOptionService.getMetricUnit(metricType),
          textStyle: {
            color: "#A8A8A8",
            fontSize: 12
          }
        },
        min: 0,
        max: DashboardChartOptionService.getYAxisMaxValue(data),
        splitNumber: 4,
      },
      series: [
        {
          type: 'line',
          smooth: true,
          itemStyle: {
            normal: {
              color: 'rgba(30,144,255,0.2)',
              lineStyle: {color: 'rgba(30,144,255,0.2)'}
            }
          },
          areaStyle: {normal: {color: 'rgba(30,144,255,0.2)'}},
          data: data
        }
      ]
    };
  }

  static getPieChartOption() {
    return  {
      tooltip: {
        trigger: 'item',
        formatter: "{b}: <br/> {c}Mb ({d}%)"
      },
      series: [
        {
          name:'日志配额',
          type:'pie',
          radius: ['50%', '90%'],
          avoidLabelOverlap: false,
          label: {
            normal: {
              position: 'inner'
            }
         },
          data:[
            {
              value:0,
              name:'',
              itemStyle:{normal:{color:'rgba(255, 0, 0, 0.5)'}}
            },
            {
              value:1024, 
              name:'未使用',
              itemStyle:{normal:{color:'rgba(34, 236, 9, 0.5)'}}
           }
          ]
        }
      ]
    };

  }
}
