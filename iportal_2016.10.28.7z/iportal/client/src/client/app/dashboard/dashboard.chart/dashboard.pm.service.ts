import {Injectable} from "@angular/core";
import {MockCfg} from "../../mock";
import {PmMetric} from "./dashboard.pm.pmmetric";
import {DashboardChartOptionService} from "./chart.option.service";
import {AuthHttp} from "../../shared/http/index";
import {ActiveProjectService} from "../../app.service";

@Injectable()
export class DashboardPmService {

  private chartData:Array<string> = [];
  private chartLegend:Array<string> = [];
  private metricsMap:Map<string,PmMetric> = new Map<string,PmMetric>();

  constructor(private http:AuthHttp
    , private activeProject:ActiveProjectService) {
  }

  initEchart(chart:any, metricType:string) {
    // chart.setOption(DashboardChartOptionService.getOption([], [], metricType));
    chart.showLoading('default', DashboardChartOptionService.getLoadingOption());
    this.getHistoryData(chart, metricType);
  }

  private getHistoryData(chart:any, metricType:string) {
    let that = this;
    that.handlePostHttp(500, function convertRes2PmMetrics(res:any) {
      let buckets:Array<any> = res.aggregations.group_by_metric_name.buckets;
      if (buckets == []) return;
      buckets.forEach((bucket:any) => {
        if (DashboardPmService.isBucketKeyContainsMetricType(bucket.key, metricType)) {
          let hits = bucket.top_value_hits.hits.hits;
          hits.forEach((hit:any) => {
            let source = hit._source;
            that.chartData.unshift(DashboardPmService.handleMetricData(metricType, source.value));
            that.chartLegend.unshift(DashboardPmService.getStandardDate(source.timestamp));
          });
        }
      });
      that.setChartOption(chart, metricType);
    });
  }

  private static isBucketKeyContainsMetricType(bucketKey:string, metricType:string) {
    return bucketKey.indexOf(metricType) > -1 && bucketKey.indexOf("request") < 0
    && bucketKey != "cpu_usage" && bucketKey.indexOf("limit") < 0;
  }

  private static handleMetricData(metricType:string, value:any) {
    switch (metricType) {
      case "cpu":
      return (parseInt(value) / 1000).toFixed(2).toString();
      case "memory":
      return (parseInt(value) / 1048576).toFixed(2).toString();
      default:
      return "";
    }
  }

  private setChartOption(chart:any, metricType:string) {
    let that = this;
    if (that.chartData.length < 1) return;
    chart.hideLoading();
    chart.setOption(DashboardChartOptionService.getOption(that.chartData, that.chartLegend, metricType));
  }

  freshDashboardPmInfo(chart:any, metricType:string) {
    let that = this;
    that.handlePostHttp(1, function convertRes2PmMetrics(res:any) {
      let buckets:Array<any> = res.aggregations.group_by_metric_name.buckets;
      buckets.forEach((bucket:any) => {
        let hits = bucket.top_value_hits.hits.hits;
        hits.forEach((hit:any) => {
          if (DashboardPmService.isBucketKeyContainsMetricType(hit._type, metricType)) {
            let source = hit._source;
            let pmMetric:PmMetric = {
              timestamp: source.timestamp, value: DashboardPmService.handleMetricData(metricType, source.value)
            };
            that.metricsMap.set(bucket.key, pmMetric);
          }
        });
      });
      that.freshChart(chart, metricType);
    });
  }

  private freshChart(chart:any, metricType:string) {
    let that = this;
    if (that.metricsMap.size == 0) return;
    let metricData = that.getMetricData(metricType);
    let metricTime = that.getMetricTime(metricType);
    if (metricData == undefined || that.hasNewMetricData(metricTime)) return;
    that.shiftChartData();
    that.chartData.push(metricData);
    that.chartLegend.push(metricTime);
    let option = DashboardChartOptionService.getOption(that.chartData, that.chartLegend, metricType);
    chart.hideLoading();
    chart.setOption(option);
  }

  private hasNewMetricData(metricTime:string):boolean {
    let that = this;
    let length = that.chartLegend.length;
    if (length < 1) return false;
    let tempTime:string = that.chartLegend[that.chartLegend.length - 1];
    return tempTime == undefined || tempTime == metricTime;
  }

  private shiftChartData() {
    let that = this;
    if (that.chartData.length > 500) {
      that.chartData.shift();
      that.chartLegend.shift();
    }
  }

  private getMetricData(metricType:string):string {
    let valueKey = metricType + '_usage';
    if (metricType == "cpu"){
      valueKey = "cpu_usage_rate";
    }
    return this.metricsMap.get(valueKey).value;
  }

  private getMetricTime(metricType:string):string {
    let valueKey = metricType + '_usage';
    if (metricType == "cpu"){
      valueKey = "cpu_usage_rate";
    }
    let time = this.metricsMap.get(valueKey).timestamp;
    return DashboardPmService.getStandardDate(time);
  }

  private static getStandardDate(timestamp:string):string {
    let date = new Date(timestamp);
    let month = date.getMonth() + 1;
    return date.getFullYear() + "/" + month + "/"
    + date.getDate() + " " + date.getHours()
    + ":" + date.getMinutes() + ":"
    + date.getSeconds();
  }

  private handlePostHttp(metricDataSize:number, resFunc:Function) {
    let that = this;
    that.http.post(MockCfg.eventUrl + "namespace_index/_search", this.getRequestlist(metricDataSize)).subscribe(
      res => {
        resFunc(res);
      });
  }

  private getRequestlist(metricDataSize:number) {
    return {
      "size": 0,
      "query": {"match": {"resourceTag.namespace_name": this.activeProject.id}},
      "aggs": {
        "group_by_metric_name": {
          "terms": {
            "field": "_type",
            "size": 100
          },
          "aggs": {
            "top_value_hits": {
              "top_hits": {
                "sort": [
                {
                  "timestamp": {
                    "order": "desc"
                  }
                }
                ],
                "_source": {
                  "include": [
                  "resourceTag.namespace_name",
                  "timestamp",
                  "value"
                  ]
                },
                "size": metricDataSize
              }
            }
          }
        }
      }
    };
  }

}
