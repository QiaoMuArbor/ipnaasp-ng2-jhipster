import {Injectable} from '@angular/core';

@Injectable()
export class NetOptionService {

  getOption() {
    let option = {
      tooltip: {
        trigger: 'axis'
      },
      grid: {
        left: '3%',
        right: '4%',
        bottom: '6%',
        containLabel: true
      },
      legend: {
        data: ['发送方向流量(bps)', '接收方向流量(bps)']
      },
      calculable: true,
      xAxis: [
      {
        type: 'category',
        boundaryGap: false,
        data: ['周一','周二','周三','周四','周五','周六','周日'],
        splitLine: {
          show: true,
          lineStyle: {
            color: ['#F8F8FA', '#F8F8FA']
          }
        },
        axisLine: {
          lineStyle: {
            color: 'rgba(234,234,227)',
          }
        },
        nameTextStyle: {
          fontSize: '12px',
          color: '#666'
        },
        axisLabel: {
          interval: 'auto',
          margin: 10,
          textStyle: {
            color: "#A8A8A8",
            fontSize: 12
          }
        }
      }
      ],
      yAxis: [
      {
        type: 'value',
        splitLine: {
          show: true,
          lineStyle: {
            color: ['#F8F8FA', '#F8F8FA']
          }
        },
        axisLine: {
          lineStyle: {
            color: 'rgba(234,234,227)',
          }
        },
        axisLabel: {
          show: true,
          textStyle: {
            color: "#A8A8A8",
            fontSize: 12
          }
        },
        min: '0',
        max: 'auto',
      }
      ],
      series: [
      {
        name: '接收方向流量(bps)',
        type: 'line',
        smooth: true,
        itemStyle: {
          normal: {
            color: 'rgba(30,144,255,0.2)',
            lineStyle: {color: 'rgba(30,144,255,0.2)'}
          }
        },
        data: [100,102,105,105,120,130,132],
      },
      {
        name: '发送方向流量(bps)',
        type: 'line',
        smooth: true,
        itemStyle: {
          normal: {
            color: '#22C36B',
            lineStyle: {color: '#22C36B'}
          }
        },
        data: [103,105,185,109,129,139,156],
      }
      ]
    };
    return option;
  }
}
