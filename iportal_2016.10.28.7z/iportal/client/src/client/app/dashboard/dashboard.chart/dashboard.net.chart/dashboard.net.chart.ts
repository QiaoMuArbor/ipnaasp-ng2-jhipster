import {Component} from "@angular/core";
import {PanelComponent} from "../dashboard.panel.component";
import {Http} from "@angular/http";
import {NetOptionService} from "./netchart.optionservice";

@Component({
  selector: 'net-chart',
  moduleId: module.id,
  directives: [PanelComponent],
  providers: [NetOptionService],
  template: `
  <panel>
    <panel-title>网络</panel-title>
    <panel-body><div class="echart" id="netChart"></div></panel-body>
  </panel>`,
  styleUrls: ['../dashboard.chart.css']
})

export class NetChartComponent {
  private netChart:any;

  constructor(public http:Http, private chartOption:NetOptionService) {

  }

  ngOnInit() {
    //初始化echarts表
    this.initEcharts();
  }

  initEcharts() {
    this.netChart = echarts.init(document.getElementById('netChart'));
    this.netChart.setOption(this.chartOption.getOption());
  }

}
