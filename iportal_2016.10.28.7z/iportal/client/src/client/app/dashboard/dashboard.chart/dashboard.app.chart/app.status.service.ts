import {Injectable} from '@angular/core';
import {MockCfg} from "../../../mock";
import {AuthHttp} from "../../../shared/http/index";
import {Observable} from 'rxjs/Observable';
import {ActiveProjectService} from "../../../app.service";


@Injectable()
export class AppStatusService {

	private appNum:any = " ";
	private runningAppNum:any  = " ";
	private srvRunningNum:number = 0;
	private msRunningNum:number = 0;
	private msListLength:number = 0;
	private srvListLength:number = 0;
	private srvUrl:string;
	private msUrl:string;

	constructor(private http:AuthHttp, private activeProject:ActiveProjectService) {
		this.srvUrl = MockCfg.vnpmUrl + this.activeProject.id + MockCfg.serviceurlsuffix;
		this.msUrl = MockCfg.vnpmUrl + this.activeProject.id + MockCfg.msserviceurlsuffix;
	}

	getAppStatus(func:Function) {
		let that = this;
		that.handleGetHttp(this.msUrl,function resFunc(res:any){
			if (res.ms_list == undefined) return;
			let msList:Array<any> = res.ms_list;
			that.msListLength = msList.length;
		//ms运行个数+srv运行个数
		that.msRunningNum = AppStatusService.getRunningNum(msList);
		that.getSrvRunningNum(func);
	}, function errFunc(err:any){
		that.getSrvRunningNum(func);
	})
	}

	private getSrvRunningNum(func:Function){
		let that = this;
		that.handleGetHttp(this.srvUrl,function resFunc(res:any){
			if (res.srv_list == undefined) return;
			let srvList:Array<any> = res.srv_list;
			that.srvListLength = srvList.length;
			that.appNum = that.srvListLength + that.msListLength;
			that.srvRunningNum = AppStatusService.getRunningNum(srvList);
			that.runningAppNum = that.srvRunningNum + that.msRunningNum;
			func(that.appNum,that.runningAppNum);
		}, function errFunc(err:any){
			that.appNum = that.srvListLength + that.msListLength;
			that.runningAppNum = that.srvRunningNum + that.msRunningNum;
			func(that.appNum,that.runningAppNum);
		})
	}

	private handleGetHttp(url:string, resFunc:Function, errFunc:Function) {
		let that = this;
		that.http.get(url).subscribe(
			res => {
				resFunc(res);
			},
			err => {
				errFunc(err);
			}
			)
	}

	private static getRunningNum(res:Array<any>):number {
		let runningNum = 0;
		for (let i = 0; i < res.length; i++) {
			if (res[i].run_status.toLowerCase().indexOf("running") > -1) {
				runningNum++;
			}
		}
		return runningNum;
	}

}
