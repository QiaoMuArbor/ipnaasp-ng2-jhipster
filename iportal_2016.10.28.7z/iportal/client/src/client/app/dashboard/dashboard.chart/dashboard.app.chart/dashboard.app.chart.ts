import {Component} from "@angular/core";
import {AppStatusService} from "./app.status.service";
import {Http} from "@angular/http";

@Component({
	selector: 'app-chart',
	moduleId: module.id,
	providers:[AppStatusService],
	templateUrl:'dashboard.app.chart.html',
	styleUrls: ['dashboard.app.chart.css']
})

export class AppChartComponent {

	private appNum:any = " ";
	private runningAppNum:any = " ";
	private stoppingAppNum:any = " ";
	private freshTimer:any;

	constructor(public http:Http, private appStatusService: AppStatusService) {

	}

	ngOnInit() {
		let that = this;
		that.freshAppNum();
		that.freshTimer = setInterval(() => {
			that.freshAppNum();
		}, 10000);
	}

	private freshAppNum() {
		let that = this;
		that.appStatusService.getAppStatus(
			function freshAppNum(appNum:any,runningAppNum:any){
				that.runningAppNum = runningAppNum;
				that.stoppingAppNum = appNum - runningAppNum;
				that.appNum = appNum;
			});
	}

	ngOnDestroy() {
		clearInterval(this.freshTimer);
	}

}
