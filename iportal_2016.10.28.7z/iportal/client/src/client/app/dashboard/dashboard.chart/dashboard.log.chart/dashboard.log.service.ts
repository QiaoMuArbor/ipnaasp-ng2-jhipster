import {Injectable} from '@angular/core';
import {MockCfg} from "../../../mock";
import {AuthHttp} from "../../../shared/http/index";
import {Observable} from 'rxjs/Observable';
import {ActiveProjectService} from "../../../app.service";
import {EventBroadcastService} from "../../../shared/event-broadcast.component";


@Injectable()
export class DashboardLogService {
  private commonUrl:string;
  
  constructor(private http:AuthHttp, 
  			  private activeProject:ActiveProjectService,
  		      private eventBroadcastService:EventBroadcastService) {
    this.commonUrl = MockCfg.logsUrl + '/v1/tenants/' + this.activeProject.id;
  }


  getLogQuotaData():Observable<{tenant_id:string,threshold:number, used_capacity:number}> {
    let url = this.commonUrl + '/usedcap';
    return this.http.get(url).map(
    	res=> {
    	return {
      	tenant_id: res.tenant_id,
        threshold: res.threshold,
      	used_capacity: res.used_capacity
    	}
	});
  }
}
