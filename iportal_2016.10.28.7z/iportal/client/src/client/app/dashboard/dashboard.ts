import {Component} from "@angular/core";
import {ActiveProjectService} from "../app.service";
import {AlarmChartComponent} from "./dashboard.chart/dashboard.alarm.chart/dashboard.alarm.chart";
import {AppChartComponent} from "./dashboard.chart/dashboard.app.chart/dashboard.app.chart";
import {CpuChartComponent} from "./dashboard.chart/dashboard.cpu.chart/dashboard.cpu.chart";
import {MemoryChartComponent} from "./dashboard.chart/dashboard.memory.chart/dashboard.memory.chart";
import {NetChartComponent} from "./dashboard.chart/dashboard.net.chart/dashboard.net.chart";
import {FsChartComponent} from "./dashboard.chart/dashboard.fs.chart/dashboard.fs.chart";
import {LogChartComponent} from "./dashboard.chart/dashboard.log.chart/dashboard.log.chart";
import {UserNameComponent} from "../user/username.component";
import {CommonTool} from "../appcenter/app.commontool";
import {AuthHttp} from "../shared/http/index";
import {UserService} from "../user/user.service";

@Component({
  selector: 'dashboard',
  moduleId: module.id,
  directives: [AlarmChartComponent, AppChartComponent, CpuChartComponent
    , MemoryChartComponent, NetChartComponent, FsChartComponent, UserNameComponent
    , LogChartComponent],
  templateUrl: 'dashboard.html',
  styleUrls: ['dashboard.css']
})

export class DashboardComponent {

  private createdAt:string;
  private projectUrl:string;
  private name:string;
  private employeeID:string;
  private description:string = '';
  private descriptionBack:string;
  private isShowAll:string = 'yes';

  constructor(public http:AuthHttp, public projectInfo:ActiveProjectService, public userService:UserService) {
    this.projectUrl = "/api/project/v1/projects/" + this.projectInfo.id;
  }

  ngOnInit() {
    let that = this;
    that.getProjectInfo();

  }

  getProjectInfo() {
    let that = this;
    that.http.get(that.projectUrl).subscribe(
      (res:any) => {
        that.createdAt = DashboardComponent.getGmtTime(res.createdAt);
        that.getUserInfo(res.owner);
        that.description = res.description;
        that.descriptionBack = that.description;
        if (that.description == '') {
          this.isShowAll = 'disappear';
        } else {
          if (that.description.length > 30) {
            that.isShowAll = 'part';
            that.description = '项目描述：' + that.description.substring(0, 30) + '...';
          } else {
            that.isShowAll = 'all';
            that.description = '项目描述：' + that.description;
          }
        }
      }
    )
  }

  look4All() {
    this.isShowAll = 'openall';
    this.description = '项目描述：' + this.descriptionBack;
  }

  notLook4All() {
    this.isShowAll = 'openpart';
    this.description = '项目描述：' + this.descriptionBack.substring(0, 30) + "...";
  }

  getUserInfo(UUID:string) {
    let that = this;
    that.userService.getById(UUID).subscribe(
      (res:any)=> {
        that.name = res.name;
        that.employeeID = res.employeeID;
      },
      err=> {
        console.log(err);
      }
    );
  }

  static getGmtTime(isoTime:string) {
    let gmtTime = new CommonTool().isoLocalTime(isoTime);
    return gmtTime.substr(0, 10);
  }

}
