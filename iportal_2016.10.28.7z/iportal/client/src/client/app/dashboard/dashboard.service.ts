import {Injectable} from "@angular/core";
import {ActiveProjectService} from "../app.service";
import {AuthHttp} from "../shared/http/index";


@Injectable()
export class DashboardService {
  private owner:string;
  private projectUrl:string;
  private createdAt:string;

  constructor(private http:AuthHttp, private activeProject:ActiveProjectService) {
    this.projectUrl = "/api/project/v1/projects/" + this.activeProject.id;
  }

  getOwner(func:Function) {
    let that = this;
    that.http.get(that.projectUrl).subscribe(
      (res:any) => {
        that.createdAt = res.createdAt;
        that.owner = res.owner;
        func(that.owner, that.createdAt);
      }
    )
  }
}
