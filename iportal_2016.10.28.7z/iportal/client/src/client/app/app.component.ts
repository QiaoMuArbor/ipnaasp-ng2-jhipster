import { Component } from '@angular/core';
import { ROUTER_DIRECTIVES } from '@angular/router';
import { EventBroadcastService,EventHandleComponent} from './shared/index';
import './rxjs-operators';
import * as _ from 'underscore';
@Component({
  selector: 'my-app',
  directives: [ROUTER_DIRECTIVES,EventHandleComponent],
  providers: [EventBroadcastService],
  template: `
    <router-outlet></router-outlet>
    <event-handle></event-handle>
  `
})

export class AppComponent {}
