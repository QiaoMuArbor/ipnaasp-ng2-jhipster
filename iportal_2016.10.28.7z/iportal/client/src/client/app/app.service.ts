import { Injectable }     from '@angular/core';
import {LocalStorageService} from './shared/localstorage.service';
import { UserService } from './user/user.service';

@Injectable()
export class ActiveProjectService {
  id:string;
  name: string;
  constructor(private userService:UserService){

  }
  setCurPrj(project: any) {
    this.name = project.name;
    this.id = project.id;
    let localStorageService=new LocalStorageService();
  	let userId = localStorageService.get('user',true).id;
    this.userService.setLastVisitPorject(userId,this.id)
    .subscribe(()=>{},error=>{console.log(error);});

  }
}
