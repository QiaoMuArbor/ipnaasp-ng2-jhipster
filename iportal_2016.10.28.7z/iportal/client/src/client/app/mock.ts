//import { Injectable } from '@angular/core';
/*var MockCfg:{} = { 'baseUrl': '/api/',
						  'swrV1Url': '/api/srepoworker/v1.0/',
						  'devUrl':"/api/dev/interface/",
						  'vnpmUrl':"/api/vnpm_deploy/v1.0/",
						  'somUrl':"/api/",
						  "orchUrl":"../"};*/


//@Injectable()

export class MockCfg {
	public static	baseUrl:string = '/api/';
  public static	swrV1Url:string = '/api/srepoworker/v1.0/';
	public static	swrVerUrl:string = '/api/swr/v1/tenants/';
	public static   swrUploadUrl:string = '/api/swr/slimage/upload';
	public static	devUrl:string = '/api/dev/interface/';
	public static	vnpmUrl:string = '/api/vnpm_deploy/v1/tenants/';
	public static	somUrl:string = '/api/';
	public static	pdmUrl:string = '/api/clusterworker/v1.0/';
	public static	orchUrl:string = '../';
	public static exportlogUrl:string = '/api/logfile/';
	public static   swrUrl:string = '/api/srepoworker/v1.0/1/images';

  public static currentalarmUrl:string = '/api/currentalarm/';
  public static logsUrl:string='/api/applogs';
  public static epsUrl:string='/api/eps/';
  public static terminalUrl:string='/api/terminal/';
  public static eventUrl:string='/api/event/';
  public static kpiUrl:string='/api/pm/';

  public static serviceurlsuffix:string='/services';
  public static msserviceurlsuffix:string='/microservices';
  public static podurlsuffix:string='/pods';


}
