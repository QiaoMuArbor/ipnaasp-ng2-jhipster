'use strict';

var port = process.argv[2] || 8100;

var restify = require('restify');

var common = require("./api/common.js");
var project = require("./api/project.js");
var auth = require("./api/auth.js");
var user = require("./api/user.js");
var dev = require("./api/dev.js");
var service = require("./api/service.js");
var msservice = require("./api/msservice.js");
var podservice =require("./api/podservice.js");
var appcenterother =require("./api/appcenterother.js");
var network = require("./api/network.js");
var bpDeploy = require("./api/blueprint-deploy.js");
var pipeline = require("./api/pipeline.js");
var pipelinedisplay = require("./api/pipelinedisplay.js")
var volume = require("./api/volume.js");
var winery = require("./api/winery.js");
var images = require("./api/imageservice.js");
var gitaccount = require("./api/gitaccount.js");
var mailconfig = require("./api/mailconfig.js");

var cluster = require("./api/cluster.js");

var commonService = require("./api/service-market.js");


var server = restify.createServer();
server.use(restify.queryParser());
server.use(restify.requestLogger());
server.use(restify.bodyParser());

server.use(
    function crossOrigin(req, res, next) {
        'use strict';
        res.header("Access-Control-Allow-Origin", "*");
        res.header("Access-Control-Allow-Headers", "X-Requested-With");
        //console.log(req);
        return next();
    }
);
//images
server.get("/api/swr/v1/tenants/:reponame/images", images["GET list"]);
server.get("/api/swr/v1/tenants/:reponame/images?", images["GET publiclist"]);
server.get("/api/swr/v1/tenants/:reponame/images/:id", images["GET imagedetail/:id"]);

//projects
server.post("/api/project/v1/projects", common["POST"]);
server.get("/api/project/v1/projects/:id", project["GET projects/:id"]);
server.get("/api/project/v1/users/:userId/projects", project["GET user-projects"]);
server.del("/api/project/v1/projects/:id", common["DELETE"]);
// projects member operator
server.get("/api/project/v1/projects/:projectId/members", project["GET projects/:id/members"]);
server.del("/api/project/v1/projects/:projectId/members/:member_id", common["DELETE"]);
server.post("/api/project/v1/projects/:projectId/members", common["POST"]);

// auth
server.post("/api/authen/v1/tokens", auth["POST auth/tokens"]);
server.post("/api/authen/v1/project-tokens", auth["POST authen/v1/project-tokens"]);
//users
server.get("/api/user/v1/indentify", user['GET indentify']);
server.get("/api/user/v1/users", user['GET users']);
server.get("/api/user/v1/users/:id", user['GET users/:id']);

//network
server.del("api/nw/v1/tenants/:tenantid/networks/:uuid", common["DELETE"]);
server.get("api/nw/v1/tenants/:tenantid/networks/:uuid", network["GET networks/:uuid"]);
server.get("api/nw/v1/tenants/:tenantid/networks", network["GET networks"]);
server.post("api/nw/v1/tenants/:tenantid/networks", common["POST"]);

//dev
server.put("/api/dev/v1/tenants/:tenantid/codebuilds/:codebuilduuid/onebuild", common["POST"]);
server.put("/api/dev/v1/tenants/:tenantid/codebuilds/:codebuilduuid", common["POST"]);
server.post("/api/dev/v1/tenants/:tenantid/codebuilds", common["POST"]);
server.get("/api/dev/v1/tenants/:tenantid/codebuilds/:codebuilduuid", dev['GET codebuild/:codebuilduuid']);
server.del("/api/dev/v1/tenants/:tenantid/codebuilds/:codebuilduuid", common["DELETE"]);
server.get("/api/dev/v1/tenants/:tenantid/codebuilds", dev['GET codebuilds']);
server.post("/api/dev/v1/tenants/:tenantid/frameworks", common["POST"]);
server.get("/api/dev/v1/tenants/:tenantid/frameworks", dev['GET allframeworks/:tenantid']);
server.del("/api/dev/v1/tenants/:tenantid/frameworks/:frameworkuuid", common["DELETE"]);
server.put("/api/dev/v1/tenants/:tenantid/frameworks/:frameworkuuid",common["POST"]);
//server.post("/api/dev/v1/tenants/:tenantid/selectedframework", common["POST"]);
server.get("/api/dev/v1/tenants/:tenantid/frameworks/:frameworkuuid", dev['GET frameworks/:frameworkuuid']);
//server.del("/api/dev/v1/tenants/:tenantid/selectedframework/:selectedframeworkuuid", common["DELETE"]);
server.get("/api/dev/v1/tenants/:tenantid/codebuilds/:codebuilduuid/instances", dev['GET instance/:codebuilduuid']);



//appcenter
server.get("/api/vnpm_deploy/v1/tenants/:tenantId/services", service["GET srvlist"]);
server.get("/api/vnpm_deploy/v1/tenants/:tenantId/services/:uuid", service['GET srvdetail']);

server.get("/api/vnpm_deploy/v1/tenants/:tenantId/microservices", msservice["GET mslist"]);
server.get("/api/vnpm_deploy/v1/tenants/:tenantId/microservices/:uuid", msservice["GET msdetail"]);

server.get("/api/vnpm_deploy/v1/tenants/:tenantId/pods/:uuid", podservice["GET poddetail"]);

server.post("/api/vnpm_deploy/v1/tenants/:tenantId/services",common["POST"]);
server.post("/api/vnpm_deploy/v1/tenants/:tenantId/microservices",common["POST"]);
server.get("/api/currentalarm/:tenantId/statistics/current/:type/:id",appcenterother["GET currentalarmnum"]);


//blueprint-deploy
server.get("api/swr/v1/tenants/:reponame/bps",bpDeploy["GET list"]);
server.del("api/swr/v1/tenants/:reponame/bps/:id",common["DELETE"]);
server.post("api/swr/v1/tenants/:reponame/bps", common["POST"]);
server.get("api/swr/v1/tenants/:reponame/bps/:id",bpDeploy["GET bpDetail"]);

//winery
server.get("/api/winery/API/templatesoverview/paas",winery["GET list"]);

//pipeline
server.post("/api/dev/v1/tenants/:tenant_id/pipelines",common["POST"]);
server.put("/api/dev/v1/tenants/:tenant_id/pipelines/:pipelineuuid",pipeline["PUT pipelines/:pipelineuuid"]);
server.get("/api/dev/v1/tenants/:tenant_id/pipelines/:pipelineuuid",pipeline["GET pipelines/:pipelineuuid"]);
server.del("/api/dev/v1/tenants/:tenant_id/pipelines/:pipelineuuid",common["DELETE"]);

server.get("/api/dev/v1/tenants/:tenant_id/pipelines",pipeline["GET pipelines"]);

//pipelinedisplay
server.get("/api/dev/v1/tenants/:tenant_id/pipelines/:pipelineuuid/currentinstances",pipeline["GET currentinstances"]);
// get pipeline histroy instance numbers
server.get("/api/dev/v1/tenants/:tenant_id/pipelines/:pipelineuuid/historyinstancenum",pipeline["GET historyinstancenum"]);
// get pipeline histroy instances
server.get("/api/dev/v1/tenants/:tenant_id/pipelines/:pipelineuuid/historyinstances",pipeline["GET historyinstances"]);
//enable or disable pipeline
server.put("/api/dev/v1/tenants/:tenant_id/pipelines/:pipelineuuid/pipelineoperation",pipeline["PUT pipelineoperation"]);
// gitcount
server.post("/api/dev/v1/tenants/:tenant_id/gitaccounts",common["POST"]);
server.get("/api/dev/v1/tenants/:tenant_id/gitaccounts",gitaccount["GET gitaccounts"]);
server.del("/api/dev/v1/tenants/:tenant_id/gitaccounts/:gitaccountuuid",common["DELETE"]);
//mailconfig
server.put("/api/dev/v1/tenants/:tenant_id/mailconfig",mailconfig["PUT mailconfig"]);
server.get("/api/dev/v1/tenants/:tenant_id/mailconfig",mailconfig["GET mailconfig"]);

//volume
server.get("/api/storage/v1/tenants/:tenantId/persistentvolumeclaims?tenantId=:tenantId&kubernetesId=:kubernetesId&namespace=:namespace",volume["GET persistentvolumeclaims"]);
server.get("/api/storage/v1/tenants/:tenantId/persistentvolumeclaims?tenantId=:tenantId&kubernetesId=:kubernetesId&namespace=:namespace&name=:name",volume["GET persistentvolumeclaims"]);
server.del("/api/storage/v1/tenants/:tenantId/persistentvolumeclaims?tenantId=:tenantId&kubernetesId=:kubernetesId&namespace=:namespace&fsType=ceph&name=:name" ,common["DELETE"]);
server.post("/api/storage/v1/tenants/:tenantId/persistentvolumeclaims?tenantId=:tenantId&kubernetesId=:kubernetesId&namespace=:namespacefsType=ceph", common["POST"]);
server.get("/api/storage/v1/tenants/:tenantId/kubernetes",volume["GET kubernetes"]);
server.post("/api/storage/v1/tenants/:tenantId/explorer/:pvcUuid",volume["POST mountInfo"]);
server.put("/api/storage/v1/tenants/:tenantId/persistentvolumeclaims?tenantId=:tenantId&kubernetesId=:kubernetesId&namespace=:namespace&fsType=ceph&name=:name", volume["PUT"]);
//server.post("/api/storage/v1/explore/persistentvolumeclaims?tenantId=:tenantId&kubernetesId=:kubernetesId&namespace=demo&name=:name", common["POST"]);
server.del("/api/storage/v1/tenants/:tenantId/explorer/:pvcUuid",common["DELETE"]);

//cluster
server.get("/api/clusterworker/v1/tenants/:tenant_id/labels",cluster["GET lables"]);


server.get("/api/storage/v1/tenants/:tenant_id/persistentvolumeclaims",volume["GET pvclist"]);

//csm market
server.get("/api/csmworker/v1/tenants/:tenantId/commonservices", commonService["GET commonservices"]);
server.get("/api/csmworker/v1/tenants/:tenantId/commonservices/:service_id",commonService["GET commonservice"]);
server.get("/api/csmworker/v1/tenants/:tenantId/csresources",commonService["GET csresources"]);
server.get("/api/csmworker/v1/tenants/:tenantId/csresources/:resource_id",commonService["GET csresource"]);

server.listen(port, function( /*req, res*/ ) {
    console.log('PorjectManager api server listening on port ' + port);
});
