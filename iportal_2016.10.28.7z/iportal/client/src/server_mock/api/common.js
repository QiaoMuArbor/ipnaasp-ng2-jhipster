
var opt = {};

opt["POST"] = function(req, res) {
    res.send(200,{});
}
opt["DELETE"] = function(req, res) {
    res.send(200,{});
}

module.exports = opt;