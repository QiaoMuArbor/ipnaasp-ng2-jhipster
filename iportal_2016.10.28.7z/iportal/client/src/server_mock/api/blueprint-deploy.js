var _ = require("underscore");
var db = require('../db/blueprint-deploy.json');

var opt = {};
for(var i=0;i< db.detail.list.length;i++) {
  db.detail.list[i].content=JSON.stringify(db.detail.list[i].content);
}
opt["GET list"] = function(req, res) {
if(req.params.reponame=='common'){

      if(req.params.name){
            res.send(200,db.namecommon);
        }else{
           res.send(200,db.common);
        }

 }else{
        if(req.params.name){
            res.send(200,db.namemy);
        }else{
           res.send(200,db.my);
        }
 }
}
opt["GET bpDetail"] = function(req, res) {
  if(req.params.id=='3'){
    db.detail.reponame='333';
  }
  if(req.params.id=='4'){
    db.detail.reponame='444';
  }
  res.send(200, db.detail)
}

module.exports = opt;