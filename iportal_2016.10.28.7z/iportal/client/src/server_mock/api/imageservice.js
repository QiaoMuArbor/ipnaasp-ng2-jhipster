var _ = require("underscore");
var db = require('../db/imagelist.json');
var detail = require('../db/imagesdetaillist.json');

var opt = {};

opt["GET list"] = function(req, res) {
console.log(req.params);
	if(req.params.reponame=='tcfs' && req.params.publicview == 'yes'){
	    res.send(200,db.public);
	}
	if(req.params.reponame=='tcfs'){
	    res.send(200,db.tcfs);
	}
	if(req.params.reponame=='public'){
	    res.send(200,db.public);
	}
}

opt["GET publiclist"] = function(req, res) {
	    res.send(200,db.public);
}
opt["GET imagedetail/:id"] = function(req, res) {

	res.send(200, detail[req.params.id]);
}

// opt["upload image/:id"] = function(req, res) {

// 	res.send(200, {});
// }
// opt["build image/:id"] = function(req, res) {

// 	res.send(200, {});
// }

// opt["updata describe/:id"] = function(req, res) {
	
// 	console.log(req.params.body);
// 	res.send(200, {});
// }
module.exports = opt;