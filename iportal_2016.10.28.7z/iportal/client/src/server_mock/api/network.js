var _ = require("underscore");
var db = require('../db/network.json');

var opt = {};

opt["GET networks/:uuid"] = function(req, res) {
    res.send(200, {
        network: db.network
    });
}

opt["GET networks"] = function(req, res) {
    res.send(200, {
        networks: db.networks
    });
}
module.exports = opt;
