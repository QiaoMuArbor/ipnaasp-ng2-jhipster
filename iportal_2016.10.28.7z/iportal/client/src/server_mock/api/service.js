var _ = require("underscore");
var db = require('../db/service_list.json');
var db2 = require('../db/servicedetail_list.json');

var opt = {};

opt["GET srvdetail"] = function(req, res) {
  res.send(200, db2[req.params.uuid]);
}
opt["GET srvlist"] = function(req, res) {
  res.send(200, db)
}

module.exports = opt;
