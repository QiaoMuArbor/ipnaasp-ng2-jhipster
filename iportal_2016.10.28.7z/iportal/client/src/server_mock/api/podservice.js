var _ = require("underscore");
var db = require('../db/pod_list.json');

var opt = {};

opt["GET poddetail"] = function(req, res) {
  res.send(200, db[req.params.uuid]);
}

module.exports = opt;
