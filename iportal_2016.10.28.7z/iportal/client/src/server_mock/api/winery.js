var _ = require("underscore");
var db = require('../db/winery.json');

var opt = {};

opt["GET list"] = function(req, res) {
  console.log(req.params.project);
       res.send(200, db.data);

}


module.exports = opt;