var _ = require("underscore");
var db = require('../db/user.json');

var opt = {};

opt["GET users/:id"] = function(req, res) {
    res.send(200, db.userDetail);
}
opt["GET users"] = function(req, res) {
    res.send(200, db.users)
}

opt['GET indentify'] = function(req, res){
	res.send(200,{indentify:'ldap'});
}

module.exports = opt;