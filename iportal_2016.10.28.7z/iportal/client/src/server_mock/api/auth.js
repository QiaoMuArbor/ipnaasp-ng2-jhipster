var opt = {};

opt["POST auth/tokens"] =function(req, res, next) {
    res.send(200,{'access_token':'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VySWQiOiJhZGQzYmNmOS1mMmEzLTRiOGYtOTZiYS0wZWI3NDEwZjM3OWMiLCJyb2xlcyI6WyJ1c2VyIl0sImV4cCI6MTQ3NjM1ODAyMTcwMH0.gxEUToPA4jm5uR5sw5CV2pATS5vJ-KyWo8AsCGDIF0w','user':{'id':'10110527','name':'nuonuoge','userName':'10110527','employeeID':'10110527'}})
    next()
}
opt["POST authen/v1/project-tokens"] =function(req, res, next) {
    res.send(200,{'access_token':'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VySWQiOiJhZGQzYmNmOS1mMmEzLTRiOGYtOTZiYS0wZWI3NDEwZjM3OWMiLCJyb2xlcyI6WyJ1c2VyIiwicHJvamVjdC1vd25lciIsInByb2plY3QtbWVtYmVyIl0sInByb2plY3RJZCI6InRjZnMiLCJleHAiOjE0NzYzNTgwMjE3MDB9.O-ZM55QfIn6ipu98jJ6EBUgVMWnOaYOw426LdhACuwc'})
    next()
}

module.exports = opt;
