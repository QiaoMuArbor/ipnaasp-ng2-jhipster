var _ = require("underscore");
var db = require('../db/volume.json');

var opt = {};

opt["GET persistentvolumeclaims"] = function(req, res) {
   if(req.params['name']==null)
   {
   	 res.send(200, db.persistentvolumeclaims);
   }else
   {
   	 res.send(200, db.persistentvolumeclaim);
   }
  
}

opt["GET kubernetes"] = function(req, res) {
    res.send(200, db.uuids);
}

opt["POST mountInfo"] = function(req, res) {
    res.send(200, db.mountInfo);
}

opt["PUT"] = function(req, res) {
    res.send(200, {});
}
opt["GET pvclist"] = function(req, res) {
    res.send(200, db.pvclist);
}

module.exports = opt;