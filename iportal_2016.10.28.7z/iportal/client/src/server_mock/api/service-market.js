var _ = require("underscore");
var commonserviceDb = require('../db/service-market-commonservices.json');
var resourcesDb = require('../db/service-maket-resources.json');

var opt = {};

opt["GET commonservices"] = function(req, res) {
  res.send(200, commonserviceDb);
}

opt["GET commonservice"] = function (req, res) {
  var commonservice = _.find(commonserviceDb.services,function (item) {
    return item.service_id == req.params.service_id;
  })
  res.send(200 ,commonservice)
}

opt["GET csresources"] = function(req, res) {

  res.send(200, resourcesDb);
}

opt["GET csresource"] = function(req, res) {
  let resource = _.find(resourcesDb.resources,function (item) {
    return item.resource_id == req.params.resource_id;
  })
  res.send(200, resource);
}

module.exports = opt;
