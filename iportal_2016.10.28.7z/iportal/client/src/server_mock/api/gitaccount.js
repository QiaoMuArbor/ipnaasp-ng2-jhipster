var _ = require("underscore");
var db = require('../db/gitaccount.json');
var opt = {};

opt["GET gitaccounts"] = function(req, res) {
     res.send(200, db.gitaccountlist);
}

module.exports = opt