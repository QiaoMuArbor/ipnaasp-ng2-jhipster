var _ = require("underscore");
var db = require('../db/mailconfig.json');
var opt = {};

opt["PUT mailconfig"] = function(req, res) {
		 res.send(200, {});
}

opt["GET mailconfig"] = function(req, res) {
    res.send(200, db.mailconfig);
}

module.exports = opt;