var _ = require("underscore");
var db = require('../db/dev.json');

var opt = {};

opt["GET codebuild/:codebuilduuid"] = function(req, res) {
    res.send(200, db.codebuildinfo);
}

opt["GET codebuilds"] = function(req, res) {
    res.send(200, db.codebuildlist);
}

opt["GET allframeworks/:tenantid"] = function(req, res) {
    res.send(200, db.frameworks);
}
opt['GET frameworks/:frameworkuuid']= function(req, res) {
    res.send(200, db.selectedframework);
}

opt["GET instance/:codebuilduuid"] = function(req, res) {
    res.send(200, db.instance);
}
module.exports = opt;