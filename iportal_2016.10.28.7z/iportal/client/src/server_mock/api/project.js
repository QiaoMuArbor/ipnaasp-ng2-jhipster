var _ = require("underscore");
var db = require('../db/project.json');

var opt = {};

opt["GET projects/:id"] = function(req, res) {
    res.send(200, db.projectDetail);
}

opt["GET user-projects"] = function(req, res) {
    res.send(200, db.projects);
}

opt["GET projects/:id/members"] = function(req, res) {
    res.send(200,db.projectMembers);
}

module.exports = opt;