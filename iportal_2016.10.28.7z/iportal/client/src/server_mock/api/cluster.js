var _ = require("underscore");
var db = require('../db/cluster.json');

var opt = {};

opt["GET lables"] = function(req, res) {
    res.send(200, db.lables);
}
module.exports = opt;