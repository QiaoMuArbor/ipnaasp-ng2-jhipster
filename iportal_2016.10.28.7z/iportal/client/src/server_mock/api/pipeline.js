var _ = require("underscore");
var db = require('../db/pipeline.json');
var pipelineinstances =  require('../db/pipelineinstances.json')

var opt = {};

opt["GET pipelines"] = function(req, res) {
		 res.send(200, db.pipelinelist);
}

opt["GET pipelines/:pipelineuuid"] = function(req, res) {
    res.send(200, db.pipelineinfo);
}

opt["PUT pipelines/:pipelineuuid"] = function(req, res) {  
    res.send(200, {});
}

opt["PUT pipelineoperation"] = function(req, res) {  
    res.send(200, {});
}
opt["GET currentinstances"] = function (req, res) {
  console.log("get pipelinedisplay")
  res.send(200,pipelineinstances)

}
opt["GET historyinstancenum"] = function (req, res) {
 if(req.params.starttime&&req.params.endtime){
 	res.send(200,{})
 }
  

}
opt["GET historyinstances"] = function (req, res) {

  if(req.params.starttime&&req.params.endtime&&req.params.pageno&&req.params.perage){
 	res.send(200,{})
   }

}


/*opt["GET allframeworks/:projectname"] = function(req, res) {
    res.send(200, db.frameworks);
}

opt["GET selectedframeworks/:projectname"] = function(req, res) {
    res.send(200, db.selectedframeworks);
}

opt["GET instance/:uuid"] = function(req, res) {
    res.send(200, db.instance);
}*/
module.exports = opt;