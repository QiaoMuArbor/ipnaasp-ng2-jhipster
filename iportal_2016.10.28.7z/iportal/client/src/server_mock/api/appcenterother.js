var _ = require("underscore");

var opt = {};

opt["GET currentalarmnum"] = function(req, res) {
  res.send(200, {total:0});
}


module.exports = opt;
