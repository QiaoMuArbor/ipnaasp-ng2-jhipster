var _ = require("underscore");
var db = require('../db/msservice_list.json');
var db2 = require('../db/msservicedetail_list.json');

var opt = {};

opt["GET msdetail"] = function(req, res) {
  res.send(200, db2[req.params.uuid]);
}
opt["GET mslist"] = function(req, res) {
  res.send(200, db)
}

module.exports = opt;
