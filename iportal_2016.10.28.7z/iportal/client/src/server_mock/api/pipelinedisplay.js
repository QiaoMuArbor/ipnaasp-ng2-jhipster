var pipelineinstances =  require('../db/pipelineinstances.json')

var opt = {};

opt["GET pipelineinstances"] = function (req, res) {
  console.log("get pipelinedisplay")
  res.send(200,pipelineinstances)

}

module.exports = opt;

