#! /bin/sh
gulp build.prod
if [ -f "./dist/prod/index.html" ]; then 
  echo "build success!"
  exit 0
else
  echo "build failure!" 
  exit 1
fi 
