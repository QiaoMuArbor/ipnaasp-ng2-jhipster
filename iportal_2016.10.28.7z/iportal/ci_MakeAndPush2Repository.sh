#!/bin/bash

if [ -z "$1" ]; then
  echo "Missing input argument: ChangeID!"
  exit 1
fi
ChangeID="$1"
srcliIp="$2"
VersionNo="$3"
# Please do not mofify above code!

echo "Begin MakeAndPush2Repository"
# Do your action below:
# Please do "exit 0" when everything is ok or "exit 1" when something fails.
# Note: $ChangeID should be added to the version number, e.g. version_no=$version_$ChangeID
CurPath=`pwd`
DockerPath=${CurPath}/docker
cd ${DockerPath} && \
./upload_tar_main.sh all $ChangeID $VersionNo $srcliIp

echo "MakeAndPush2Repository Ends"
exit 0
