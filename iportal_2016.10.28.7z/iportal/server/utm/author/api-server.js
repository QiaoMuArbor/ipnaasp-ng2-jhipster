'use strict';
var port = process.argv[2] || 8103;

var express = require('express');
var bodyParser = require('body-parser');

var author = require("./author.js");
var role = require("./role.js");

var app = express();
var router = express.Router();

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));

app.use(
	function crossOrigin(req, res, next) {
		'use strict';
		res.header("Access-Control-Allow-Origin", "*");
		res.header("Access-Control-Allow-Headers", "X-Requested-With");
		return next();
	}
);

/*
author/v1/verify-url/需要鉴权的url
注意，把原有的请求消息头直接转发过来即可，包括请求method和token信息
*/

author.buildVerifyUrl(app,'/author/v1/');

app.get('/author/v1/project-roles',function(req,res){
	res.status(200).json({roles:role.getByType('project')})
});


// 将路由挂载至应用
app.use('/', router);



var server = app.listen(port, function () {
  var host = server.address().address;
  var port = server.address().port;

  console.log('Author api server listening at http://%s:%s', host, port);
});