var _ = require("underscore");
var _db = require("underscore-db");

_.mixin(_db);
var dbFile = '../config/author-db.json';
var db = _.load(dbFile);

var opt = {};

/*
url 方法对应的权限列表，从权限列表中反构出来
[
	{
		"url":"xxx/xx/xx",
		"methods":[
			{
				"name":"get",
				"permissions":[]
			}
		]
	}
]
*/
var urlsPermission = [];

opt.get = function() {
	return db.permissions || [];
}
opt.getUrlsPermission = function() {
	return urlsPermission;
}

function buildUrlsPermission() {
	var permissions = db.permissions;
	_.each(permissions, function(_permission) {
		buildUrlsPermissionFromPermission(_permission);
	});
}

function buildUrlsPermissionFromPermission(_permission) {
	_.each(_permission.resources, function(_resource) {
		buildUrlsPermissionFromPermissionResource(_resource, _permission.name);
	});
}

function buildUrlsPermissionFromPermissionResource(_resource, permission) {
	var isNew = false;
	var url = _.findWhere(urlsPermission, {
		url: _resource.url
	});
	if (!url) {
		isNew = true;
		url = {
			"url": _resource.url,
			"methods": []
		};
	}
	_.each(_resource.methods, function(method) {
		if (method === '*') {
			addPerissionToUrlMethod(url, 'post', permission);
			addPerissionToUrlMethod(url, 'delete', permission);
			addPerissionToUrlMethod(url, 'put', permission);
			addPerissionToUrlMethod(url, 'patch', permission);
			addPerissionToUrlMethod(url, 'get', permission);
			addPerissionToUrlMethod(url, 'head', permission);
		} else {
			addPerissionToUrlMethod(url, method, permission);
		}
	});
	if (isNew) {
		urlsPermission.push(url);
	}
}

function addPerissionToUrlMethod(url, _method, permission) {
	_method = _method.toLowerCase();
	var isNew = false;
	var method = _.findWhere(url.methods, {
		name: _method
	});
	if (!method) {
		isNew = true;
		method = {
			name: _method,
			permissions: []
		}
	}
	if (_.indexOf(method.permissions, permission) === -1) {
		method.permissions.push(permission);
	}
	if (isNew) {
		url.methods.push(method);
	}
}

buildUrlsPermission();
//console.log(urlsPermission);

module.exports = opt;