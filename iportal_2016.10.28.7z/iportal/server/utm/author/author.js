var base64 = require('base64-coder-node')();
var _ = require("underscore");

var permission = require('./permission.js');
var role = require('./role.js');

var opt = {};

opt.buildVerifyUrl = function(app, apiPrefix) {

	var urlsPermission = permission.getUrlsPermission();
	_.each(urlsPermission, function(urlPermission) {
		_.each(urlPermission.methods, function(methodPermissions) {
			app[methodPermissions.name](apiPrefix + 'verify-url/' + urlPermission.url, function(req, res) {
				if (!req.headers['access-token']) {
					return res.status(401).json({
						message: '没有权限'
					}).end();
				}
				if (req.headers['access-token'].split('.').length!=3) {
					return res.status(401).json({
						message: '没有权限0'
					}).end();
				}
				var payload = JSON.parse(base64.decode(req.headers['access-token'].split('.')[1]));
				//console.log(payload);
				//var payload = {projectId:'',userId:'',roles:[]};
				//console.log("1"+req.params.projectId+"1",payload,payload.projectId != req.params.projectId,method.permissions);

				/*  如果有 projectId 判断是否与token中的项目id匹配  */
				if (req.params.projectId && payload.projectId != req.params.projectId) {
					return res.status(401).json({
						message: '没有权限1'
					}).end();
				}
				/*  如果有 userId 判断是否与token中的用户id匹配  */
				if (req.params.userId && payload.userId !== req.params.userId) {
					return res.status(401).json({
						message: '没有权限2'
					}).end();
				}
				
				/*  判断token中的角色是否有这些权限 */
				if (!role.allowedPermissions(payload.roles, methodPermissions.permissions)) {
					return res.status(401).json({
						message: '没有权限3'
					}).end();
				}
				return res.status(204).end();
			});
		});
	});
	app.all(apiPrefix + 'verify-url/*', function(req, res) {
		res.status(401).json({
			message: '没有权限4'
		}).end();
	});
}

module.exports = opt;
