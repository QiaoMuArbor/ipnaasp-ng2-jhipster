var _ = require("underscore");
var _db = require("underscore-db");

_.mixin(_db);
var dbFile = '../config/author-db.json';
var db = _.load(dbFile);

var opt = {}

opt.get = function() {
	return db.roles || [];
}
opt.getByType = function(type) {
	return _.where(db.roles || [],{type:type});
}
opt.allowedPermissions = function(roles,permissions){
	roles = roles||[];
	for (var i = roles.length - 1; i >= 0; i--) {
		if(opt.hasPermissions(roles[i],permissions)){
			return true;
		}
	}
	return false;
}
opt.hasPermissions = function(roleId, permissions) {
	var role = _.findWhere(db.roles, {
		id: roleId
	});
	if (!role) {
		return false;
	}
	var sameValues = _.intersection(role.permissions, permissions);
	if (sameValues.length == 0) {
		return false;
	}
	return true;
}

module.exports = opt;