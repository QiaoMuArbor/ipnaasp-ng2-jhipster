var url = require("url");

var _ = require("underscore");
var _db = require("underscore-db");
var restify = require('restify');
var log4js = require('log4js');
var logger = log4js.getLogger();


var pdm = require('../../config/config.json').pdm;
var log = require('../../config/config.json').log;
var network = require('../../config/config.json').network;

//用bluebird实现异步调用，避免回调函数问题...
var Promise = require("bluebird");

_.mixin(_db);

var dbFile = '../config/project-db.json';
var db = _.load(dbFile);

var pdmClient = restify.createJsonClient({
    url: pdm.host
});

var logClient = restify.createJsonClient({
    url: log.host
});

var networkClient = restify.createJsonClient({
    url: network.host
});


var opt = {};

opt.getByName = function(name) {
    return _.filter(db.projects,function(item){
        return item.name == name;
    }).length;
}

opt.addProject = function(project,cb) {
    
    pdmClient.post('/clusterworker/v1/tenants/admin/ns',{"namespace":project.id}, function(err, creq, cres, obj) {
        if (err) {
            logger.trace('创建命名空间失败 error:',err);
            return cb(err);
        };
        //创建日志配额...
        logClient.post('/log/v1/tenants/'+project.id+"/quota?threshold=1024",{"tenant_id":project.id,"threshold:":1024}, function(err, creq, cres, obj) {
            if (err){
                logger.trace('创建日志配额失败 error :',err);

                return cb(err);
            };
            //创建网络..
         networkClient.post('/nw/v1/tenants/'+project.id+'/networks',{"network": {"name": "lan","gateway": "123.124.125.1", "cidr": "123.124.125.0/24"}}, function(err, creq, cres, obj) {
            if (err){
                logger.trace('创建网络失败 error:',err);
                return cb(err);
            };
    
            project.createdAt = new Date().getTime();
            var newProject = _.insert(db.projects, project);
            _.save(db, dbFile);
            logger.trace('创建项目成功！');

            return cb(null,newProject);});
        });

    });
}

opt.getProjectMembers = function(projectId) {
    var project = _.find(db.projects, function(item) {
        return item.id == projectId;
    });
    if (!project) {
        return [];
    }
    return project.members;
}

opt.getProjectMembersByMemberId = function(projectId,memberId) {
    var project = _.find(db.projects, function(item) {
        return item.id == projectId;
    });
    if(!project) {
        return false;
    }
    var member = _.find(project.members, function(item) {
        return item.id == memberId;
    });
    if(!member){
        return false;
    }
    return member;
}

opt.updateProjectMembersByMemberId = function(projectId,memberId,roles) {
    var project = _.find(db.projects, function(item) {
        return item.id == projectId;
    });
    if (!project) {
        return false;
    }
    var index = undefined;
    for(var i=0;i<project.members.length;i++){
        if(project.members[i].id == memberId){
            index = i;
        }
    }
    if(!index){
        return false;
    }
    project.members[index].roles = roles;
    _.updateById(db.projects, project.id, project);
    _.save(db, dbFile);
    return true;
}

opt.delProjectMembers = function(projectId, memberId) {
    var project = _.findWhere(db.projects, {
        id: projectId
    });
    project.members = _.filter(project.members, function(item) {
        return item.id != memberId;
    });
    _.updateById(db.projects, project.id, project);
     _.save(db, dbFile);
    return true;

    // _.save(db, dbFile);
}

opt.addProjectMembers = function(projectId,member){
     var project = _.findWhere(db.projects, {
         id: projectId
     });
     var  result = _.find(project.members,function(item){
        return item.id == member.id;
      });
     if(!result){
        project.members.push(member);
     _.updateById(db.projects, project.id, project); 
      _.save(db, dbFile);
     return true;
     }
    return false;
}

opt.getByUserId = function(userId,role,notHave){
    var projects = _.filter(db.projects, function(project) {
        var user = _.findWhere(project.members, {
            id: userId
        });
        if (!user) {
            return false;
        }
        if (!notHave) {
            if (role && -1 == _.indexOf(user.roles, role)) {
                return false;
            } 
        }else{
            if (role && -1 != _.indexOf(user.roles, role)) {
                return false;
            }
        }
        
        return true;
    });
    return projects;
}

opt.getById = function(projectId) {
    var project = _.findWhere(db.projects, {
        id: projectId
    });
    return project;
}

function delNetwork(id,cb){
    networkClient.get("/nw/v1/tenants/"+id+"/network",function(err,creq,cres,obj){
        var body = creq.body;
        var loop = 0;
        if(!body.networks || body.networks.length < 1){
            return cb(null,id);
        }
        _.each(body.networks,function(network){
            networkClient.del('/nw/v1/tenants/'+id+'/networks'+network.network_id, function(err, creq, cres, obj) {
                if (err) {
                    logger.trace('删除网络失败 error:',err);
                    return cb(err);
                }
                loop += 1;
                if(loop == body.networks.length){
                    return cb(null,id);
                }

            });
    });
});
}

opt.delById = function(id,cb) {
        
    delNetwork(id,function(err,id){
        if(err){
            logger.trace('删除网络失败 error:',err);
            return cb(err);
        }
        logClient.del('/log/v1/tenants/'+id+'/quota', function(err, creq, cres, obj) {
            if (err) {
                logger.trace('删除租户日志配额失败 error:',err);
                return cb(err);
            }
            pdmClient.del('/clusterworker/v1.0/1/ns/'+id, function(err, creq, cres, obj) {
                if (err) {
                    logger.trace('删除命名空间失败 error :',err);
                    return cb(err);
                }

                var project = _.removeById(db.projects, id);
                _.save(db, dbFile);

                logger.trace('删除项目成功！');
                return cb(null,project);

            });

        });

    });
}

opt.updateById = function(projectId,data) {
    var project = _.updateById(db.projects,projectId, data);
    _.save(db, dbFile);
    return project;
}

module.exports = opt;
