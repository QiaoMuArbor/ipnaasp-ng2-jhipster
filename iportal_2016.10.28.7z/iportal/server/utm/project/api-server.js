'use strict';

var port = process.argv[2] || 8104;
var restify = require('restify');
var project = require("./api/project.js")

var server = restify.createServer();
server.use(restify.queryParser());
server.use(restify.requestLogger());
server.use(restify.bodyParser());

server.use(
	function crossOrigin(req, res, next) {
		'use strict';
		res.header("Access-Control-Allow-Origin", "*");
		res.header("Access-Control-Allow-Headers", "X-Requested-With");
		return next();
	}
);


server.post("/project/v1/projects",project["POST projects"]);
server.del("/project/v1/projects/:projectId",project["DELETE projects"]);
server.patch("/project/v1/projects/:projectId",project["PATCH projects"]);
server.get("/project/v1/projects/:projectId",project["GET projects detail"]);
server.get("/project/v1/users/:userId/projects",project["GET users projects"]);
server.post("/project/v1/projects/:projectId/members",project["POST project members"]);
server.del("/project/v1/projects/:projectId/members/:memberId",project["DELETE project members"]);
server.put("/project/v1/projects/:projectId/members/:memberId",project["PUT project members"]);
server.get("/project/v1/projects/:projectId/members",project["GET project members"]);
server.get("/project/v1/projects/:projectId/members/:memberId",project["GET project one member"]);




// //creat project
// server.post("/api/projects", project["POST projects"]);
//
// //get project config
// server.get("/api/projects/:id", project["GET projects/:id"]);
// server.get("/api/projects", project["GET projects"]);
// server.del("/api/projects/:id", project["DELETE projects/:id"]);
// server.post("/api/project-subscribes", project["POST project-subscribes"]);
// server.del("/api/project-subscribes/:id", project["DELETE project-subscribes/:id"]);
// server.get("/api/-subscribes", project["GET project-subscribes"]);
//
// // projects member operator
// server.get("/api/projects/:id/members", project["GET members"]);
// server.del("/api/projects/:id/members/:member_id", project["DELETE members/:member_id"]);
// server.post("/api/projects/:id/members", project["POST members"]);

server.listen(port, function( /*req, res*/ ) {
	console.log('PorjectManager api server listening on port ' + port);
});