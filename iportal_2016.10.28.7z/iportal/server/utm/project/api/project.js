var projects = require('../project/project.js');
var base64 = require('base64-coder-node')();
var uuid = require('node-uuid');

var opt = {};
opt["POST projects"] = function(req, res) {
    var project = {};

    if (projects.getById(req.body.id)) {
        res.send(409, {
            message: '项目ID已存在,请修改后重试!'
        });
        return;
    }
    var userId = JSON.parse(base64.decode(req.headers['access-token'].split('.')[1])).userId;
    project.name = req.body.name;
    project.description = req.body.description;
    project.id = req.body.id;
    project.owner = userId;
    project.members = [{
        'id': userId,
        'roles': ['project-owner'],
        'createdAt': new Date().getTime()
    }];
    project.self = "/project/v1/projects/" + project.id;
    projects.addProject(project,function(err,newProject){
        if (err) {
            res.send(500, {error:err});
        }
        res.send(200, newProject);
    });
}


opt["DELETE projects"] = function(req, res) {
    var project = projects.getById(req.params.projectId);
    if (!project) {
        res.send(409, {
            'message': '项目不存在!'
        });
    }
    try {
        projects.delById(req.params.projectId,function(err){
            if(err){
                res.send(500, {
                    error: err
                });
            }
            res.send(200, {});
        });
        
    } catch (e) {
        res.send(500, {
            error: e
        });
    }
}

opt["PATCH projects"] = function(req, res){
    var project = projects.getById(req.params.projectId);
    if (!project) {
        res.send(409, {
            'message': '项目不存在!'
        });
    }
    try {
        projects.updateById(req.params.projectId,req.body);
        res.send(200, {});
    } catch (e) {
        res.send(500, {
            error: e
        });
    }
}

opt["GET projects detail"] = function(req, res) {
    var project = projects.getById(req.params.projectId);
    if (!project) {
        res.send(409, {
            'message': '项目不存在!'
        });
        return;
    }
    res.send(project);
}

opt["GET users projects"] = function(req, res){
    var filter = req.query.filter;
    if(!filter){
        res.send(projects.getByUserId(req.params.userId));
    }
    if (filter =='my-created') {
        res.send(projects.getByUserId(req.params.userId,'project-owner'));
    }
    else{
        res.send(projects.getByUserId(req.params.userId,'project-owner',true));
    }
   
}

opt["GET project members"] = function(req, res) {
    var projectId = req.params.projectId;
    res.send(projects.getProjectMembers(projectId));
}

opt["GET project one member"] = function(req, res){
    var member = projects.getProjectMembersByMemberId(req.params.projectId,req.params.memberId);
    if(!member){
        res.send(409, {
            'message': '用户不存在'
        });
    }
    res.send(200, member);
}

opt["PUT project members"] = function(req, res){
    var projectId = req.params.projectId;
    var memberId = req.params.memberId;
    var member = projects.updateProjectMembersByMemberId(projectId,memberId,req.body.roles);
    if(!member){
        res.send(409, {
            'message': '用户不存在'
        });
    }
    res.send(200, {});
}

opt["DELETE project members"] = function(req, res) {
    var projectId = req.params.projectId;
    var memberId = req.params.memberId;
    projects.delProjectMembers(projectId, memberId);
    res.send(200, {});
}

opt["POST project members"] = function(req, res) {
    var projectId = req.params.projectId;
    // var user = users.getById(req.body.id);
    // if (!user) {
    //     res.send(409, {
    //         'message': '用户不存在'
    //     });
    //     return;
    // }
    var member = {
        'id': req.body.id,
        'roles': req.body.roles,
        'createdAt': new Date().getTime()
    };
    var result = projects.addProjectMembers(projectId, member);
    if (result) {
        res.send(200, {});
    } else {
        res.send(409, {
            'message': '成员已经存在'
        });
    }
}



module.exports = opt;