'use strict';
var port = process.argv[2] || 8105;
var restify = require('restify');
var user = require("./api/user.js");

var server = restify.createServer();
server.use(restify.queryParser());
server.use(restify.requestLogger());
server.use(restify.bodyParser());

server.use(
	function crossOrigin(req, res, next) {
		'use strict';
		res.header("Access-Control-Allow-Origin", "*");
		res.header("Access-Control-Allow-Headers", "X-Requested-With");
		return next();
	}
);


server.get("/user/v1/indentify",user['GET indentify']);
server.post("/user/v1/users",user['POST users']);
server.del("/user/v1/users/:userId",user['DELETE users']);
server.patch("/user/v1/users/:userId",user['PATCH users']);
server.get("/user/v1/users",user['GET users']);
server.get("/user/v1/users/:userId",user['GET users/:userId']);
server.put("/user/v1/users/:userId/password",user['PUT users/:userId/password']);
server.post("/user/v1/users/:userId/visit-porjects",user['POST users/:userId/visit-porjects']);
server.post("/user/v1/users/check-password",user['POST check-password']);

server.listen(port, function( /*req, res*/ ) {
	console.log('UserManager api server listening on port ' + port);
});