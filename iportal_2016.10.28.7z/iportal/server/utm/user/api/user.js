var _ = require("underscore");
var user = require('../user/user.js');
var indentifyType = require('../../config/config.json').indentifyType;
var ldap = require('../ldap/ldap.js');
var md5 = require("blueimp-md5");

var opt = {};

opt['GET indentify'] = function(req, res){
	res.send(200,{indentify:indentifyType});
}

opt['POST users'] = function(req, res){
	var obj = req.body;
	if(user.getByUserName(obj.userName)){
		res.send(409,{'error':'user name already exist!'});
	}
	obj.visitPorjects = [];
	var userobj = user.addUser(obj);
	if(!userobj){
		res.send(500,{'error':'add user error!'});
	}
	res.send(200,_.omit(user,'password'));
}

opt['DELETE users'] = function(req, res){
	var id = req.params.userId;
	var userobj = user.delUser(id);
	if(!userobj){
		res.send(500,{'error':'delete user error!'})
	}
	res.send(200,_.omit(userobj,'password'));
}

opt['PATCH users'] = function(req, res){
	var id = req.params.userId;
	var userobj = user.updateById(id,req.body);
	if(!userobj){
		res.send(500,{'error':'update user error!'})
	}
	res.send(200,_.omit(userobj,'password'));
}

opt['GET users'] = function(req, res) {
	var list = user.get();
	list = _.chain(list).map(function(user){return _.omit(user,'password');});
	res.send(200, list);
}

opt['GET users/:userId'] = function(req, res) {
	var id = req.params.userId;
	var userObj = user.getById(id);
	if (!userObj) {
		res.send(404, {
			'error': 'user is not exist!'
		});
	}
	res.send(200, _.omit(userObj,'password'));
}

opt['PUT users/:userId/password'] = function(req, res){
	var id = req.params.userId;
	var oldPassword = req.body.oldpassword;
	var newPassword = req.body.newpassword;
	var userObj = user.getById(id);
	if (!userObj) {
		res.send(404, {
			'error': 'user is not exist!'
		});
	}
	if(!user.checkPassword(userObj.userName,oldPassword)){
		res.send(405, {
			'error': 'old password is not correct!'
		});
	}
	userObj.password = md5(md5(newPassword));
	var obj = user.updateById(id,userObj);
	if(!obj){
		res.send(500,{'error':'update password error!'})
	}
	res.send(200,_.omit(obj,'password'));
}
opt['POST users/:userId/visit-porjects'] = function(req, res){
	var id = req.params.userId;
	if(!user.addVisitPorjects(id,req.body.projectId)){
		res.send(500,{'error':'update user error!'});
	}else{
		res.send(204,{});
	}
}

opt['POST check-password'] = function(req, res){
	var userName = req.body.name;
	var password = req.body.password;
	if(indentifyType =='ldap'){
		try{
			ldap.checkPassword(userName, password)
				.map(function() {
					return user.getLocalUserinfoIfUserNotExistCreateUser(userName);
				})
				.subscribe( userObj => {
					if (!user.getLocalUserinfoIfUserNotExistCreateUser(userName).name) {
						user.updateUserInfoFromLdap(userName, password);
					}
					var _user = user.getByUserName(userName);
					res.send({result:true,data:_.omit(_user,'password')});
				},error=>{
					console.log(error);
					res.send({result:false});
				});
			} catch (e) {
				res.send({result:false});
			}
	}else{
		if(user.checkPassword(userName, password)){
			var _user = user.getByUserName(userName);
			res.send({result:true,data:_.omit(_user,'password')});
		}else{
			res.send({result:false});
		}
	}
	// var userObj = user.getById(id);
	// if (!userObj) {
	// 	res.send(404, {
	// 		'error': 'user is not exist!'
	// 	});
	// }
	// res.send(user.localCheckPassword(req.body));
}

module.exports = opt;