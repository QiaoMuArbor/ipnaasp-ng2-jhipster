var Rx = require('rx');
var uuid = require('node-uuid');
var md5 = require("blueimp-md5");
var ldap = require("../ldap/ldap.js");

var _ = require("underscore");
var _db = require("underscore-db");

_.mixin(_db);
var dbFile = "../config/user-db.json";
var db = _.load(dbFile);

var opt = {}

opt.getById = function(id) {
	 return _.getById(db.users, id);
}
opt.getByUserName = function(userName){
	return _.findWhere(db.users, {userName:userName});
}

opt.get = function() {
	return db.users || [];
}

opt.getLocalUserinfoIfUserNotExistCreateUser = function(userName) {
	var userObj = opt.getByUserName(userName);
	if (!userObj) {
		userObj = { 
		  'userName':userName,
		  'name':'',
		  'employeeID':userName,
		  'email': userName + '@zte.com.cn',
		  'department':['','','']
		};
		return opt.addUser(userObj);
	}
	return userObj;
}

opt.updateUserInfoFromLdap = function(employeeID, password) {
	ldap.getUserInfo(employeeID, password)
		.map(function(userData) {
		return opt.updateByUserName(employeeID, userData);
		})
		.subscribe(res=>{
			console.log('update user(username is empty) info from ldap success! id is ' + employeeID);
		},error=>{
			console.log('update user(username is empty) info from ldap fail! id is ' + employeeID);
		});
}

opt.addUser = function(user) {
	user.password = md5(md5(user.password));
	var newUser = _.insert(db.users, user);
	_.save(db, dbFile);
	return newUser;
}
opt.delUser = function(id) {
	var delData = _.removeById(db.users, id);
	return delData;
}
opt.updateById = function(id, user) {
	var newUser = _.updateById(db.users, id, user);
	_.save(db, dbFile);
	return newUser;
}
opt.updateByUserName = function(userName,user){
	var newUser = _.updateWhere(db.users, {userName:userName}, user);
	_.save(db, dbFile);
	return newUser;
}

opt.addVisitPorjects = function(id,projectId){
	var userObj = opt.getById(id);
	if (!userObj) {
		return false;
	}
	var visitPorjects =  userObj.visitPorjects||[];
	var visitPorject = _.findWhere(visitPorjects,{projectId:projectId});
	if(!visitPorject){
		visitPorjects.push({projectId:projectId,visitAt:new Date().getTime()});
	}else{
		visitPorject.visitAt = new Date().getTime();
	}
	var obj = opt.updateById(id,{visitPorjects:visitPorjects});
	if(!obj){
		return false;
	}
	return true;
}

opt.checkPassword = function(userName,password){
	var user = _.findWhere(db.users,{userName:userName});
	if (!user) {
		return false;
	}
	if (user.password != md5(md5(password))) {
		return false;
	}
	return true;
}

module.exports = opt;