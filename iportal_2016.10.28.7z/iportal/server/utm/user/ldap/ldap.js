var Rx = require('rx');

var _ = require("underscore");

var ldap = require('ldapjs');
var ldapServer = require('../../config/config.json').ldapServer;

var opt = {};

opt.checkPassword = function(employeeID, password) {
    return Rx.Observable.create(function(observer) {
        var userClient = ldap.createClient({
            url: ldapServer.url,
            timeout: 20000,
            connectTimeout: 20000
        });

        userClient.bind(ldapServer.domain + '\\' + employeeID, password, function(err) {
            if (err || !employeeID || !password) {
                observer.onError(
                    {'error':err,'flag':false});
                return ;
            }
            observer.onNext(true);
            observer.onCompleted();

        });
        // Note that this is optional, you do not have to return this if you require no cleanup
        return function() {
            userClient.unbind();
        };
    });
}

opt.getUserInfo = function(employeeID, password) {

    return Rx.Observable.create(function(observer) {
        var userClient = ldap.createClient({
            url: ldapServer.url,
            timeout: 20000,
            connectTimeout: 20000
        });

        userClient.bind(ldapServer.domain + '\\' + employeeID, password, function(err) {
            if (err || !employeeID || !password) {

                observer.onError(err);
                return;
            }
            //console.info('bind success ' + err);

            var opts = {
                filter: '(employeeID=' + employeeID + ')',
                scope: 'sub',
                timeLimit: 60,
                attributes: ['dn', 'givenName', 'mail', 'employeeID']
            }
            userClient.search(ldapServer.baseDn, opts, function(err, res2) {
                //console.info('search success '+err);
                //查询结果事件响应
                res2.on('searchEntry', function(entry) {
                    //获取查询的对象
                    //var ldapUser = entry.object;
                    //console.info('entry: ' + entry);
                    var user = getUserInfoFromLdap(entry.object);
                    observer.onNext(user);
                    observer.onCompleted();
                });

                //查询错误事件
                res2.on('error', function(err) {
                    observer.onError({'error':err,'flag':true});
                });

                //查询结束
                res2.on('end', function(result) {
                    //console.info('search status: ' + result.status);
                    observer.onError(err);
                });

            });

        });
        // Note that this is optional, you do not have to return this if you require no cleanup
        return function() {
            userClient.unbind();
        };
    });
}

function getDepartment(dn) {
    return _.map(dn.split(',').slice(1, 4), function(str) {
        return str.substring(3);
    });
}

function getUserInfoFromLdap(userObj) {
    //console.log(userObj);

    return user = {
        'userName': userObj.employeeID,
        'name': userObj.givenName,
        'employeeID': userObj.employeeID,
        'email': userObj.mail,
        'department': getDepartment(userObj.dn)
    };

}

module.exports = opt;