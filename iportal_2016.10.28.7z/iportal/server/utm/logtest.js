var log4js = require('log4js');
var logger = log4js.getLogger();

logger.trace('trace log');
logger.debug('debug log');
logger.info('info log');
logger.warn('warn log');
logger.error('error log');
logger.fatal('fatal log');
logger.fatal('__dirname:',__dirname);
