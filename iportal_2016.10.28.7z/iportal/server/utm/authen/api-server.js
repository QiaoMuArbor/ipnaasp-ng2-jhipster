'use strict';
var port = process.argv[2] || 8102;
var restify = require('restify');
var jwt = require("./api/jwt.js");

var server = restify.createServer();
server.use(restify.queryParser());
server.use(restify.requestLogger());
server.use(restify.bodyParser());

server.use(
    function crossOrigin(req, res, next) {
        'use strict';
        res.header("Access-Control-Allow-Origin", "*");
        res.header("Access-Control-Allow-Headers", "X-Requested-With");
        return next();
    }
);

// ldap login token
server.post("/authen/v1/tokens", jwt['POST tokens']);
server.post("/authen/v1/project-tokens", jwt['POST project-tokens']);
server.post("/authen/v1/verify-token", jwt['POST verify-token']);

server.listen(port, function( /*req, res*/ ) {
    console.log('Authen api server listening on port ' + port);
});