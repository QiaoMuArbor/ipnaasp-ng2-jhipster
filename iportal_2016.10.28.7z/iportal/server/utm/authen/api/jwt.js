/**
 * Created by zte on 16-9-20.
 */
var jwt = require('../jwt/jwt.js');
var restify = require('restify');
var config = require('../config.json');
var url = require('url');
var _ = require('underscore');
var opt = {};
var userClient = restify.createJsonClient({
    url: config.userhost
});
var projectClient = restify.createJsonClient({
    url: config.projecthost
});

opt['POST tokens'] = function(req, res) {
    userClient.headers = req.headers;
    userClient.post('/user/v1/users/check-password', req.body, function (err, creq, cres, obj) {
        if(err){
            return res.send(401, obj);
        };
        if(!obj.result){
            return res.send(401,{message:'username or password wrong!'});
        }else{
            var token = jwt.createToken({userId:obj.data.id,roles:['user']});
            return res.send(200,{'access_token': token,'user':obj.data});
        }
    });
}

opt['POST verify-token'] = function(req, res) {
    var result = jwt.verifyToken(req.headers['access-token']);
    if (!result.result) {
            res.send(401, {
            'error': result.message
        });
    }
    res.send(204);
}


opt['POST project-tokens'] = function(req, res) {
    var decodedToken = jwt.decodeToken(req.headers['access-token']);
    if (!decodedToken) {
        res.send(401, {
            'error': 'Access token invalid!'
        });
    }
    var reqUrl = '/project/v1/projects/'+req.body.projectId+'/members/'+decodedToken.userId;
    projectClient.headers = req.headers;
    projectClient.get(reqUrl, function (err, creq, cres, obj) {
        if(err){
            return res.send(500,obj);
        };
        var payload = {userId:decodedToken.userId,projectId:req.body.projectId,roles:obj.roles};
        var token = jwt.createToken(payload);
        return res.send(200, {'access_token': token});
    });
}

module.exports = opt;