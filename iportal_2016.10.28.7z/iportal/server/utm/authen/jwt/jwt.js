var jwt = require('jwt-simple');
var moment = require('moment');
var secret = require('./secret.js');
var expires = moment().add(24, 'hours').valueOf();
var url = require('url');

var opt = {};

opt.createToken = function(dataObj) {
    var payload = dataObj;
    payload.exp = expires;
    return jwt.encode(payload, secret.secretKey);
}

opt.decodeToken = function(token){
    try{
      var token = jwt.decode(token, secret.secretKey);
    }catch (err){
      return null;
    }
    if(token){
      return token;
    }
    return null;
}


opt.verifyToken = function (token) {
  if (token) {
    try {
      var decoded = jwt.decode(token, secret.secretKey);
      if(decoded){
        return {result:true,message:'Access token valid!'};
      }else{
        return {result:false,message:'No Access token found!'};
      }
    } catch (err) {
      return {result:false,message:'No Access token found!'};
    }
  } else {
    return {result:false,message:'No Access token found!'};
  }
}

module.exports = opt;
