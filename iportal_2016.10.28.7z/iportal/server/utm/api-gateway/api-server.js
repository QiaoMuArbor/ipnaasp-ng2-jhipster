var express = require('express');
var proxy = require('http-proxy-middleware');
var restify = require('restify');
var url = require('url');
var _ = require('underscore');
var config = require('../config/api-gateway.json');

var port = process.argv[2] || 8101;

var exceptions = [];

_.each(config.exceptions,function(_exception){
    exceptions.push(_exception);
});


var app = express();
app.use(
    function crossOrigin(req, res, next) {
        'use strict';
        res.header("Access-Control-Allow-Origin", "*");
        res.header("Access-Control-Allow-Headers", "X-Requested-With");
        return next();
    }
);

var jwtclient = restify.createJsonClient({
    url: config.authenhost
});
var aclclient = restify.createJsonClient({
    url: config.authorhost
});

function verifyToken(headers, cb) {
    jwtclient.headers = headers;
    jwtclient.post('/authen/v1/verify-token', function(err, creq, cres, obj) {
        if (err) {
            return cb(err);
        };
        return cb();
    });
}

function verifyRole(item, req, cb) {
    var method = req.method.toLowerCase();
    //var data = { token:req.headers['access-token'],method:req.method.toLowerCase() };
    aclclient.headers = req.headers;
    if (method == 'delete') {
        method = "del";
    }
    var requestUrl = url.parse(req.url).pathname;
    // console.log('requestUrl1:'+requestUrl);
    // requestUrl = requestUrl.replace(item.matchPath, item.targetPath);
    // console.log('requestUrl2:'+requestUrl);
    aclclient[method]('/author/v1/verify-url' + requestUrl, function(err, creq, cres, obj) {
        if (err) {
            return cb(err);
        };
        return cb();
    });
}

function isException(_url) {
    var requestUrl = url.parse(_url).pathname;
    var exception = _.find(exceptions, function(_exception) {
        if (_exception.type === "regular") {
            
            if (requestUrl.match(_exception.url)) {
                //console.log(requestUrl, _exception.url);
            //console.log(requestUrl.match(_exception.url));
                return true;
            }
        } else {
            //console.log(requestUrl, _exception.url, requestUrl.indexOf(_exception.url));
            if (requestUrl.indexOf(_exception.url) == 0) {
                return true;
            }
        }
        return false;
    });
    //console.log(exception,exceptions);
    return exception ? true : false;
}


_.each(config.proxy_targets, function(item) {
    app.all(item.matchPath + '*', function(req, res, next) {
        //console.log(item.matchPath + '*:' + req.url);
        if (isException(req.url)) {
            return next();
        }
        //console.log('verifyToken:'+req.url);
        verifyToken(req.headers, function(err) {
            if (err) {
                return res.status(401).send(err).end();
            }
            verifyRole(item, req, function(err) {
                if (err) {
                    return res.status(401).send(err).end();
                }
                return next();
            });
        });
    });
});

_.each(config.proxy_targets, function(item) {
    var oldpath = '^' + item.matchPath;
    var options = {
        target: item.target,
        pathRewrite: {}
    };
    options.pathRewrite[oldpath] = item.targetPath;
    //console.log(apiproxy);

    var apiproxy = proxy(item.matchPath, options)
    app.use(apiproxy);
});


app.listen(port, function( /*req, res*/ ) {
    console.log('ApiProxy server listening on port ' + port);
})