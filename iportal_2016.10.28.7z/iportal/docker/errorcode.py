# -*- coding:utf-8 -*-

class ErrorCode(object):
    class Err(object):
        def __init__(self,iCode,sMsg):
            self.iCode = iCode
            self.sMsg  = sMsg
        def get_code(self):
            return self.iCode
        def get_msg(self):
            return self.sMsg

    SUC          = Err(0,"suc")
    BUILD_WEB_FAIL             = Err(101,'build web fail')
    TSC_FAIL                 = Err(102,"tsc fail")
    BUILD_SCALA_FAIL         = Err(103,'build scala fail')

    # UNITTEST_SCALA_FAIL      = Err(103,"UNITTEST_SCALA_FAIL")
    DOCKER_TAR_FAIL          = Err(104,'create tar package fail')
    # BUILD_VERSION_TAR_FAIL   = Err(105,'create version tar file fail')