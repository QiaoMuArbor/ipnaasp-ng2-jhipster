# -*- coding:utf-8 -*-

import os
import tool
from errorcode import ErrorCode
import re



def modify_version_tag(logger,strWorkSpace):
    logger.debug("modify client version LastcommitID")
    versionFileList = []

    
    reg = re.compile('(LastCommitId:){1}([\d]|[a-zA-Z]|[:+]|[\s])*(<br>){0,1}([\d]|[a-zA-Z]|[:+]|[\s])*([:]){0,1}(<br>){0,1}([\d]|[a-zA-Z]|[:+]|[\s])*([:]){0,1}(<br>){0,1}(Version|commitId|VVV){1}')
    iportalVersionNoFile       = tool.get_iportal_versionNo_file(strWorkSpace)
    utmVersionNoFile = tool.get_utm_versionNO_file(strWorkSpace)
    versionFileList.append(iportalVersionNoFile)
    versionFileList.append(utmVersionNoFile)
    # srcTag  = tool.get_client_version_srctag()
    destTag = tool.get_client_version_desttag() + tool.get_iportal_last_commit_id(strWorkSpace) + " <br>Branch:" + tool.get_iportal_version_branch(strWorkSpace) + " <br>Version"
    destTag = destTag.replace('\n',"")
    for versionFile in versionFileList:
        if not os.path.exists(versionFile):
            logger.debug("Not found client version file: %s "%(versionFile))
            return False
        fp = open(versionFile,'r+')
        lines = fp.readlines()
        fp.seek(0)
        fp.truncate()
        for line in lines:
            if reg.search(line):
                result,_=reg.subn(destTag,line)
                fp.write(result.replace("Date","<br>Date"))
            else:
                fp.write(line)
            # fp.write(line.replace(srcTag,destTag))
        fp.close()
    return True

def build_web(logger,strWorkSpace):
    '''
    :param strWorkSpace:
    :return:
    '''
    logger.debug("--> build_web")
    logger.debug("workspace="+strWorkSpace)

    if (os.path.exists(tool.get_webapp(strWorkSpace))):
        os.system("rm -rf %s"%(tool.get_webapp(strWorkSpace)))
    strCurDir = os.getcwd()
    os.chdir(tool.get_client(strWorkSpace))

    # os.system("unzip -o node_modules.zip")

    # cmd = "npm run build.prod"
    cmd = "gulp build.prod --color"
    res = modify_version_tag(logger,strWorkSpace)
    if not res:
        logger.error("<-- build_web fail")
        return ErrorCode.BUILD_WEB_FAIL
    logfile = os.path.join(tool.get_complie(strWorkSpace),"webStd.log")
    logfileerr = os.path.join(tool.get_complie(strWorkSpace),"webErr.log")
    os.system("%s 1>%s 2>%s"%(cmd,logfile,logfileerr))

    os.chdir(strCurDir)
    if (not os.path.exists(os.path.join(tool.get_webapp(strWorkSpace),"index.html"))):
        logger.error("<-- build_web fail")
        return ErrorCode.BUILD_WEB_FAIL


    logger.debug("<-- build_web")
    return ErrorCode.SUC