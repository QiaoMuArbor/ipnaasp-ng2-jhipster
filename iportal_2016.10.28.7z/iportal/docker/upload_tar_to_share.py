# __author__ = 'root'

import setting
import tool
import pexpect
from logger import  get_logger
from datetime import datetime
import time
import os



def login_share_do(logger, cmdStr):
    loginStr = "ssh " + tool.get_share_ssh_ip()
    task = pexpect.spawn(loginStr,maxread=10000)
    index = task.expect(['root@',pexpect.EOF,pexpect.TIMEOUT],
                    timeout = 5)
    if index == 0:
        task.sendline(tool.get_share_passwd())
        task.expect(['root@',pexpect.EOF,pexpect.TIMEOUT],timeout = 5)
        task.sendline(cmdStr)
        task.expect(['root@',pexpect.EOF,pexpect.TIMEOUT],timeout = 5)
        task.sendline("exit")

    else:
        logger.debug("login share vm fail")
        return False
    task.close()

def upload_to_share(logger ,srcPath, destPath, passwd, module_name):
    '''upload to share 98'''
    logger.debug("begin upload %s ..."%(module_name))
    cmdStr = "scp -r " + srcPath + "/" + module_name + " " + destPath
    task = pexpect.spawn(cmdStr,maxread=10000)
    index = task.expect(['continue','password',pexpect.EOF,pexpect.TIMEOUT],
                    timeout = 40)
    if index == 0:
        task.sendline("yes")
        task.expect('password')
        task.sendline(passwd)
        # task.interact()
        task.wait()
    elif index == 1:
        task.sendline(passwd)
        # task.interact()
        task.wait()
    else:
        task.close(True)
        logger.debug("    upload - %s fail"%(module_name))
        return False
    task.close(True)
    time.sleep(8)
    logger.debug("    upload %s success"%(module_name))
    return True


# begin upload flag=0,rm file flag=1, complete upload flag=2
def exe_share_vm_shell(flag):

    # fileName = datetime.now().date().isoformat() +datetime.now().time().isoformat()

    beginFileStr = "cd " + tool.get_share_ssh_dir() + " && " + "touch " + '"Can not copy ! please waitting .Version is uploading ....txt"'
    rmStr = "rm " + tool.get_share_ssh_dir() + '/' + tool.get_share_version_file()
    # EndFileStr = "cd " + tool.get_share_ssh_dir() + " && " + "touch " + '"' + "Version: " + fileName+ ".txt" + '"'
    EndFileStr=  "cd " + tool.get_share_ssh_dir() + " && " + "touch "   + '"version upload complete.txt"'

    if 0 == flag:
        login_share_do(logger, beginFileStr)
    elif 1 == flag:
        login_share_do(logger, rmStr)
    elif 2 == flag:
        login_share_do(logger, EndFileStr)
    else:
        exit(1)


if __name__ == "__main__":
    logger = get_logger(setting.g_strWorkSpace)
    passwd = tool.get_share_passwd()
    srcPath = tool.get_deploy(setting.g_strWorkSpace)
    destPath= tool.get_share_udate_dir()
    module_name_list = [ "iportal", "utm" ]
    logger.debug("rm version file")
    exe_share_vm_shell(1)
    exe_share_vm_shell(0)

    for module in module_name_list:
        upload_to_share(logger, srcPath, destPath, passwd, module)
        logger.debug("end upload  %s"%(module))
    logger.debug("All module upload complete!")

    exe_share_vm_shell(1)
    exe_share_vm_shell(2)
    logger.debug("create version file")