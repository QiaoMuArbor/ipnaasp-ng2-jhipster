#! /bin/sh
CurPath=`pwd`
ClientPath=${CurPath}/../client
DeployPath=${CurPath}/../deploy

if [ $# -ne 4 ]; then
    echo "usage:"
    echo "./upload_tar_main.sh  module_name changid versionno srvip"
    exit 1
fi


module_name=$1
changid=$2
version=$3
srvip=$4


echo "deploy module..."
cd ${ClientPath} && chmod a+x compile.sh && ./compile.sh && cd ${CurPath} && \
   python build_main.py && \
   python upload_tar_main.py  $module_name $changid $version $srvip