import os
import tool
import setting
def code_front(fop,dirPath):
    "sss"
    execludeDirs = tool.get_som_front_execlude_dir(setting.g_strWorkSpace)
    flag = False;
    lineNum = 0
    for root,dirs,files in os.walk(dirPath):
        flag = False;
        for dir in execludeDirs:
            if  root.startswith(dir):
                flag = True
        if not flag:
            for fileName in files:
                if fileName.endswith(".ts") or fileName.endswith(".html") or fileName.endswith(".css"):
                    filenameabs = os.path.join(root,fileName)
                    output = os.popen('cat %s | grep -v "^$" |  wc -l'%(filenameabs))
                    lineNum = int(lineNum) + int(output.read())

    fop.write("iportal front code lines: " + str(lineNum) + "\n")
    
def code_end(fop,dirPath):
    "sss"
    execludeDirs = tool.get_som_end_execlude_dir(setting.g_strWorkSpace)
    flag = False;
    lineNum = 0
    for root,dirs,files in os.walk(dirPath):
        flag = False;
        for dir in execludeDirs:
            if  root.startswith(dir):
                flag = True
        if not flag:
            for fileName in files:
                if fileName.endswith(".js"):
                    filenameabs = os.path.join(root,fileName)
                    output = os.popen('cat %s | grep -v "^$" |  wc -l'%(filenameabs))
                    lineNum = int(lineNum) + int(output.read())
    fop.write("iportal end code lines: " + str(lineNum))
 
def code_end_unitTest(fop,dirPath):
    "ssss"   
    os.chdir(dirPath)
    output = os.popen('find . -name "*.scala" | xargs grep -v "^$" |  wc -l')
    fop.write("iportal end unit test lines: " + output.read()) 
    
def is_dir_exist(logger,strWorkSpace):
    flag = True
    infoStr = "code_stat: code dir not exist = "
    if (not os.path.exists(tool.get_som_front_code_ts(strWorkSpace))):
        logger.debug(infoStr + tool.get_som_front_code_ts(strWorkSpace))
        flag = False
    # if (not os.path.exists(tool.get_som_end_code_scala(strWorkSpace))):
    #     logger.debug(infoStr + tool.get_som_end_code_scala(strWorkSpace))
    #     flag = False
    # if (not os.path.exists(tool.get_som_end_code_unitTest(strWorkSpace))):
    #     logger.debug(infoStr + tool.get_som_end_code_unitTest(strWorkSpace))
    #     flag = False
    return flag      
    
def code_Statistic(logger, versionDir):
    if(not is_dir_exist(logger,versionDir)):
        logger.debug("Error:  code_stat end")
        return
    
    if (os.path.isfile("code_stat.txt")):
        logger.debug("rm code_stat.txt")
        os.popen("rm -rf code_stat.txt")
        
    fop = open('code_stat.txt', 'w+')
    logger.debug("-->front code stat")   
    code_front(fop,tool.get_som_front_code_ts(versionDir))
    logger.debug("<--front code stat")
    
    logger.debug("-->end code stat")
    code_end(fop,tool.get_som_end_code_js(versionDir))
    logger.debug("<--end code stat")
    
    # logger.debug("-->end unit test code stat")
    # code_end_unitTest(fop,tool.get_som_end_code_unitTest(versionDir))
    # logger.debug("<--end unit test code stat")
    fop.close()

        
if __name__ == '__main__':
    from logger import  get_logger
    logger = get_logger('.')
    code_Statistic(logger, os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir)))