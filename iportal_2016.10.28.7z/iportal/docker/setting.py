import os

g_strWorkSpace = os.path.abspath(os.path.join(os.path.dirname(__file__),os.pardir))

