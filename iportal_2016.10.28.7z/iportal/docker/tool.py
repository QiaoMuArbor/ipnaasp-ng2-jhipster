# -*- coding:utf-8 -*-

import os

def get_client(strWorkSpace):
    return  os.path.join(strWorkSpace,"client")
def get_iportal_versionNo_file(strWorkSpace):
    return os.path.join(strWorkSpace,"client","src","client","app","about.component.ts")
# def get_client_version_srctag():
#     return "LastCommitId:VVV"
def get_client_version_desttag():
    return "LastCommitId:"

def get_deploy(strWorkSpace):
    return os.path.join(strWorkSpace,"deploy")
def get_nginx(strWorkSpace):
    return os.path.join(strWorkSpace,"nginx")
def get_docker(strWorkSpace):
    return os.path.join(strWorkSpace,"docker")
def get_server(strWorkSpace):
	return os.path.join(strWorkSpace,"server")
def get_complie(strWorkSpace):
    return os.path.join(strWorkSpace,"docker","complie")
def get_webapp(strWorkSpace):
    return  os.path.join(get_client(strWorkSpace),"dist", "prod")


# copy version file
def get_iportal_verfile(strWorkSpace):
    return os.path.join(get_client(strWorkSpace),"dist","prod")

def get_utm_verfile(strWorkSpace):
    return os.path.join(strWorkSpace,"server","utm")
def get_utm_verfile_config(strWorkSpace):
    return os.path.join(strWorkSpace,"server","utm", "config")
def get_utm_versionNO_file(strWorkSpace):
    return os.path.join(strWorkSpace,"server","utm","version.js")


#code_stat.py use
def get_som_front_code_ts(strWorkSpace):
    return os.path.join(strWorkSpace,"client","src","client","app")
def get_som_end_code_js(strWorkSpace):
    return os.path.join(strWorkSpace,"server")
def get_som_front_execlude_dir(strWorkSpace):
    return [os.path.join(get_som_front_code_ts(strWorkSpace),"shared","kylib")]
def get_som_end_execlude_dir(strWorkSpace):
    return [os.path.join(get_som_end_code_js(strWorkSpace),"utm","node_modules"), \
            os.path.join(get_som_end_code_js(strWorkSpace),"iportal","node_modules")]
# def get_som_end_code_scala(strWorkSpace):
#     return os.path.join(strWorkSpace,"server","utm","ztes","som","src","main","scala")
# def get_som_end_code_unitTest(strWorkSpace):
#     return os.path.join(strWorkSpace,"server","utm","ztes","som","src","test","scala")


#config update iportal tar to share 98 vm

def get_share_ssh_ip():
    return "root@10.92.247.98"
def get_share_ssh_dir():
    return "/data4share/share/iportal_version"
def get_share_udate_dir():
    return get_share_ssh_ip()+ ":" +get_share_ssh_dir()
def get_share_passwd():
    return "root123"
def get_share_version_file():
    return "*.txt"



#config upload iportal tar to swr gerrit
def get_ci_version_no():
    return "v1.16.10.02"
def get_ci_srcli_path():
    return "/root/zartcli"
def get_ci_srcli_port():
    return "6000"
# def get_ci_srcli_ip():
#     return ""

# get iportal last commit id
def get_iportal_last_commit_id(strWorkSpace):
    cmdStr = "cd " + strWorkSpace + " && " + "git log -1|grep  -E 'commit|Date'|sed -e 2q|sed 's/commit //g'"
    # git log -1|grep -E 'commit|Date' |sed -e 2q |sed 's/commit //g'
    return os.popen(cmdStr).read()

def get_iportal_version_branch(strWorkSpace):
    cmdStr = "cd " + strWorkSpace + " && " + "git branch |grep '*'|sed 's/* //g'"
    return os.popen(cmdStr).read()






