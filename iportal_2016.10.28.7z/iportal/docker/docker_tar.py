# -*- coding:utf-8 -*-
import os
import glob
import sys
import pexpect
import shutil
import tool
from errorcode import ErrorCode

class BaseConf(object):
    def __init__(self,logger,strWorkSpace,container_name,image_name,ver_path):
        self.fout = None
        self.task = None
        self.verfile = 'verfile'
        self.logger = logger
        self.root_dir = os.path.dirname(os.path.realpath(__file__))
        self.container_name = container_name
        self.image_name = image_name
        self.tar_name = image_name + '.tar'
        self.logfile = ''
        self.ver_path = ver_path
        self.dockerfileDir = os.path.join(self.root_dir,self.image_name)
        self.strWorkSpace = strWorkSpace
        if not self.init_base_para(ver_path):
            self.check_run = False
        else:
            self.check_run = True

    def init_base_para(self,ver_path):
        ver_path = os.path.realpath(ver_path)
        if os.path.isfile(ver_path):
            ver_path = os.path.dirname(ver_path)

        buildTmpSpace = tool.get_complie(self.strWorkSpace)
        if (not os.path.exists(buildTmpSpace)):
            os.makedirs(buildTmpSpace)

        self.logfile = os.path.join(buildTmpSpace, self.image_name + 'tarBuild.log')
        return True

    def release_connect(self):
        if self.task != None:
            #self.task.close(force=False)
            #self.task = None
            pass

    def close_log_file(self):
        if self.fout != None:
            self.fout.close()
            self.fout = None

    def is_root_user(self):
        self.task = pexpect.spawn('whoami',maxread=10000)
        index = self.task.expect(['root','jenkins',pexpect.EOF,pexpect.TIMEOUT],
                        timeout = 10)
        if index == 0:
            self.release_connect()
            return True,'root'
        self.release_connect()
        return False,'jenkins'

class DcokerContainer(BaseConf):
    def __init__(self,logger,strWorkSpace,container_name,image_name,ver_path):
        BaseConf.__init__(self,logger,strWorkSpace,container_name,image_name,ver_path)

    def is_container_run(self):
        self.fout = file(self.logfile,'a+')
        _is_root_user,passwd = self.is_root_user()
        if _is_root_user:
            _cmd_str = 'docker ps -a'
        else:
            _cmd_str = 'sudo docker ps -a'
        i = 6
        while i > 0:
            self.task = pexpect.spawn(_cmd_str,
                                maxread=10000)
            self.task.logfile = self.fout

            if not _is_root_user:
                index = self.task.expect(['sudo.*password',
                                pexpect.EOF,pexpect.TIMEOUT],
                                timeout = 3)
                if index == 0:
                    self.task.sendline(passwd)
                    self.task.expect('.*')

            index = self.task.expect([self.container_name,'Error','failed',
                            pexpect.EOF,pexpect.TIMEOUT],
                            timeout = 20)
            if index == 0:
                self.release_connect()
                return True
            self.task.close(force=True)
            i -= 1
        self.logger.debug( 'check container %s run finish'%(self.container_name))
        self.release_connect()
        return False

    def stop_container(self):
        self.fout = file(self.logfile,'a+')
        _is_root_user,passwd = self.is_root_user()
        if _is_root_user:
            _cmd_str = 'docker stop %s'%(self.container_name)
        else:
            _cmd_str = 'sudo docker stop %s'%(self.container_name)

        self.task = pexpect.spawn(_cmd_str,
                            maxread=10000)
        self.task.logfile = self.fout

        if not _is_root_user:
            index = self.task.expect(['sudo.*password',
                            pexpect.EOF,pexpect.TIMEOUT],
                            timeout = 3)
            if index == 0:
                self.task.sendline(passwd)
                self.task.expect('.*')

        index = self.task.expect([self.container_name,'Error','failed',
                        pexpect.EOF,pexpect.TIMEOUT],
                        timeout = 20)
        if index == 0:
            self.release_connect()
            return True
        self.logger.debug( 'stop container %s finish'%(self.container_name))
        self.release_connect()
        return False

    def start_container(self):
        self.fout = file(self.logfile,'a+')
        _is_root_user,passwd = self.is_root_user()
        if _is_root_user:
            _cmd_str = 'docker run -d -p 31942:1942 --name %s %s '%(self.container_name,self.image_name)
        else:
            _cmd_str = 'sudo docker run -d -p 31942:1942 --name %s %s '%(self.container_name,self.image_name)
        self.task = pexpect.spawn(_cmd_str,
                            maxread=10000)
        self.task.logfile = self.fout

        if not _is_root_user:
            index = self.task.expect(['sudo.*password',
                            pexpect.EOF,pexpect.TIMEOUT],
                            timeout = 3)
            if index == 0:
                self.task.sendline(passwd)
                self.task.expect('.*')

        index = self.task.expect(['%s|#|started'%self.container_name,'Error','failed',
                        pexpect.EOF,pexpect.TIMEOUT],
                        timeout = 60)
        if index == 0:
            self.release_connect()
            return True
        self.logger.debug( 'start container %s finish'%(self.container_name))
        self.release_connect()
        return False

    def rm_container(self):
        self.fout = file(self.logfile,'a+')
        _is_root_user,passwd = self.is_root_user()
        if _is_root_user:
            _cmd_str = 'docker rm %s'%(self.container_name)
        else:
            _cmd_str = 'sudo docker rm %s'%(self.container_name)

        self.task = pexpect.spawn(_cmd_str,
                            maxread=10000)
        self.task.logfile = self.fout

        if not _is_root_user:
            index = self.task.expect(['sudo.*password',
                            pexpect.EOF,pexpect.TIMEOUT],
                            timeout = 3)
            if index == 0:
                self.task.sendline(passwd)
                self.task.expect('.*')

        index = self.task.expect([self.container_name,'Error','failed',
                        pexpect.EOF,pexpect.TIMEOUT],
                        timeout = 20)
        if index == 0:
            self.release_connect()
            return True
        self.logger.debug( 'rm container %s finish'%(self.container_name))
        self.release_connect()
        return False


class DockerImage(BaseConf):
    def __init__(self,logger,strWorkSpace,container_name,image_name,ver_path):
        BaseConf.__init__(self,logger,strWorkSpace,container_name,image_name,ver_path)

    def is_image_exists(self):
        self.fout = file(self.logfile,'a+')

        _is_root_user,passwd = self.is_root_user()
        if _is_root_user:
            _cmd_str = '/bin/bash -c "docker images |grep %s"'%(self.image_name)
        else:
            _cmd_str = 'sudo /bin/bash -c "docker images |grep %s"'%(self.image_name)

        self.task = pexpect.spawn(_cmd_str,maxread=10000)
        self.task.logfile = self.fout

        if not _is_root_user:
            index = self.task.expect(['sudo.*password',
                            pexpect.EOF,pexpect.TIMEOUT],
                            timeout = 3)
            if index == 0:
                self.task.sendline(passwd)
                self.task.expect('.*')

        index = self.task.expect([self.image_name,
                        pexpect.EOF,pexpect.TIMEOUT],
                        timeout = 20)
        if index == 0:
            self.release_connect()
            return True
        self.logger.debug( 'image %s is not exists'%(self.image_name))
        self.release_connect()
        return False

    def create_image(self):
        self.fout = file(self.logfile,'a+')
        _is_root_user,passwd = self.is_root_user()
        if _is_root_user:
            _cmd_str = 'docker build -t library/%s %s'%(self.image_name,self.dockerfileDir)
        else:
            _cmd_str = 'sudo docker build -t library/%s %s'%(self.image_name,self.dockerfileDir)

        self.task = pexpect.spawn(_cmd_str,maxread=10000)
        self.task.logfile = self.fout
        if not _is_root_user:
            index = self.task.expect(['sudo.*password',
                            pexpect.EOF,pexpect.TIMEOUT],
                            timeout = 3)
            if index == 0:
                self.task.sendline(passwd)
                self.task.expect('.*')

        index = self.task.expect(['Successfully',
                        pexpect.EOF,pexpect.TIMEOUT],
                        timeout = 60*10)
        if index == 0:
            self.logger.debug( 'image %s create suc'%(self.image_name))
            self.release_connect()
            return True
        self.logger.debug(str(self.task))
        self.logger.debug( 'image %s create fail'%(self.image_name))
        self.release_connect()
        return False

    def remove_image(self):
        self.fout = file(self.logfile,'a+')

        _is_root_user,passwd = self.is_root_user()
        if _is_root_user:
            _cmd_str = '/bin/bash -c "docker rmi %s"'%(self.image_name)
        else:
            _cmd_str = 'sudo /bin/bash -c "docker rmi %s"'%(self.image_name)

        self.task = pexpect.spawn(_cmd_str,maxread=10000)
        self.task.logfile = self.fout

        if not _is_root_user:
            index = self.task.expect(['sudo.*password',
                            pexpect.EOF,pexpect.TIMEOUT],
                            timeout = 3)
            if index == 0:
                self.task.sendline(passwd)
                self.task.expect('.*')

        index = self.task.expect([self.image_name,
                        pexpect.EOF,pexpect.TIMEOUT],
                        timeout = 20)
        if index == 0:
            self.release_connect()
            self.logger.debug( 'image %s is delete'%(self.image_name))
            return True
        self.logger.debug( 'image %s is not exist ,dont need to delete'%(self.image_name))
        self.release_connect()
        return False

class DockerTar(BaseConf):
    def __init__(self,logger,strWorkSpace,container_name,image_name,ver_path='libs'):
        BaseConf.__init__(self,logger,strWorkSpace,container_name,image_name,ver_path)
        if self.check_run:
            if not self.check_dockerfile():
                self.check_run = False
            if not self.prepare_basefile():
                self.check_run = False

    def prepare_basefile(self):

        buildVerDir = os.path.join(self.root_dir,self.image_name,self.verfile)
        if not os.path.exists(self.ver_path):
            self.logger.debug( '%s not exists'%(os.path.realpath(self.ver_path)))
            return False


        if os.path.exists(buildVerDir):
            shutil.rmtree(buildVerDir)


        if os.path.exists(os.path.join(self.root_dir,self.tar_name)):
            os.system('rm -rf %s'%(os.path.join(self.root_dir,self.tar_name)))
        self.logger.debug(self.ver_path+ "/////////" +buildVerDir)
        shutil.copytree(self.ver_path, buildVerDir)
        if self.image_name == 'utm':
            if not os.path.exists(os.path.join(buildVerDir,'api-gateway','api-server.js')):
                self.logger.debug( '%s not exists'%(os.path.realpath(os.path.join(buildVerDir,'api-gateway', 'api-server.js'))))
                return False
            
            if not os.path.exists(os.path.join(buildVerDir,'node_modules.tar')):
                self.logger.debug( '%s not exists'%(os.path.realpath(os.path.join(buildVerDir,'node_modules.tar'))))
                return False
            nodetmpdir = os.path.realpath(buildVerDir)
            # os.system("unzip -o %s/node_modules.zip -d %s"%(nodetmpdir,nodetmpdir))
            # os.system("rm -rf %s/node_modules.zip"%(nodetmpdir))
        elif self.image_name == 'iportal':
            if os.path.exists(os.path.join(buildVerDir,'..','nginx')):
                shutil.rmtree(os.path.join(buildVerDir,'..','nginx'))
            shutil.copytree(tool.get_nginx(self.strWorkSpace), os.path.join(buildVerDir,'..','nginx'))
            if not os.path.exists(os.path.join(buildVerDir,'index.html')):
                self.logger.debug( '%s not exists'%(os.path.realpath(os.path.join(buildVerDir,'index.html'))))
                return False

        self.logger.debug('copy file finish')
        return True

    def check_dockerfile(self):
        dockfile_path = os.path.join(self.dockerfileDir,'Dockerfile')
        if not os.path.exists(dockfile_path):
            self.logger.debug( '%s dockfile is not exists'%(dockfile_path))
            return False
        self.logger.debug('dockfile check finish')
        return True

    def check_docker_version(self):
        self.fout = file(self.logfile,'w+')
        _is_root_user,passwd = self.is_root_user()
        if _is_root_user:
            _cmd_str = 'docker version'
        else:
            _cmd_str = 'sudo docker version'

        self.task = pexpect.spawn(_cmd_str,
                            maxread=10000)
        self.task.logfile = self.fout

        if not _is_root_user:
            index = self.task.expect(['sudo.*password',
                            pexpect.EOF,pexpect.TIMEOUT],
                            timeout = 3)
            if index == 0:
                self.task.sendline(passwd)
                self.task.expect('.*')

        index = self.task.expect(['Client.*version','command.*not.*found',pexpect.EOF,pexpect.TIMEOUT],
                                        timeout = 20)
        if index == 0:
            self.logger.debug ('docker version check suc')
        else:
            self.logger.debug ('docker not install')
            self.logger.debug (str(self.task))
            self.release_connect()
            return False
        self.release_connect()
        return True

    def docker_tar(self):
        self.fout = file(self.logfile,'a+')
        _is_root_user,passwd = self.is_root_user()
        if _is_root_user:
            _cmd_str = '/bin/bash -c "docker save %s > %s"'%(self.image_name,self.tar_name)
        else:
            _cmd_str = 'sudo /bin/bash -c "docker save %s > %s"'%(self.image_name,self.tar_name)

        self.task = pexpect.spawn(_cmd_str,
                            maxread=10000)
        self.task.logfile = self.fout

        if not _is_root_user:
            index = self.task.expect(['sudo.*password',
                            pexpect.EOF,pexpect.TIMEOUT],
                            timeout = 3)
            if index == 0:
                self.task.sendline(passwd)
                self.task.expect('.*')

        index = self.task.expect(['Error','failed',
                        pexpect.EOF,pexpect.TIMEOUT],
                        timeout = 60*10)
        if index == 2:
            self.release_connect()
            self.logger.debug("copy tar to deploy dir")
            os.system("cp  %s %s"%(os.path.join(tool.get_docker(self.strWorkSpace))+"/"+self.tar_name,os.path.join(tool.get_deploy(self.strWorkSpace),self.image_name)))
            if self.image_name == "utm":
                os.system("rm %s"%(os.path.join(tool.get_deploy(self.strWorkSpace), self.image_name) + '/*.json'))
                os.system("cp %s %s"%(os.path.join(tool.get_utm_verfile_config(self.strWorkSpace) +"/*") , os.path.join(tool.get_deploy(self.strWorkSpace),self.image_name)))
            return True
        self.logger.debug(str(self.task))
        self.logger.debug( 'tar %s create fail'%(self.tar_name))
        self.release_connect()
        return False

    def is_tar_exists(self):
        if not os.path.exists(os.path.join(self.root_dir,self.tar_name)):
            return False
        return True

    def do_process(self,dcont,dimage):
        self.logger.debug('run stop container if exists')
        dcont.stop_container()
        self.logger.debug('run rm container if exists')
        dcont.rm_container()
        self.logger.debug('run rm images if exists')
        dimage.remove_image()
        self.logger.debug('begin create image')
        if not dimage.create_image():
            return False
        self.logger.debug('create image, finish')
        self.logger.debug('begin check image exists')
        if not dimage.is_image_exists():
            return False
        self.logger.debug('check image exists, ok')
        self.logger.debug('begin make tar by image')
        if not self.docker_tar():
            return False
        self.logger.debug('make tar by image, finish')
        self.logger.debug('begin check tar exists')
        if not self.is_tar_exists():
            return False
        self.logger.debug('check tar exists, ok')
        # self.logger.debug('run start container')
        # dcont.start_container()
        # self.logger.debug('begin check container run')
        # if not dcont.is_container_run():
        #     return False
        # self.logger.debug('check container run, ok')
        return True

    def process(self):
        if not self.check_run:
            self.logger.debug('pre check fail,can not make docker tar')
            return False

        if not self.check_docker_version():
            return False
        _curdir = os.curdir
        os.chdir(self.root_dir)


        dcont = DcokerContainer(self.logger,self.strWorkSpace,self.container_name,self.image_name,self.ver_path)
        dimage = DockerImage(self.logger,self.strWorkSpace,self.container_name,self.image_name,self.ver_path)

        self.do_process(dcont,dimage)

        self.logger.debug('close logfile')
        dcont.close_log_file()
        dimage.close_log_file()

        os.chdir(_curdir)
        return True

def get_rel_path(path):
    dir_path = os.path.dirname(os.path.realpath(__file__))
    return os.path.join(dir_path,path)

def crt_tar_package(logger,strWorkSpace,container_name,image_name,package_dir = 'prod'):
    '''
    '''
    logger.debug("--> docker_%s_tar_package"%(image_name))
    logger.debug("workspace = %s"%(strWorkSpace))

    if package_dir == 'prod':
        package_dir = tool.get_iportal_verfile(strWorkSpace)
    elif package_dir == 'utm':
        package_dir = tool.get_utm_verfile(strWorkSpace)

    dockert = DockerTar(logger,strWorkSpace,container_name,image_name,package_dir)

    res = dockert.process()
    if res != True:
        logger.error("docker_%s_tar_run fail"%(image_name))
        return ErrorCode.DOCKER_TAR_FAIL
    else:
        logger.debug("docker_%s_tar_run suc"%(image_name))
    dockert.close_log_file()
    logger.debug("<-- docker_%s_tar_package"%(image_name))

    return ErrorCode.SUC

def crt_tar_package_list(logger,cFlag):
    # # build web + nginx docker
    flag = 0
    if cFlag & 0x0001 ==1:
        res =crt_tar_package(logger,os.path.abspath(os.path.join(os.path.dirname(__file__),os.pardir)),"iportal","iportal","prod")
        if res != ErrorCode.SUC:
            flag = flag | 0x0001
    # # build utm images 
    if cFlag & 0x0002 ==2:
        res = crt_tar_package(logger,os.path.abspath(os.path.join(os.path.dirname(__file__),os.pardir)),"utm","utm","utm")
        if res != ErrorCode.SUC:
            flag = flag | 0x0004

    return flag

if __name__ == '__main__':
    from logger import  get_logger
    logger = get_logger('.')
    buildFlag = 0
    argc = len(sys.argv)
    if argc == 1:
        buildFlag = 3
        pass
    else:
        for i in range(argc - 1):
            if sys.argv[i+1] == "iportal":
                buildFlag = buildFlag | 0x0001
            elif sys.argv[i+1] == "utm":
                buildFlag = buildFlag | 0x0002

    crt_tar_package_list(logger,buildFlag)
