__author__ = 'root'

import os
import sys
import setting
import time
from logger import  get_logger
import pexpect

def upload_version_to_paas(module_name,ctlip,verpath):
    '''upload to share 98'''
    logger.debug("begin upload %s ..."%(module_name))
    tarName = module_name + ".tar"
    destPath = ctlip + ":" + verpath
    cmdStr = "scp -r " + tarName + " " + destPath
    passwd = "cloud"
    task = pexpect.spawn(cmdStr,maxread=10000)
    index = task.expect(['continue','password',pexpect.EOF,pexpect.TIMEOUT],
                    timeout = 40)
    if index == 0:
        task.sendline("yes")
        task.expect('password')
        task.sendline(passwd)
        # task.interact()
        task.wait()
    elif index == 1:
        task.sendline(passwd)
        # task.interact()
        task.wait()
    else:
        task.close(True)
        logger.debug("    upload - %s fail"%(module_name))
        return False
    task.close(True)
    time.sleep(8)
    logger.debug("    upload %s success"%(module_name))
    return True
def build_version(logger):

    logger.debug("--> build version")
    cmdStr = 'build_main.py'
    argc = len(sys.argv)
    module_name_list = []
    if argc == 2:
        module_name_list = [ "iportal", "utm" ]
        pass
    else:
        for i in range(argc - 1):
            if sys.argv[i+2] == "iportal":
                cmdStr = cmdStr + " iportal"
                module_name_list.append("iportal")
            elif sys.argv[i+2] == "utm":
                cmdStr = cmdStr + " utm"
                module_name_list.append("utm")
    exeStr = '/bin/bash -c "python %s"'%(cmdStr)
    res = os.system(exeStr)
    if res != 0:
        logger.debug("<-- build version fail !")
        exit(1)
    else:
        logger.debug("<-- build version success !")

    return module_name_list

def login_paas_controller_do(logger,ctrip ,cmdStr):
    loginStr = "ssh " + ctrip
    task = pexpect.spawn(loginStr,maxread=10000)
    index = task.expect(['root@',pexpect.EOF,pexpect.TIMEOUT],
                    timeout = 5)
    if index == 0:
        task.sendline("cloud")
        task.expect(['root@',pexpect.EOF,pexpect.TIMEOUT],timeout = 5)
        task.sendline(cmdStr)
        task.wait()
    else:
        logger.debug("login share vm fail")
        return False
    task.close(True)

def rm_container(logger,module_name):
    logger.debug("rm contain %s"%(module_name))
    cmdStr = "docker ps -a | grep " + module_name + "| awk '{print $1}' | xargs docker rm -f "
    login_paas_controller_do()

def rm_image(logger,module_name):
    '''xxx'''

def run_image(logger,module_name):
    '''xxx'''
    
def chg_contain_in_paas(logger,module_name):
    logger.debug("rm container %s"%(module_name))
    rm_container(logger,module_name)
    logger.debug("rm image %s"%(module_name))
    rm_image(logger,module_name)
    logger.debug("run container %s"%(module_name))
    run_image(logger,module_name)


if __name__ == '__main__':
    # 7 default changer iportal utm
    logger = get_logger(setting.g_strWorkSpace)

    if (sys.argv[1]).count('.') != 3:
        logger.debug(" please usage: ./chg_iportalversion_paas.py $controllerip")
        exit(1)

    controllerip = sys.argv[1]
    controllerversionPath = "/home/iportal"
    module_name_list = []
    #build version
    module_name_list = build_version(logger)

    #create version path in paas controller
    logger.debug("creat version  path in controller")
    createPathStr = "mkdir -p " + controllerversionPath
    login_paas_controller_do(logger,controllerip,createPathStr)
    #upload version
    for module in module_name_list:
        upload_version_to_paas(module,controllerip,controllerversionPath)
        chg_contain_in_paas(logger,module)

    #chg version of paas controller




