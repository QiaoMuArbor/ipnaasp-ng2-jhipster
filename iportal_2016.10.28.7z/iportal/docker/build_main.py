
# -*- coding:utf-8 -*-

from logger import  get_logger
from errorcode import ErrorCode
from build_web import build_web


from docker_tar import crt_tar_package_list


import setting
import sys




def build_main(cFlag,strWorkSpace=setting.g_strWorkSpace):
    logger = get_logger(strWorkSpace)

    if cFlag & 0x0001 == 1:
        res = build_web(logger,strWorkSpace)
        if res != ErrorCode.SUC:
            exit(1)
            return res.get_code()


    res = crt_tar_package_list(logger,cFlag)
    if res != 0 :
        errStr = "fail docker name: "
        if res & 0x0001 == 1:
            errStr += "iportal "
        if res & 0x0002 == 2:
            errStr += "utm "

        logger.debug("docker build fail ------ %s"%(errStr))
        exit(1)
        return ErrorCode.DOCKER_TAR_FAIL.get_code()


    return ErrorCode.SUC.get_code()


if __name__ == '__main__':
    # 7 default build iportal  utm
    complieFlag = 0
    argc = len(sys.argv)
    if argc == 1:
        complieFlag = 3
        pass
    else:
        for i in range(argc - 1):
            if sys.argv[i+1] == "iportal":
                complieFlag = complieFlag | 0x0001
            elif sys.argv[i+1] == "utm":
                complieFlag = complieFlag | 0x0002

    build_main(complieFlag,setting.g_strWorkSpace)