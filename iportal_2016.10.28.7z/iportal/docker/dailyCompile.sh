#!/bin/sh
CurPath=`pwd`
ClientPath=${CurPath}/../client
CodeGerritPath=${CurPath}/..



echo " Begin: daily compile and upload to 98share..."
cd ${CodeGerritPath} && git checkout . && git pull  && \
cd ${ClientPath} && chmod a+x compile.sh && ./compile.sh && cd ${CurPath} && \
   python build_main.py && \
   python upload_tar_to_share.py
echo "End: daily compile and upload to 98share..."