# __author__ = 'root'

# -*- encoding: utf-8 -*-



import os
import sys
from logger import  get_logger
import setting
import tool

def set_srcli_ipport(logger):
    srcli_path = tool.get_ci_srcli_path()
    srcli_name = "zartcli"
    swr_ip = sys.argv[-1]
    swr_port = tool.get_ci_srcli_port()
    ftp_ip = swr_ip

    cmd = ("cd "+ srcli_path + " && ./" + srcli_name + " -S "
          + swr_ip + ":" + swr_port)
    logger.debug('set zartcli begin')
    result = os.system(cmd)
    if result != 0:
        logger.debug("set zartcli failed.")
        return False
    logger.debug("set zartcli successfully.")


def check_tar(logger,module_name):
    '''check iportal utm images is exist'''
    module_tar = module_name + ".tar"
    if not os.path.exists(os.path.join(tool.get_docker(setting.g_strWorkSpace),module_tar)):
        logger.debug( '%s not exists'%(os.path.realpath(os.path.join(tool.get_docker(setting.g_strWorkSpace),module_tar))))
        return False
    else:
        return True

def upload_sw(moduleName, moduleVersion, modulePath):
    srcli_path = tool.get_ci_srcli_path()
    srcli_name = "zartcli"

    cmd = ("cd "+ srcli_path + " && ./" + srcli_name + " -o=upload -i=admin -m=com "
           + " -n=" + moduleName + " -v=" + moduleVersion + " -p="+ modulePath)
    rs = os.system(cmd)
    if rs != 0:
        return False

    return True

# def delete_swr(**kwargs):
#     srcli_path = tool.get_ci_srcli_path()
#     srcli_name = "sr-cli"

#     cmd = ("cd "+ srcli_path + " && ./" + srcli_name + " delete "
#            + kwargs["vertype"] + " " + kwargs["type"] + " "
#            + kwargs["name"] + " " + kwargs["no"])
#     rs = os.system(cmd)
#     if rs != 0:
#         return False

#     return True
def upload_module(logger,module_name):
    # update_path = sys.argv[1]
    update_path = tool.get_deploy(setting.g_strWorkSpace)
    #sys.argv[2] == changid
    if len(sys.argv) >4:
        version = sys.argv[3] + "." + sys.argv[2]
    elif len(sys.argv) >3:
        version = tool.get_ci_version_no() + "." + sys.argv[2]
    else:
        version = tool.get_ci_version_no()
    sw_info_list = [{"name": "utm", "no": version,"path":update_path + "/utm"},
                    {"name": "iportal", "no": version,"path":update_path + "/iportal"}]
    for sw in sw_info_list:
        if (sw["name"] == module_name):
            if not check_tar(logger,module_name):
                logger.debug("module_name not exist")
                return False
            if not upload_sw(sw["name"], sw["no"], sw["path"]):
                print "upload %s error"%(sw["name"])
                logger.debug("upload %s error"%(sw["name"]))
                return False
            else:
                print "upload %s success"%(sw["name"])
                logger.debug("upload %s success"%(sw["name"]))
                return True



def upload_main(logger):


    if len(sys.argv) == 1:
        module_name = "all"
    else:
        module_name = sys.argv[1]


    module_name_list = ["iportal","utm"]
    print "module_name: " + module_name
    # upload iportal utm images to swr
    if module_name == "all":
        for module in module_name_list:
            if not upload_module(logger,module):
                return False
    else:
        if not upload_module(logger,module_name):
            return False
    return True

# def delete_module(logger,module_name):

#     update_path = tool.get_deploy(setting.g_strWorkSpace)
#     if len(sys.argv) >5:
#         version = sys.argv[4] + "." + sys.argv[3]
#     elif len(sys.argv) >4:
#         version = tool.get_ci_version_no() + "." + sys.argv[3]
#     else:
#         version = tool.get_ci_version_no()
#     sw_info_list = [
#                     {
#                      "sw_info": {"vertype": "servicelet", "name": "utm", "type": "paas_release", "no": version},
#                      "path":update_path + "/utm"},
#                     {
#                      "sw_info": {"vertype": "servicelet", "name": "iportal", "type": "paas_release", "no": version},
#                      "path":update_path + "/iportal"}]
#     for sw in sw_info_list:
#         if (sw["sw_info"]["name"] == module_name):
#             if not delete_swr(**sw["sw_info"]):
#                 logger.debug("delete %s fail"%(sw["sw_info"]["name"]))
#                 return False
#             else:
#                 logger.debug("delete %s success"%(sw["sw_info"]["name"]))
#                 return True


# def delete_main(logger):
#     if len(sys.argv) == 2:
#         module_name = "all"
#     else:
#         module_name = sys.argv[2]
#     module_name_list = ["iportal","utm"]
#     print "module_name: " + module_name
#     # upload iportal utm images to swr
#     if module_name == "all":
#         for module in module_name_list:
#             if not delete_module(logger,module):
#                 continue
#     else:
#         if not delete_module(logger,module_name):
#             return False
#     return True

if __name__ == "__main__":
    logger = get_logger(setting.g_strWorkSpace)
    set_srcli_ipport(logger)
    if (len(sys.argv)>1) and (sys.argv[1] == '-d'):
       #delete_main(logger)
        pass
    else:
        upload_main(logger)
