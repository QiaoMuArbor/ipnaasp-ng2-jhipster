# -*- coding:utf-8 -*-


import logging
import os
import tool

import sys
def get_logger(strWorkSpace):

    buildTmpSpace = tool.get_complie(strWorkSpace)
    if (not os.path.exists(buildTmpSpace)):
        os.makedirs(buildTmpSpace)
    iportal_logger = logging.getLogger('iportal')
    iportal_logger.setLevel(logging.DEBUG)
    #iportal_logger.setLevel(logging.ERROR)



    #formatter  = logging.Formatter('%(asctime)s %(name)-12s %(levelname)-8s %(message)s', '%a, %d %b %Y %H:%M:%S')
    formatter  = logging.Formatter('%(asctime)s %(name)-12s %(levelname)-8s %(message)s', '%H:%M:%S')
    file_handler = logging.FileHandler(os.path.join(buildTmpSpace,"iportBuild.log"))
    file_handler.setFormatter(formatter)

    iportal_logger.addHandler(file_handler)
    stream_handler = logging.StreamHandler(sys.stdout)
    stream_handler.setFormatter(formatter)
    iportal_logger.addHandler(stream_handler)
    return iportal_logger
