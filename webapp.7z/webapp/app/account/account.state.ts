export const accountState = {
    name: 'account',
    abstract: true,
    parent: 'app'
};
