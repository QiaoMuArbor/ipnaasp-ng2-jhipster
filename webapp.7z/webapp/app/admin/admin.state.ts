export const adminState = {
    name: 'admin',
    abstract: true,
    parent: 'app'
};
