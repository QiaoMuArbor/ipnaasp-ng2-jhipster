import { Component } from '@angular/core';

@Component({
    selector: 'jhi-docs',
    templateUrl: 'app/admin/docs/docs.html'
})
export class JhiDocsComponent {}
