import { Component, OnInit, Inject } from '@angular/core';

@Component({
    selector: 'footer',
    templateUrl: 'app/layouts/footer/footer.html'
})
export class FooterComponent {}
