export const entityState = {
    name: 'entity',
    abstract: true,
    parent: 'app'
};
