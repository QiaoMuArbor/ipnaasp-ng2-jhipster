angular
    .module('ipnaaspApp.entity', [
        'ngResource',
        'ngFileUpload',
        'ui.bootstrap',
        'ui.router',
        'infinite-scroll'
    ]);
