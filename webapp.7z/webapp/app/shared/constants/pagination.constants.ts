export const ITEMS_PER_PAGE:number = 20;
