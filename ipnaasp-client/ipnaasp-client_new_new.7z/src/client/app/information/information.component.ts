import { Component } from '@angular/core';

@Component({
  moduleId: module.id,
  selector: 'sd-information',
  templateUrl: 'information.component.html',
  styleUrls: ['information.component.css'],
})

export class InformationComponent {

  constructor() {}

}
