export * from './information.component';
export * from './information.component.module';
