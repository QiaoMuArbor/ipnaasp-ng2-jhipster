import { Component } from '@angular/core';

@Component({
  moduleId: module.id,
  selector: 'sd-platformMarket',
  templateUrl: 'platformMarket.component.html',
  styleUrls: ['platformMarket.component.css'],
})

export class PlatformMarketComponent {

  constructor() {}

}
