export * from './platformMarket.component';
export * from './platformMarket.component.module';
