export * from './register.component';
export * from './register.component.module';
