import { Injectable, Inject } from '@angular/core';
import { Http, Response, Headers, RequestOptions, RequestOptionsArgs } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import {LocalStorageService} from '../index';
import { MockCfg } from '../../mock';

@Injectable()
export class AuthServerProvider {
  requestOptions = {
    headers:new Headers({
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': '*'})
  };
    constructor(
        private http: Http,
        private $localStorage: LocalStorageService,
        private $sessionStorage: LocalStorageService
    ){}

    getToken () {
        return this.$localStorage.retrieve('authenticationToken') || this.$sessionStorage.retrieve('authenticationToken');
    }

    login (credentials): Observable<any> {

        var data = {
            username: credentials.username,
            password: credentials.password,
            rememberMe: credentials.rememberMe
        };
        return this.http.post(MockCfg.baseUrl+MockCfg.authenticateUrl, data,this.requestOptions).map(authenticateSuccess.bind(this));

        function authenticateSuccess (resp) {
          console.log(resp);
            var bearerToken = resp.headers.get('Authorization');
          console.log(resp.headers);
            console.log(bearerToken);
            if (bearerToken && bearerToken.slice(0, 7) === 'Bearer ') {
                var jwt = bearerToken.slice(7, bearerToken.length);
                this.storeAuthenticationToken(jwt, credentials.rememberMe);
              console.log(jwt);
                return jwt;
            }
        }
    }

    loginWithToken(jwt, rememberMe) {
        if (jwt) {
            this.storeAuthenticationToken(jwt, rememberMe);
            return Promise.resolve(jwt);
        } else {
            return Promise.reject("auth-jwt-service Promise reject"); //Put appropriate error message here
        }
    }

    storeAuthenticationToken(jwt, rememberMe) {
        if(rememberMe){
            this.$localStorage.set('authenticationToken', jwt);
        } else {
            this.$sessionStorage.set('authenticationToken', jwt);
        }
    }

    logout (): Observable<any> {
        return new Observable(observer => {
            this.$localStorage.clear('authenticationToken');
            this.$sessionStorage.clear('authenticationToken');
            observer.complete();
        });
    }
}
