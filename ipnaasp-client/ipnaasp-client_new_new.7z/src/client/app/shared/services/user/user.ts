export interface User {
  userID: string,
  userPwd: string,
  loginStatus: boolean
}
