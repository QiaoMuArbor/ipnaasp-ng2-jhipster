import { Router } from '@angular/router';
import { PolicyService } from '../shared/index';
import { Component, Renderer, ElementRef } from '@angular/core';
import { LoginService } from '../login/login.service';
import { UserService,LocalStorageService } from'../shared/index';
@Component({
  moduleId: module.id,
  selector: 'sd-login',
  templateUrl: 'login.component.html',
  styleUrls: ['login.component.css'],
  providers: [LoginService]
})

export class LoginComponent {
  private logining: boolean;

  private vm:any = {
    authenticationError:false,
    password:'',
    credentials:{},
    rememberMe:true,
    username:''
  };

  constructor(private _policyService: PolicyService,
              private _userService: UserService,
              private loginService: LoginService,
              private elementRef: ElementRef,
              private renderer: Renderer,
              private router: Router,
              private localStorageService: LocalStorageService
              ) {
    this.logining = false;
  }

  ngOnInit(){
    this._policyService.isShowHeaderMenuFlag = false;
  }
  ngAfterViewInit() {
    this.renderer.invokeElementMethod(this.elementRef.nativeElement.querySelector('#username'), 'focus', []);
  }
  ngOnDestroy() {
    this._policyService.isShowHeaderMenuFlag = true;
  }

  gotoRegist = function() {
    this.router.navigate(['/register']);
  }
  login() {
    let that = this;
    this.logining = true;
    this.loginService.login({
      username: this.vm.username,
      password: this.vm.password,
      rememberMe: this.vm.rememberMe
    }).then(() => {
      this.logining = false;
      this.vm.authenticationError = false;
      this.router.navigate(['/home']);
    }).catch(() => {
      this.vm.authenticationError = true;
      this.logining = false;
    });
  }
  // login() {
  //   let that = this;
  //   this.logining = true;
  //   this._userService.login({
  //         username: this.vm.username,
  //         password: this.vm.password,
  //         rememberMe: this.vm.rememberMe
  //       }).subscribe(data => {
  //         console.log(data);
  //         this.logining = false;
  //         this.vm.authenticationError = false;
  //         var bearerToken = data.headers.get('Authorization');
  //         console.log(bearerToken);
  //         if (bearerToken && bearerToken.slice(0, 7) === 'Bearer ') {
  //           var jwt = bearerToken.slice(7, bearerToken.length);
  //           that.localStorageService.set('Access-Token', jwt);
  //           that.localStorageService.set('username', this.vm.username);
  //           this.router.navigate(['/home']);
  //         }
  //         else {
  //           this.vm.authenticationError = true;
  //           this.logining = false;
  //         }
  //
  //     },
  //     error => {
  //       this.vm.authenticationError = true;
  //       this.logining = false;
  //     });
  // }
}
