import { Component } from '@angular/core';

@Component({
  moduleId: module.id,
  selector: 'sd-socialCircle',
  templateUrl: 'socialCircle.component.html',
  styleUrls: ['socialCircle.component.css'],
})

export class SocialCircleComponent {

  constructor() {}

}
