import { Component } from '@angular/core';

@Component({
  moduleId: module.id,
  selector: 'sd-analysis',
  templateUrl: 'analysis.component.html',
  styleUrls: ['analysis.component.css'],
})

export class AnalysisComponent {

  constructor() {}

}
