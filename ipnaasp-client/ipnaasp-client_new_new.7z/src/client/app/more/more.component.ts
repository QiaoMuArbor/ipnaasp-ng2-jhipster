import { Component } from '@angular/core';

@Component({
  moduleId: module.id,
  selector: 'sd-more',
  templateUrl: 'more.component.html',
  styleUrls: ['more.component.css'],
})

export class MoreComponent {

  constructor() {}

}
