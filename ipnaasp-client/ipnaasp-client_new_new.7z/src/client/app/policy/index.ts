export * from './policy.component';
export * from './policy.component.module';
