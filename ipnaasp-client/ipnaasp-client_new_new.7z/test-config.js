// Load our SystemJS configuration.
System.config({
  baseURL: '/base/'
});

